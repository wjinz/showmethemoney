import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";


// ─────────────────────────────────────────────────────────────
// INPUT MODAL
// ─────────────────────────────────────────────────────────────
async function runOCR(file){
  const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
  const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:512,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:base64}},{type:"text",text:`영수증 분석. JSON만 응답:\n{"merchant":"가맹점","amount":숫자,"date":"YYYY-MM-DD","category":"food|transport|medical|education|housing|culture|clothing|sub|etc","memo":"메모"}\n오늘:${today_str()}`}]}]})});
  const data=await resp.json();
  return JSON.parse(data.content?.map(i=>i.text||"").join("").replace(/```json|```/g,"").trim());
}


function InputModal({defaultWho,names,onClose,onSave}){
  const [mode,setMode]=useState("manual");
  const [who,setWho]=useState(defaultWho||"husband");
  const [amount,setAmount]=useState("");
  const [cat,setCat]=useState("");
  const [memo,setMemo]=useState("");
  const [ocr,setOcr]=useState("idle");
  const [ocrMsg,setOcrMsg]=useState("");
  const num=v=>{if(v==="⌫")setAmount(a=>a.slice(0,-1));else if(v==="000")setAmount(a=>(a+"000").slice(0,9));else setAmount(a=>(a+v).slice(0,9));};
  const handleFile=async e=>{
    const f=e.target.files[0];if(!f)return;
    setOcr("loading");setOcrMsg("Claude AI 분석 중...");
    try{const r=await runOCR(f);setAmount(String(r.amount||""));setCat(r.category||"");setMemo(r.memo||r.merchant||"");setOcr("done");setOcrMsg(`✓ ${r.merchant||"가맹점"} · ${(r.amount||0).toLocaleString()}원`);setMode("manual");}
    catch{setOcr("error");setOcrMsg("인식 실패 · 직접 입력해주세요");}
  };
  const save=()=>{if(!amount||!cat)return;onSave({who,amount:parseInt(amount),cat,memo,date:today_str()});onClose();};
  const pad=["1","2","3","4","5","6","7","8","9","000","0","⌫"];
  return(
    <div style={{position:"fixed",inset:0,zIndex:200,background:"rgba(0,0,0,.82)",backdropFilter:"blur(10px)",display:"flex",flexDirection:"column",justifyContent:"flex-end",animation:"fadeIn .2s ease"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:"var(--bg3)",borderRadius:"22px 22px 0 0",border:"1px solid var(--border2)",borderBottom:"none",padding:"6px 18px 28px",maxHeight:"92dvh",overflowY:"auto",animation:"slideUp .3s ease"}}>
        <div style={{width:36,height:4,background:"rgba(255,255,255,.1)",borderRadius:99,margin:"10px auto 16px"}}/>
        {ocr!=="idle"&&(<div style={{padding:"9px 13px",borderRadius:11,marginBottom:12,background:ocr==="done"?"var(--greenD)":ocr==="error"?"var(--redD)":"var(--bg4)",border:`1px solid ${ocr==="done"?"rgba(77,171,135,.3)":ocr==="error"?"rgba(217,95,95,.3)":"var(--border)"}`,fontSize:12,color:ocr==="done"?"var(--green)":ocr==="error"?"var(--red)":"var(--text2)",display:"flex",alignItems:"center",gap:6}}>
          {ocr==="loading"&&<span style={{animation:"spin .8s linear infinite",display:"inline-block"}}>⟳</span>}{ocrMsg}
        </div>)}
        <div style={{display:"flex",gap:6,marginBottom:14}}>
          {[{id:"manual",l:"✏️ 직접 입력"},{id:"ocr",l:"📸 영수증 OCR"}].map(m=>(
            <button key={m.id} onClick={()=>setMode(m.id)} style={{flex:1,padding:"9px",borderRadius:11,cursor:"pointer",background:mode===m.id?"var(--goldD)":"transparent",border:`1px solid ${mode===m.id?"var(--gold)":"var(--border)"}`,color:mode===m.id?"var(--goldL)":"var(--text2)",fontWeight:600,fontSize:12}}>{m.l}</button>
          ))}
        </div>
        {mode==="ocr"?(
          <div style={{textAlign:"center",padding:"8px 0 14px"}}>
            <div style={{border:"2px dashed var(--border2)",borderRadius:16,padding:"32px 20px",cursor:"pointer",background:"var(--bg4)"}} onClick={()=>document.getElementById("ocrFileV4")?.click()}>
              <div style={{fontSize:36,marginBottom:10}}>📷</div>
              <div style={{fontSize:14,fontWeight:700,marginBottom:5}}>사진 업로드</div>
              <div style={{fontSize:11,color:"var(--text2)"}}>영수증 · 카드전표 · 결제문자<br/><span style={{fontSize:10,color:"var(--text3)"}}>Claude AI가 자동으로 파싱합니다</span></div>
            </div>
            <input id="ocrFileV4" type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          </div>
        ):(
          <>
            <div style={{display:"flex",gap:7,marginBottom:13}}>
              {["husband","wife"].map(w=>(<button key={w} onClick={()=>setWho(w)} style={{flex:1,padding:"9px",borderRadius:11,cursor:"pointer",background:who===w?(w==="husband"?"var(--hD)":"var(--wD)"):"transparent",border:`1px solid ${who===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,color:who===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)",fontWeight:700,fontSize:13}}>{w==="husband"?names.husband:names.wife}</button>))}
            </div>
            <div style={{background:"var(--bg4)",borderRadius:13,padding:"12px 16px",marginBottom:13,display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
              <span style={{fontSize:11,color:"var(--text2)"}}>금액</span>
              <span style={{fontSize:28,fontWeight:700,color:amount?"var(--text)":"var(--text3)",letterSpacing:"-.02em"}}>{amount?parseInt(amount).toLocaleString():"0"}<span style={{fontSize:14,color:"var(--text2)",marginLeft:2}}>원</span></span>
            </div>
            {!amount&&(<div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:13}}>{pad.map(n=>(<button key={n} onClick={()=>num(n)} style={{background:n==="⌫"?"rgba(255,255,255,.03)":"var(--bg4)",border:"1px solid var(--border)",borderRadius:12,padding:"14px",color:"var(--text)",fontSize:17,fontWeight:500,cursor:"pointer"}}>{n}</button>))}</div>)}
            {amount&&(<div style={{display:"flex",gap:6,marginBottom:13}}>{["⌫","000"].map(n=>(<button key={n} onClick={()=>num(n)} style={{flex:1,background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"8px",color:"var(--text2)",fontSize:13,cursor:"pointer"}}>{n}</button>))}<button onClick={()=>setAmount("")} style={{flex:1,background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:10,padding:"8px",color:"var(--red)",fontSize:12,cursor:"pointer",fontWeight:600}}>초기화</button></div>)}
            {amount&&(<div style={{marginBottom:13}}><div style={{fontSize:11,color:"var(--text2)",marginBottom:8}}>카테고리</div><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>{CATS.map(c=>(<button key={c.id} onClick={()=>setCat(c.id)} style={{background:cat===c.id?c.color+"25":"var(--bg4)",border:`1px solid ${cat===c.id?c.color+"66":"var(--border)"}`,borderRadius:12,padding:"10px 6px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4}}><span style={{fontSize:17}}>{c.icon}</span><span style={{fontSize:10,color:cat===c.id?"var(--text)":"var(--text2)"}}>{c.label}</span></button>))}</div></div>)}
            {cat&&(<input placeholder="메모 (선택)" value={memo} onChange={e=>setMemo(e.target.value)} style={{width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:11,padding:"11px 14px",color:"var(--text)",fontSize:13,outline:"none",marginBottom:13}}/>)}
            {amount&&cat&&(<button onClick={save} style={{width:"100%",padding:"15px",background:"linear-gradient(135deg,var(--gold),var(--goldL))",border:"none",borderRadius:13,color:"#1a1200",fontWeight:700,fontSize:15,cursor:"pointer",boxShadow:"0 4px 24px rgba(200,168,75,.3)"}}>저장 · {parseInt(amount).toLocaleString()}원</button>)}
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ENTRY VIEW — 전용 입력 탭 (시뮬 자리 대체)
// ─────────────────────────────────────────────────────────────
async function runOCR_entry(file){
  const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
  const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:512,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:base64}},{type:"text",text:`영수증 분석. JSON만 응답:\n{"merchant":"가맹점","amount":숫자,"date":"YYYY-MM-DD","category":"food|transport|medical|education|housing|culture|clothing|sub|etc","memo":"메모"}\n오늘:${today_str()}`}]}]})});
  const data=await resp.json();
  return JSON.parse(data.content?.map(i=>i.text||"").join("").replace(/```json|```/g,"").trim());
}
-e 
export { InputModal };
