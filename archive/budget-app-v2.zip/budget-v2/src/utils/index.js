// ── 날짜 상수 ─────────────────────────────────────────────────
export const NOW   = new Date();
export const DAYS  = new Date(NOW.getFullYear(), NOW.getMonth()+1, 0).getDate();
export const DAY   = NOW.getDate();
export const MONTH = NOW.getMonth()+1;
export const YEAR  = NOW.getFullYear();
export const today_str = () => NOW.toISOString().split("T")[0];

// ── 숫자 포맷 ─────────────────────────────────────────────────
export const fmt  = n => n.toLocaleString("ko-KR") + "원";
export const fmtS = n => {
  if (n >= 100000000) return (n / 100000000).toFixed(1) + "억";
  if (n >= 10000)     return Math.round(n / 10000) + "만";
  return n.toLocaleString();
};

// ── 카드 정산 알고리즘 ────────────────────────────────────────
//
//  A형) billingEndNextMonth=false : 당월 X일 ~ 당월 Z일 → 다음달 Y일
//  B형) billingEndNextMonth=true  : 당월 X일 ~ 다음달 Z일 → 다음달 Y일
//
export function getBillingPeriod(card, today = NOW) {
  const { billingStartDay, billingEndDay, billingEndNextMonth, paymentDay } = card;
  const y = today.getFullYear();
  const m = today.getMonth();
  const d = today.getDate();
  let sY, sM, eY, eM, pY, pM;

  if (billingEndNextMonth) {
    if (d >= billingStartDay) {
      sY=y; sM=m;
      eY=(m===11?y+1:y); eM=(m===11?0:m+1);
    } else {
      sY=(m===0?y-1:y); sM=(m===0?11:m-1);
      eY=y; eM=m;
    }
    pY=eY; pM=eM;
  } else {
    if (d >= billingStartDay) {
      sY=y; sM=m; eY=y; eM=m;
      pY=(m===11?y+1:y); pM=(m===11?0:m+1);
    } else {
      sY=(m===0?y-1:y); sM=(m===0?11:m-1);
      eY=sY; eM=sM; pY=y; pM=m;
    }
  }

  const cycleStart = new Date(sY, sM, billingStartDay);
  const lastDay    = new Date(eY, eM+1, 0).getDate();
  const cycleEnd   = new Date(eY, eM, Math.min(billingEndDay, lastDay));
  const payDate    = new Date(pY, pM, paymentDay);
  const daysUntilPay = Math.ceil((payDate - today) / 86400000);

  return { cycleStart, cycleEnd, payDate, daysUntilPay };
}

export const toDateStr = d =>
  `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;

export const fmtMonthDay = d => `${d.getMonth()+1}월 ${d.getDate()}일`;

export const fmtPeriodLabel = (s, e) => {
  const sm=s.getMonth()+1, sd=s.getDate(), em=e.getMonth()+1, ed=e.getDate();
  return sm===em ? `${sm}월 ${sd}일 ~ ${ed}일` : `${sm}/${sd} ~ ${em}/${ed}`;
};
