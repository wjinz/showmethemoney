import { useState } from "react";
import { Card, SectionHeader } from "../components/shared";

function AssetView({ assets, setAssets }) {
  return (
    <div style={{ padding: "0 16px 96px", overflowY: "auto", height: "100%" }}>
      <SectionHeader sub="Assets" title="자산 관리" />
      <Card style={{ padding: "32px", textAlign: "center" }}>
        <div style={{ fontSize: 36, marginBottom: 12 }}>🏦</div>
        <div style={{ fontSize: 14, color: "var(--text2)", marginBottom: 6 }}>자산 관리 기능</div>
        <div style={{ fontSize: 12, color: "var(--text3)", lineHeight: 1.7 }}>
          부동산, 금융자산, 현금 등<br />
          가정 전체 자산을 추적합니다.<br />
          다음 업데이트에서 제공될 예정입니다.
        </div>
      </Card>
    </div>
  );
}

export { AssetView };
