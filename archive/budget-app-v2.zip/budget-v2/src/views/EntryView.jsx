import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";

async function runOCR_entry(file){
// ─────────────────────────────────────────────────────────────
// ENTRY VIEW — 전용 입력 탭 (시뮬 자리 대체)
// ─────────────────────────────────────────────────────────────
async function runOCR_entry(file){
  const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
  const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:512,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:base64}},{type:"text",text:`영수증 분석. JSON만 응답:\n{"merchant":"가맹점","amount":숫자,"date":"YYYY-MM-DD","category":"food|transport|medical|education|housing|culture|clothing|sub|etc","memo":"메모"}\n오늘:${today_str()}`}]}]})});
  const data=await resp.json();
  return JSON.parse(data.content?.map(i=>i.text||"").join("").replace(/```json|```/g,"").trim());
}

function EntryView({names,onSave,onDelete,tx,cards}){
  const [mode,  setMode]  = useState("manual");
  const [who,   setWho]   = useState("husband");
  const [amount,setAmount]= useState("");
  const [cat,   setCat]   = useState("");
  const [cardId,setCardId]= useState("");
  const [memo,  setMemo]  = useState("");
  const [saved, setSaved] = useState(false);
  const [ocr,   setOcr]   = useState("idle");
  const [ocrMsg,setOcrMsg]= useState("");

  const myCards = cards.filter(c => c.owner === who);

  const num=v=>{
    if(v==="⌫") setAmount(a=>a.slice(0,-1));
    else if(v==="000") setAmount(a=>(a+"000").slice(0,9));
    else setAmount(a=>(a+v).slice(0,9));
  };
  const reset=()=>{setAmount("");setCat("");setCardId("");setMemo("");setSaved(false);setOcr("idle");setOcrMsg("");};
  const save=()=>{
    if(!amount||!cat) return;
    onSave({who,amount:parseInt(amount),cat,cardId:cardId||null,memo,date:today_str()});
    setSaved(true);
    setTimeout(()=>{setAmount("");setCat("");setCardId("");setMemo("");setSaved(false);},900);
  };

  const handleFile=async e=>{
    const f=e.target.files[0]; if(!f) return;
    setOcr("loading"); setOcrMsg("Claude AI 분석 중...");
    try{
      const r=await runOCR_entry(f);
      setAmount(String(r.amount||"")); setCat(r.category||""); setMemo(r.memo||r.merchant||"");
      setOcr("done"); setOcrMsg(`✓ ${r.merchant||"가맹점"} · ${(r.amount||0).toLocaleString()}원`);
      setMode("manual");
    }catch{ setOcr("error"); setOcrMsg("인식 실패 · 직접 입력해주세요"); }
    e.target.value="";
  };

  const pad=["1","2","3","4","5","6","7","8","9","000","0","⌫"];
  const todayTx=[...tx].filter(t=>t.date===today_str()).sort((a,b)=>b.id-a.id);

  return(
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflowY:"auto",padding:"0 16px 96px"}}>
      {/* Header */}
      <div className="u1" style={{padding:"22px 0 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
        <div>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>Daily Entry</div>
          <div className="serif" style={{fontSize:21}}>지출 입력</div>
        </div>
        <div style={{fontSize:11,color:"var(--text2)",background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:99,padding:"4px 10px"}}>
          오늘 {todayTx.length}건 · {fmtS(todayTx.reduce((s,t)=>s+t.amount,0))}원
        </div>
      </div>

      {/* Mode toggle */}
      <div className="u2" style={{display:"flex",gap:7,marginBottom:14}}>
        {[{id:"manual",l:"✏️ 직접 입력"},{id:"ocr",l:"📸 영수증 OCR"}].map(m=>(
          <button key={m.id} onClick={()=>setMode(m.id)} style={{
            flex:1,padding:"11px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:13,
            background:mode===m.id?"var(--goldD)":"var(--bg2)",
            border:`1px solid ${mode===m.id?"var(--gold)":"var(--border)"}`,
            color:mode===m.id?"var(--goldL)":"var(--text2)"
          }}>{m.l}</button>
        ))}
      </div>

      {/* OCR banner */}
      {ocr!=="idle"&&(
        <div className="u2" style={{
          padding:"10px 14px",borderRadius:12,marginBottom:12,
          background:ocr==="done"?"var(--greenD)":ocr==="error"?"var(--redD)":"var(--bg3)",
          border:`1px solid ${ocr==="done"?"rgba(77,171,135,.3)":ocr==="error"?"rgba(217,95,95,.3)":"var(--border)"}`,
          fontSize:12,color:ocr==="done"?"var(--green)":ocr==="error"?"var(--red)":"var(--text2)",
          display:"flex",alignItems:"center",gap:8
        }}>
          {ocr==="loading"&&<span style={{animation:"spin .8s linear infinite",display:"inline-block"}}>⟳</span>}
          {ocrMsg}
        </div>
      )}

      {mode==="ocr"?(
        /* OCR 업로드 영역 */
        <Card className="u3" style={{padding:"0",overflow:"hidden",marginBottom:14}}>
          <label style={{display:"block",padding:"36px 20px",textAlign:"center",cursor:"pointer"}}>
            <div style={{fontSize:40,marginBottom:12}}>📷</div>
            <div style={{fontSize:15,fontWeight:700,marginBottom:6}}>사진 업로드</div>
            <div style={{fontSize:12,color:"var(--text2)",lineHeight:1.7}}>
              영수증 · 카드전표 · 결제문자 캡처<br/>
              <span style={{fontSize:11,color:"var(--text3)"}}>Claude AI가 금액·가맹점·날짜를 자동으로 읽어옵니다</span>
            </div>
            <input type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          </label>
        </Card>
      ):(
        /* 직접 입력 영역 */
        <div className="u3">
          {/* Who */}
          <div style={{display:"flex",gap:8,marginBottom:12}}>
            {["husband","wife"].map(w=>(
              <button key={w} onClick={()=>setWho(w)} style={{
                flex:1,padding:"12px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:14,
                background:who===w?(w==="husband"?"var(--hD)":"var(--wD)"):"var(--bg2)",
                border:`1px solid ${who===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,
                color:who===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)"
              }}>{w==="husband"?names.husband:names.wife}</button>
            ))}
          </div>

          {/* Amount display */}
          <Card style={{padding:"14px 18px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>금액</span>
            <span style={{fontSize:32,fontWeight:700,color:amount?"var(--text)":"var(--text3)",letterSpacing:"-.02em"}}>
              {amount?parseInt(amount).toLocaleString():"0"}
              <span style={{fontSize:16,color:"var(--text2)",marginLeft:3}}>원</span>
            </span>
          </Card>

          {/* Numpad — 항상 표시 */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7,marginBottom:12}}>
            {pad.map(n=>(
              <button key={n} onClick={()=>num(n)} style={{
                background:n==="⌫"?"var(--bg3)":"var(--bg2)",
                border:"1px solid var(--border)",borderRadius:13,
                padding:"16px",color:"var(--text)",fontSize:18,fontWeight:500,cursor:"pointer",
                transition:"background .1s"
              }}>{n}</button>
            ))}
          </div>

          {/* Category — 금액 입력 전에도 보임 */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:9}}>카테고리</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7}}>
              {CATS.map(c=>(
                <button key={c.id} onClick={()=>setCat(c.id)} style={{
                  background:cat===c.id?c.color+"28":"var(--bg2)",
                  border:`1px solid ${cat===c.id?c.color+"88":"var(--border)"}`,
                  borderRadius:13,padding:"12px 6px",cursor:"pointer",
                  display:"flex",flexDirection:"column",alignItems:"center",gap:5,
                  transition:"all .15s"
                }}>
                  <span style={{fontSize:20}}>{c.icon}</span>
                  <span style={{fontSize:10,fontWeight:cat===c.id?700:400,color:cat===c.id?"var(--text)":"var(--text2)"}}>{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Memo */}
          <input placeholder="메모 (선택사항)" value={memo} onChange={e=>setMemo(e.target.value)}
            style={{width:"100%",background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:"12px 16px",color:"var(--text)",fontSize:13,outline:"none",marginBottom:12}}/>

          {/* 카드 선택 (등록된 카드가 있을 때만) */}
          {myCards.length > 0 && (
            <div style={{marginBottom:12}}>
              <div style={{fontSize:11,color:"var(--text2)",marginBottom:7}}>결제 카드 <span style={{color:"var(--text3)"}}>(선택)</span></div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                <button onClick={()=>setCardId("")} style={{
                  padding:"7px 13px",borderRadius:99,cursor:"pointer",fontSize:11,fontWeight:600,
                  background:!cardId?"var(--bg4)":"transparent",
                  border:`1px solid ${!cardId?"var(--border2)":"var(--border)"}`,
                  color:!cardId?"var(--text)":"var(--text3)"
                }}>현금/기타</button>
                {myCards.map(c=>(
                  <button key={c.id} onClick={()=>setCardId(c.id)} style={{
                    padding:"7px 13px",borderRadius:99,cursor:"pointer",fontSize:11,fontWeight:600,
                    background:cardId===c.id?c.color+"22":"transparent",
                    border:`1px solid ${cardId===c.id?c.color+"88":"var(--border)"}`,
                    color:cardId===c.id?"var(--text)":"var(--text2)",
                    display:"flex",alignItems:"center",gap:5
                  }}>
                    <span>{c.icon}</span>{c.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Save / Reset */}
          <div style={{display:"flex",gap:8,marginBottom:16}}>
            <button onClick={reset} style={{
              width:52,padding:"14px",background:"var(--bg2)",border:"1px solid var(--border)",
              borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:16,flexShrink:0
            }}>↺</button>
            <button onClick={save} disabled={!amount||!cat} style={{
              flex:1,padding:"15px",
              background:saved?"var(--greenD)":(!amount||!cat)?"var(--bg3)":"var(--gold)",
              border:`1px solid ${saved?"var(--green)":(!amount||!cat)?"var(--border)":"transparent"}`,
              borderRadius:13,
              color:saved?"var(--green)":(!amount||!cat)?"var(--text3)":"#fff",
              fontWeight:700,fontSize:15,cursor:(!amount||!cat)?"default":"pointer",
              boxShadow:(!amount||!cat)||saved?"none":"0 4px 24px rgba(200,168,75,.3)",
              transition:"all .2s"
            }}>
              {saved?"✓ 저장됨":(!amount||!cat)?"금액과 카테고리 선택":`저장 · ${amount?parseInt(amount).toLocaleString():0}원`}
            </button>
          </div>
        </div>
      )}

      {/* 오늘의 내역 */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{padding:"12px 14px 8px",display:"flex",justifyContent:"space-between"}}>
          <span style={{fontSize:12,fontWeight:700}}>오늘 내역</span>
          <span style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>{fmtS(todayTx.reduce((s,t)=>s+t.amount,0))}원</span>
        </div>
        {todayTx.length===0?(
          <div style={{padding:"24px 14px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            오늘 입력된 내역이 없어요
          </div>
        ):todayTx.map(t=>{
          const c=CAT[t.cat]||CATS[8];
          return(
            <div key={t.id} style={{padding:"9px 14px",borderTop:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:32,height:32,borderRadius:9,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{c.icon}</div>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:1}}>
                  <span style={{fontSize:12,fontWeight:500}}>{c.label}</span>
                  <Chip who={t.who} names={names}/>
                </div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo||"—"}</div>
              </div>
              <span style={{fontSize:13,fontWeight:700,color:"var(--text)",flexShrink:0}}>-{fmtS(t.amount)}원</span>
              <button onClick={()=>onDelete(t.id)} style={{
                width:26,height:26,borderRadius:7,border:"none",cursor:"pointer",
                background:"var(--redD)",color:"var(--red)",fontSize:13,
                display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0
              }}>✕</button>
            </div>
          );
        })}
      </Card>
    </div>
  );
}
-e 
export { EntryView };
