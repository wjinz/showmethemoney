import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";


function CardView({cards, setCards, tx, names}) {
  const [showAdd, setShowAdd] = useState(false);
  const blank = {name:"", owner:"husband", color:"#1c2340", icon:"💳",
    billingStartDay:13, billingEndDay:14, billingEndNextMonth:true, paymentDay:23};
  const [nc, setNc] = useState({...blank});
  const iStyle = {background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,
    padding:"9px 12px",color:"var(--text)",fontSize:13,outline:"none",width:"100%"};

  const addCard = () => {
    if (!nc.name.trim()) return;
    setCards(cs => [...cs, {...nc, id:"card_"+Date.now()}]);
    setNc({...blank}); setShowAdd(false);
  };
  const delCard = id => setCards(cs => cs.filter(c => c.id !== id));

  return (
    <div className="u4">
      {/* 헤더 안내 */}
      <div style={{
        background:"var(--blueD)",border:"1px solid rgba(92,141,232,.2)",
        borderRadius:14,padding:"13px 15px",marginBottom:14,
        display:"flex",gap:10,alignItems:"flex-start"
      }}>
        <span style={{fontSize:18,flexShrink:0}}>💡</span>
        <div style={{fontSize:11,color:"var(--text2)",lineHeight:1.7}}>
          카드사별 정산 기간을 등록하면 결제일 기준 <strong style={{color:"var(--text)"}}>실제 납부 예정금액</strong>을 정확하게 계산합니다. 지출 입력 시 카드를 선택하면 자동으로 집계돼요.
        </div>
      </div>

      {/* 카드 목록 */}
      {cards.length === 0 ? (
        <div style={{padding:"32px 16px",textAlign:"center",color:"var(--text3)"}}>
          <div style={{fontSize:36,marginBottom:10}}>💳</div>
          <div style={{fontSize:13,color:"var(--text2)",marginBottom:5}}>등록된 카드가 없어요</div>
          <div style={{fontSize:11,lineHeight:1.7}}>아래 버튼으로 카드를 추가하면<br/>정산 기간 기준 청구 예정금액을 확인할 수 있어요</div>
        </div>
      ) : cards.map(card => {
        const { cycleStart, cycleEnd, payDate, daysUntilPay } = getBillingPeriod(card);
        const s = toDateStr(cycleStart), e = toDateStr(cycleEnd);
        const cardTx = tx.filter(t => t.cardId === card.id && t.date >= s && t.date <= e);
        const total  = cardTx.reduce((sum,t) => sum+t.amount, 0);
        const isPast = daysUntilPay < 0;
        const isNear = daysUntilPay >= 0 && daysUntilPay <= 7;

        return (
          <div key={card.id} style={{marginBottom:12,borderRadius:18,overflow:"hidden",border:"1px solid var(--border)"}}>
            {/* 카드 헤더 */}
            <div style={{
              background:`linear-gradient(135deg, ${card.color}f0, ${card.color}a0)`,
              padding:"18px 16px 14px",position:"relative",
            }}>
              {/* D-day 뱃지 */}
              <div style={{
                position:"absolute",top:14,right:14,
                background:isPast?"rgba(0,0,0,.4)":isNear?"rgba(220,60,60,.8)":"rgba(0,0,0,.35)",
                borderRadius:99,padding:"4px 10px",
                fontSize:11,fontWeight:700,color:"#fff",letterSpacing:".04em"
              }}>
                {isPast ? "결제 완료" : `D-${daysUntilPay}`}
              </div>
              <div style={{fontSize:11,color:"rgba(255,255,255,.55)",marginBottom:4}}>
                {card.owner==="husband"?names.husband:names.wife}
              </div>
              <div style={{fontSize:17,fontWeight:700,color:"#fff",marginBottom:10}}>
                {card.icon} {card.name}
              </div>
              <div style={{display:"flex",gap:16}}>
                <div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,.5)",marginBottom:2}}>정산 기간</div>
                  <div style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,.85)"}}>
                    {fmtPeriodLabel(cycleStart, cycleEnd)}
                  </div>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,.5)",marginBottom:2}}>결제일</div>
                  <div style={{fontSize:12,fontWeight:600,color:isNear&&!isPast?"#ffb3b3":"rgba(255,255,255,.85)"}}>
                    {fmtMonthDay(payDate)}
                  </div>
                </div>
              </div>
            </div>

            {/* 청구 금액 */}
            <div style={{background:"var(--bg2)",padding:"14px 16px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:10}}>
                <div>
                  <div style={{fontSize:11,color:"var(--text2)",marginBottom:3}}>
                    {isPast ? "청구 금액 (확정)" : "청구 예정금액"}
                  </div>
                  <div style={{fontSize:22,fontWeight:700,
                    color:total>0?(isNear&&!isPast?"var(--red)":"var(--text)"):"var(--text3)"
                  }}>
                    {fmt(total)}
                  </div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:11,color:"var(--text2)"}}>내역 {cardTx.length}건</div>
                  {!isPast && daysUntilPay >= 0 && (
                    <div style={{fontSize:11,color:"var(--text2)",marginTop:2}}>
                      {daysUntilPay === 0 ? "⚠️ 오늘 결제" : `${daysUntilPay}일 후 결제`}
                    </div>
                  )}
                </div>
              </div>

              {/* 이번 주기 지출 내역 미리보기 */}
              {cardTx.length > 0 ? (
                <div style={{borderTop:"1px solid var(--border)",paddingTop:10}}>
                  {cardTx.slice(-4).reverse().map(t => {
                    const c = CAT[t.cat]||CATS[8];
                    return (
                      <div key={t.id} style={{
                        display:"flex",justifyContent:"space-between",alignItems:"center",
                        padding:"4px 0",fontSize:12
                      }}>
                        <span style={{color:"var(--text2)"}}>
                          {c.icon} {c.label}
                          {t.memo && <span style={{color:"var(--text3)"}}> · {t.memo}</span>}
                          <span style={{color:"var(--text3)",fontSize:10}}> {t.date.slice(5)}</span>
                        </span>
                        <span style={{fontWeight:600,color:"var(--text)",flexShrink:0,marginLeft:8}}>
                          {fmtS(t.amount)}원
                        </span>
                      </div>
                    );
                  })}
                  {cardTx.length > 4 && (
                    <div style={{fontSize:11,color:"var(--text3)",paddingTop:4}}>외 {cardTx.length-4}건 더</div>
                  )}
                </div>
              ) : (
                <div style={{
                  fontSize:11,color:"var(--text3)",paddingTop:8,borderTop:"1px solid var(--border)"
                }}>이번 정산 기간 내 해당 카드 내역 없음</div>
              )}

              {/* 삭제 */}
              <button onClick={()=>delCard(card.id)} style={{
                marginTop:10,width:"100%",padding:"7px",
                background:"transparent",border:"1px solid var(--border)",
                borderRadius:9,color:"var(--text3)",fontSize:11,cursor:"pointer"
              }}>카드 삭제</button>
            </div>
          </div>
        );
      })}

      {/* 카드 추가 폼 */}
      {showAdd ? (
        <Card style={{padding:"18px",marginBottom:10}}>
          <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>+ 카드 등록</div>

          {/* 카드명 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>카드사 / 카드명</div>
            <input placeholder="예: 현대카드 M" value={nc.name}
              onChange={e=>setNc(v=>({...v,name:e.target.value}))} style={iStyle}/>
          </div>

          {/* 사용자 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>사용자</div>
            <div style={{display:"flex",gap:6}}>
              {["husband","wife"].map(w=>(
                <button key={w} onClick={()=>setNc(v=>({...v,owner:w}))} style={{
                  flex:1,padding:"9px",borderRadius:10,cursor:"pointer",fontWeight:600,fontSize:12,
                  background:nc.owner===w?(w==="husband"?"var(--hD)":"var(--wD)"):"var(--bg4)",
                  border:`1px solid ${nc.owner===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,
                  color:nc.owner===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)"
                }}>{w==="husband"?names.husband:names.wife}</button>
              ))}
            </div>
          </div>

          {/* 정산 타입 선택 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>정산 기간 유형</div>
            <div style={{display:"flex",gap:6}}>
              {[
                {v:false, l:"당월 정산", desc:"예: 1일~말일 → 다음달 결제"},
                {v:true,  l:"익월 정산", desc:"예: 13일~다음달14일 → 다음달23일 결제"},
              ].map(t=>(
                <button key={String(t.v)} onClick={()=>setNc(v=>({...v,billingEndNextMonth:t.v}))} style={{
                  flex:1,padding:"9px 6px",borderRadius:10,cursor:"pointer",
                  background:nc.billingEndNextMonth===t.v?"var(--goldD)":"var(--bg4)",
                  border:`1px solid ${nc.billingEndNextMonth===t.v?"var(--gold)":"var(--border)"}`,
                  textAlign:"center"
                }}>
                  <div style={{fontSize:11,fontWeight:700,color:nc.billingEndNextMonth===t.v?"var(--gold)":"var(--text2)",marginBottom:2}}>{t.l}</div>
                  <div style={{fontSize:9,color:"var(--text3)"}}>{t.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* 날짜 설정 */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
            {[
              {label:"정산 시작일", key:"billingStartDay", suffix:"일부터"},
              {label:nc.billingEndNextMonth?"마감일 (익월)":"정산 마감일", key:"billingEndDay", suffix:"일까지"},
              {label:"결제일 (익월)", key:"paymentDay", suffix:"일"},
            ].map(f=>(
              <div key={f.key}>
                <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{f.label}</div>
                <div style={{position:"relative"}}>
                  <input type="number" min={1} max={31} value={nc[f.key]}
                    onChange={e=>setNc(v=>({...v,[f.key]:Math.min(31,Math.max(1,parseInt(e.target.value)||1))}))}
                    style={{...iStyle,textAlign:"center",paddingRight:6}}/>
                  <div style={{fontSize:10,color:"var(--text3)",textAlign:"center",marginTop:3}}>{f.suffix}</div>
                </div>
              </div>
            ))}
          </div>

          {/* 미리보기 */}
          {(() => {
            try {
              const preview = getBillingPeriod(nc);
              return (
                <div style={{
                  background:"var(--greenD)",border:"1px solid rgba(77,171,135,.25)",
                  borderRadius:10,padding:"10px 13px",marginBottom:12,fontSize:11
                }}>
                  <div style={{fontWeight:700,color:"var(--green)",marginBottom:4}}>✓ 정산 미리보기</div>
                  <div style={{color:"var(--text2)",lineHeight:1.8}}>
                    현재 주기: <strong style={{color:"var(--text)"}}>{fmtPeriodLabel(preview.cycleStart, preview.cycleEnd)}</strong><br/>
                    결제일: <strong style={{color:"var(--text)"}}>{fmtMonthDay(preview.payDate)}</strong>
                    {preview.daysUntilPay>=0 && <span style={{color:"var(--text3)"}}> (D-{preview.daysUntilPay})</span>}
                  </div>
                </div>
              );
            } catch { return null; }
          })()}

          {/* 색상 선택 */}
          <div style={{marginBottom:14}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:7}}>카드 색상</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {CARD_PRESETS_COLOR.map(c=>(
                <button key={c} onClick={()=>setNc(v=>({...v,color:c}))} style={{
                  width:28,height:28,borderRadius:8,background:c,border:"none",cursor:"pointer",
                  outline:nc.color===c?"2px solid var(--goldL)":"2px solid transparent",
                  outlineOffset:2,transition:"outline .15s"
                }}/>
              ))}
            </div>
          </div>

          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>{setShowAdd(false);setNc({...blank});}} style={{
              flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",
              borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12
            }}>취소</button>
            <button onClick={addCard} style={{
              flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",
              borderRadius:11,color:"var(--gold)",fontWeight:700,fontSize:13,cursor:"pointer"
            }}>카드 등록</button>
          </div>
        </Card>
      ) : (
        <button onClick={()=>setShowAdd(true)} style={{
          width:"100%",padding:"13px",background:"transparent",
          border:"1px dashed var(--border2)",borderRadius:13,
          color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600
        }}>💳 카드 추가</button>
      )}
    </div>
  );
}

function FixedView({fixed,setFixed,install,setInstall,cards,setCards,tx,names}){
  const [tab,setTab]=useState("fixed");
  const [showAdd,setShowAdd]=useState(false);
  const [nf,setNf]=useState({name:"",amount:"",cat:"etc",icon:"📦"});
  const [showAddI,setShowAddI]=useState(false);
  const [ni,setNi]=useState({name:"",monthly:"",total:"",paidN:"0",cat:"etc",icon:"💳"});
  const fixedTotal  =fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal=install.reduce((s,i)=>s+i.monthly,0);
  const paidFixed   =fixed.filter(f=>f.paid).reduce((s,f)=>s+f.amount,0);
  const togglePaid  =id=>setFixed(fs=>fs.map(f=>f.id===id?{...f,paid:!f.paid}:f));
  const iStyle={width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"9px 13px",color:"var(--text)",fontSize:13,outline:"none"};

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub="Fixed Costs" title="고정비 · 할부"/></div>
      <div className="u2" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
        <Card style={{padding:"14px"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>이달 고정비</div>
          <div style={{fontSize:18,fontWeight:700,color:"var(--gold)"}}>{fmtS(fixedTotal)}원</div>
          <div style={{fontSize:11,color:"var(--text2)",marginTop:3}}>납부 {fmtS(paidFixed)} / 미납 {fmtS(fixedTotal-paidFixed)}</div>
          <div style={{marginTop:8}}><Bar pct={fixedTotal>0?paidFixed/fixedTotal*100:0} color="var(--gold)" h={4}/></div>
        </Card>
        <Card style={{padding:"14px"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>월 할부 부담</div>
          <div style={{fontSize:18,fontWeight:700,color:"var(--pink)"}}>{fmtS(installTotal)}원</div>
          <div style={{fontSize:11,color:"var(--text2)",marginTop:3}}>{install.length}건</div>
          <div style={{marginTop:8}}><Bar pct={install.length>0?Math.round(install.reduce((s,i)=>s+i.paid,0)/install.reduce((s,i)=>s+i.total,0)*100):0} color="var(--pink)" h={4}/></div>
        </Card>
      </div>
      <div className="u3" style={{display:"flex",gap:6,marginBottom:12}}>
        {[
          {id:"fixed",  l:`고정비 (${fixed.length})`},
          {id:"install",l:`할부 (${install.length})`},
          {id:"card",   l:`💳 카드 (${cards.length})`},
        ].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flex:1,padding:"8px 4px",borderRadius:11,cursor:"pointer",fontWeight:700,fontSize:11,
            background:tab===t.id?"var(--goldD)":"transparent",
            border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,
            color:tab===t.id?"var(--gold)":"var(--text2)"
          }}>{t.l}</button>
        ))}
      </div>
      {tab==="fixed"&&(
        <div className="u4">
          <Card style={{overflow:"hidden",marginBottom:10}}>
            {fixed.map(f=>{const c=CAT[f.cat]||CATS[8];return(
              <div key={f.id} style={{padding:"11px 13px",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:34,height:34,borderRadius:10,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,flexShrink:0}}>{f.icon}</div>
                <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600}}>{f.name}</div><div style={{fontSize:11,color:"var(--text2)"}}>{c.label}</div></div>
                <div style={{textAlign:"right",marginRight:6}}>
                  <div style={{fontSize:14,fontWeight:700}}>{fmtS(f.amount)}원</div>
                  <div style={{fontSize:10,color:f.paid?"var(--green)":"var(--red)"}}>{f.paid?"납부완료":"미납"}</div>
                </div>
                <button onClick={()=>togglePaid(f.id)} style={{width:28,height:28,borderRadius:8,border:"none",cursor:"pointer",fontSize:13,flexShrink:0,background:f.paid?"var(--greenD)":"var(--bg4)",color:f.paid?"var(--green)":"var(--text2)"}}>{f.paid?"✓":"○"}</button>
                <button onClick={()=>setFixed(fs=>fs.filter(x=>x.id!==f.id))} style={{width:22,height:22,borderRadius:6,border:"none",cursor:"pointer",fontSize:12,flexShrink:0,background:"transparent",color:"var(--text3)"}}>✕</button>
              </div>
            );})}
          </Card>
          {showAdd?(
            <Card style={{padding:"16px",marginBottom:10}}>
              <div style={{fontSize:12,fontWeight:700,marginBottom:12,color:"var(--text2)"}}>+ 고정비 추가</div>
              <input placeholder="항목명" value={nf.name} onChange={e=>setNf(v=>({...v,name:e.target.value}))} style={{...iStyle,marginBottom:8}}/>
              <input type="number" placeholder="월 금액" value={nf.amount} onChange={e=>setNf(v=>({...v,amount:e.target.value}))} style={{...iStyle,marginBottom:10}}/>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:12}}>
                {CATS.slice(0,6).map(c=>(
                  <button key={c.id} onClick={()=>setNf(v=>({...v,cat:c.id,icon:c.icon}))} style={{background:nf.cat===c.id?c.color+"25":"var(--bg4)",border:`1px solid ${nf.cat===c.id?c.color+"66":"var(--border)"}`,borderRadius:10,padding:"8px 4px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                    <span style={{fontSize:15}}>{c.icon}</span><span style={{fontSize:9,color:"var(--text2)"}}>{c.label}</span>
                  </button>
                ))}
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setShowAdd(false)} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>취소</button>
                <button onClick={()=>{if(!nf.name||!nf.amount)return;setFixed(fs=>[...fs,{id:Date.now(),name:nf.name,amount:parseInt(nf.amount),cat:nf.cat,icon:nf.icon,paid:false}]);setNf({name:"",amount:"",cat:"etc",icon:"📦"});setShowAdd(false);}} style={{flex:2,padding:"10px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:10,color:"var(--goldL)",cursor:"pointer",fontWeight:700,fontSize:12}}>추가</button>
              </div>
            </Card>
          ):(
            <button onClick={()=>setShowAdd(true)} style={{width:"100%",padding:"12px",background:"transparent",border:"1px dashed var(--border2)",borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600}}>+ 고정비 추가</button>
          )}
        </div>
      )}
      {tab==="install"&&(
        <div className="u4">
          {install.map(item=>{
            const pct=Math.round(item.paid/item.total*100);
            const remain=(item.total-item.paid)*item.monthly;
            return(
              <Card key={item.id} style={{padding:"16px",marginBottom:8}}>
                <div style={{display:"flex",gap:10,marginBottom:12}}>
                  <div style={{width:38,height:38,borderRadius:11,background:"var(--pinkD)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{item.icon}</div>
                  <div style={{flex:1}}><div style={{fontSize:14,fontWeight:700,marginBottom:2}}>{item.name}</div><div style={{fontSize:11,color:"var(--text2)"}}>월 {fmtS(item.monthly)}원 · {item.paid}/{item.total}회차</div></div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:13,fontWeight:700,color:"var(--pink)"}}>{fmtS(remain)}원 잔여</div>
                    <div style={{fontSize:10,color:"var(--text2)"}}>{item.total-item.paid}회 남음</div>
                  </div>
                  <button onClick={()=>setInstall(is=>is.filter(x=>x.id!==item.id))} style={{width:22,height:22,borderRadius:6,border:"none",cursor:"pointer",background:"transparent",color:"var(--text3)",fontSize:12,flexShrink:0,alignSelf:"flex-start"}}>✕</button>
                </div>
                <Bar pct={pct} color="var(--pink)" h={5}/>
                <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}><span style={{fontSize:10,color:"var(--text2)"}}>진행 {pct}%</span><span style={{fontSize:10,color:"var(--text2)"}}>완납 {item.total}회차</span></div>
              </Card>
            );
          })}
          {showAddI?(
            <Card style={{padding:"16px",marginBottom:10}}>
              <div style={{fontSize:12,fontWeight:700,marginBottom:12,color:"var(--text2)"}}>+ 할부 추가</div>
              <input placeholder="항목명" value={ni.name} onChange={e=>setNi(v=>({...v,name:e.target.value}))} style={{...iStyle,marginBottom:8}}/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
                <input type="number" placeholder="월 납부액" value={ni.monthly} onChange={e=>setNi(v=>({...v,monthly:e.target.value}))} style={iStyle}/>
                <input type="number" placeholder="총 회차" value={ni.total} onChange={e=>setNi(v=>({...v,total:e.target.value}))} style={iStyle}/>
              </div>
              <input type="number" placeholder="완납 회차 (현재)" value={ni.paidN} onChange={e=>setNi(v=>({...v,paidN:e.target.value}))} style={{...iStyle,marginBottom:12}}/>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setShowAddI(false)} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>취소</button>
                <button onClick={()=>{if(!ni.name||!ni.monthly||!ni.total)return;setInstall(is=>[...is,{id:Date.now(),name:ni.name,monthly:parseInt(ni.monthly),total:parseInt(ni.total),paid:parseInt(ni.paidN)||0,cat:ni.cat,icon:ni.icon}]);setNi({name:"",monthly:"",total:"",paidN:"0",cat:"etc",icon:"💳"});setShowAddI(false);}} style={{flex:2,padding:"10px",background:"var(--pinkD)",border:"1px solid var(--pink)",borderRadius:10,color:"var(--pink)",cursor:"pointer",fontWeight:700,fontSize:12}}>추가</button>
              </div>
            </Card>
          ):(
            <button onClick={()=>setShowAddI(true)} style={{width:"100%",padding:"12px",background:"transparent",border:"1px dashed var(--border2)",borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600}}>+ 할부 추가</button>
          )}
        </div>
      )}
      {tab==="card"&&(
        <CardView cards={cards} setCards={setCards} tx={tx} names={names}/>
      )}
    </div>
  );
}
-e 
export { FixedView };
