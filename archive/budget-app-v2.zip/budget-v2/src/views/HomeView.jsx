import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";

function HomeView({tx,budgets,fixed,install,names,onAdd,sliderCfg}){
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const fixedTotal   = fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal = install.reduce((s,i)=>s+i.monthly,0);
  const totalSpent   = tx.reduce((s,t)=>s+t.amount,0);
  const pct          = Math.round(totalSpent/totalBudget*100);
  const paceTarget   = Math.round(DAY/DAYS*totalBudget);
  const pacePct      = paceTarget>0?Math.round(totalSpent/paceTarget*100):0;
  const remaining    = totalBudget-totalSpent;
  const hSpent       = tx.filter(t=>t.who==="husband").reduce((s,t)=>s+t.amount,0);
  const wSpent       = tx.filter(t=>t.who==="wife").reduce((s,t)=>s+t.amount,0);
  const recent       = [...tx].sort((a,b)=>b.id-a.id).slice(0,4);

  const daysLeft       = Math.max(DAYS - DAY, 1);
  const defaultPaceVal = Math.min(Math.round(remaining / daysLeft), sliderCfg.paceMaxDaily);
  const [paceDaily, setPaceDaily] = useState(Math.max(0, defaultPaceVal));

  const paceMax     = sliderCfg.paceMaxDaily;
  const projected   = totalSpent + paceDaily * daysLeft;
  const projOver    = projected > totalBudget;
  const paceColor   = pacePct<=90?"var(--green)":pacePct<=110?"#d4b84a":"var(--red)";
  const paceStatus  = pacePct<=90?"양호 ✓":pacePct<=110?"보통":"주의";
  const fillColor   = projOver ? "var(--red)" : "var(--green)";

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      {/* Header */}
      <div className="u1" style={{padding:"22px 0 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>{YEAR}년 {MONTH}월 · {DAY}일차</div>
          <div className="serif" style={{fontSize:21}}>가정 경영현황</div>
        </div>
        <div style={{background:paceColor+"22",color:paceColor,fontSize:11,fontWeight:700,padding:"5px 11px",borderRadius:99,border:`1px solid ${paceColor}44`}}>
          PACE {paceStatus}
        </div>
      </div>

      {/* Main card */}
      <Card className="u2" style={{padding:"18px",marginBottom:10,overflow:"hidden",position:"relative"}}>
        <div style={{position:"absolute",top:-50,right:-50,width:180,height:180,borderRadius:"50%",background:"radial-gradient(circle,var(--goldD) 0%,transparent 70%)",pointerEvents:"none"}}/>
        {/* Ring + stats */}
        <div style={{display:"flex",gap:18,alignItems:"center",marginBottom:16}}>
          <Ring pct={pct} size={100} stroke={7}>
            <div style={{fontSize:20,fontWeight:700,color:"var(--gold)"}}>{pct}%</div>
            <div style={{fontSize:9,color:"var(--text2)",letterSpacing:".05em",marginTop:1}}>집행률</div>
          </Ring>
          <div style={{flex:1}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:2}}>누적 지출</div>
            <div style={{fontSize:21,fontWeight:700,letterSpacing:"-.02em"}}>{fmtS(totalSpent)}<span style={{fontSize:13,color:"var(--text2)",marginLeft:2}}>원</span></div>
            <div style={{fontSize:12,color:"var(--text2)",marginTop:1}}>/ {fmtS(totalBudget)}원</div>
            <div style={{display:"flex",gap:14,marginTop:10}}>
              <div><div style={{fontSize:10,color:"var(--text2)"}}>잔여</div><div style={{fontSize:12,fontWeight:700,color:remaining>=0?"var(--green)":"var(--red)"}}>{fmtS(remaining)}원</div></div>
              <div><div style={{fontSize:10,color:"var(--text2)"}}>고정+할부</div><div style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>{fmtS(fixedTotal+installTotal)}원</div></div>
            </div>
          </div>
        </div>

        {/* ④ Pace Slider */}
        <div style={{background:"var(--bg4)",borderRadius:14,padding:"16px",border:"1px solid var(--border2)"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
            <div>
              <div style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>📊 남은 {daysLeft}일 시나리오</div>
              <div style={{fontSize:10,color:"var(--text2)",marginTop:3}}>슬라이더로 일 지출 조정 → 월말 예상 변화</div>
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <div style={{fontSize:10,color:"var(--text2)"}}>월말 예상</div>
              <div style={{fontSize:16,fontWeight:700,color:projOver?"var(--red)":"var(--green)"}}>{fmtS(projected)}원</div>
              <div style={{fontSize:10,color:projOver?"var(--red)":"var(--green)",marginTop:1}}>{projOver?"▲ 예산 초과":"✓ 예산 내"}</div>
            </div>
          </div>

          <SliderRow
            label="일평균 목표 지출"
            value={paceDaily}
            min={0}
            max={paceMax}
            step={5000}
            onChange={setPaceDaily}
            fillColor={fillColor}
            formatVal={v => fmtS(v)+"원/일"}
            showReset
            onReset={() => setPaceDaily(Math.max(0, defaultPaceVal))}
          />

          <div style={{display:"flex",gap:8}}>
            {[{label:"현재 페이스",val:Math.round(totalSpent/DAY),c:"var(--text2)"},{label:"조정 후",val:paceDaily,c:fillColor}].map(b=>(
              <div key={b.label} style={{flex:1,background:"var(--bg3)",borderRadius:10,padding:"9px 12px"}}>
                <div style={{fontSize:10,color:"var(--text2)",marginBottom:3}}>{b.label}</div>
                <div style={{fontSize:14,fontWeight:700,color:b.c}}>{fmtS(b.val)}<span style={{fontSize:10,color:"var(--text2)",marginLeft:2}}>원/일</span></div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Partner */}
      <Card className="u3" style={{padding:"14px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",marginBottom:10}}>파트너별 지출</div>
        <div style={{display:"flex",height:5,borderRadius:99,overflow:"hidden",marginBottom:10}}>
          <div style={{width:`${totalSpent>0?hSpent/totalSpent*100:50}%`,background:"var(--h)",transition:"width .7s ease"}}/>
          <div style={{flex:1,background:"var(--w)"}}/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
          {[{w:"husband",a:hSpent},{w:"wife",a:wSpent}].map(p=>(
            <div key={p.w} style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:p.w==="husband"?"var(--h)":"var(--w)"}}/>
              <div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{p.w==="husband"?names.husband:names.wife}</div>
                <div style={{fontSize:13,fontWeight:700}}>{fmtS(p.a)}원</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          {["husband","wife"].map(w=>(
            <button key={w} onClick={()=>onAdd(w)} style={{
              background:w==="husband"?"var(--hD)":"var(--wD)",
              border:`1px solid ${w==="husband"?"rgba(92,141,232,.25)":"rgba(217,127,168,.25)"}`,
              borderRadius:11,padding:"11px",cursor:"pointer",
              color:w==="husband"?"var(--h)":"var(--w)",fontWeight:700,fontSize:13,
              display:"flex",alignItems:"center",gap:6,justifyContent:"center"
            }}><span style={{fontSize:17,lineHeight:1}}>+</span>{w==="husband"?names.husband:names.wife}</button>
          ))}
        </div>
      </Card>

      {/* Recent */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{padding:"12px 14px 8px",display:"flex",justifyContent:"space-between"}}>
          <span style={{fontSize:12,fontWeight:700}}>최근 내역</span>
          <span style={{fontSize:10,color:"var(--text2)"}}>{tx.length}건</span>
        </div>
        {recent.length===0?(
          <div style={{padding:"28px 14px",textAlign:"center"}}>
            <div style={{fontSize:28,marginBottom:8}}>📋</div>
            <div style={{fontSize:13,color:"var(--text2)",marginBottom:4}}>아직 입력된 내역이 없어요</div>
            <div style={{fontSize:11,color:"var(--text3)"}}>✚ 입력 탭에서 지출을 기록해보세요</div>
          </div>
        ):recent.map(t=>{
          const c=CAT[t.cat]||CATS[8];
          return(
            <div key={t.id} style={{padding:"9px 14px",borderTop:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:33,height:33,borderRadius:9,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{c.icon}</div>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:2}}><span style={{fontSize:12,fontWeight:500}}>{c.label}</span><Chip who={t.who} names={names}/></div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo||"—"} · {t.date.slice(5)}</div>
              </div>
              <span style={{fontSize:13,fontWeight:700,flexShrink:0}}>-{fmtS(t.amount)}원</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}
-e 
export { HomeView };
