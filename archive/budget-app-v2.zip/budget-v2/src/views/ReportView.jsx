import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

function StackedBar({data,total,height=24,showLegend=false}){
  return(
    <div>
      <div style={{display:"flex",height,borderRadius:10,overflow:"hidden"}}>
        {data.filter(d=>d.amount>0).map(d=>{
          const c=CAT[d.cat]; const w=total>0?d.amount/total*100:0;
          return <div key={d.cat} style={{width:`${w}%`,background:c?.color||"#888",transition:"width .7s ease",minWidth:w>1?1:0}} title={`${c?.label} ${Math.round(w)}%`}/>;
        })}
      </div>
      {showLegend&&(
        <div style={{display:"flex",flexWrap:"wrap",gap:"5px 12px",marginTop:8}}>
          {data.filter(d=>d.amount>0&&total>0&&d.amount/total>.03).map(d=>{
            const c=CAT[d.cat]; const p=Math.round(d.amount/total*100);
            return(<div key={d.cat} style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:6,height:6,borderRadius:1,background:c?.color}}/><span style={{fontSize:10,color:"var(--text2)"}}>{c?.label} {p}%</span></div>);
          })}
        </div>
      )}
    </div>
  );
}

function ReportContent({tx,budgets,fixed,install,names}){
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const totalSpent   = tx.reduce((s,t)=>s+t.amount,0);
  const fixedTotal   = fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal = install.reduce((s,i)=>s+i.monthly,0);
  const projected    = DAY > 0 ? Math.round(totalSpent / DAY * DAYS) : 0;
  const hSpent = tx.filter(t=>t.who==="husband").reduce((s,t)=>s+t.amount,0);
  const wSpent = tx.filter(t=>t.who==="wife").reduce((s,t)=>s+t.amount,0);

  // 이번 달 카테고리별 집계
  const curMonthStr = `${YEAR}-${String(MONTH).padStart(2,"0")}`;
  const curTx  = tx.filter(t=>t.date.startsWith(curMonthStr));
  const catData= CATS.map(c=>({cat:c.id,amount:curTx.filter(t=>t.cat===c.id).reduce((s,t)=>s+t.amount,0)}));
  const curTotal = curTx.reduce((s,t)=>s+t.amount,0);

  // 전월 데이터 — 실제 tx에서 계산
  const prevYear  = MONTH===1 ? YEAR-1 : YEAR;
  const prevMonth = MONTH===1 ? 12 : MONTH-1;
  const prevMonthStr = `${prevYear}-${String(prevMonth).padStart(2,"0")}`;
  const prevTx   = tx.filter(t=>t.date.startsWith(prevMonthStr));
  const prevCatData = CATS.map(c=>({cat:c.id,amount:prevTx.filter(t=>t.cat===c.id).reduce((s,t)=>s+t.amount,0)}));
  const prevTotal= prevTx.reduce((s,t)=>s+t.amount,0);
  const hasPrev  = prevTotal > 0;

  // 월 표시 레이블
  const prevLabel = `${prevYear}년 ${prevMonth}월`;

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub={`${YEAR}년 ${MONTH}월 · ${DAY}일 기준`} title="월간 경영 리포트"/></div>

      {/* 지출 구조 비교 */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 지출 구조 비교</div>

        {/* 이번 달 */}
        <div style={{marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <span style={{fontSize:12,fontWeight:600}}>이번 달 ({fmtS(curTotal)}원)</span>
            <span style={{fontSize:11,color:projected>totalBudget?"var(--red)":"var(--green)"}}>
              예상 {fmtS(projected)}원
            </span>
          </div>
          {curTotal > 0
            ? <StackedBar data={catData} total={curTotal} height={24} showLegend/>
            : <div style={{height:24,borderRadius:10,background:"var(--track)",display:"flex",alignItems:"center",paddingLeft:12}}>
                <span style={{fontSize:11,color:"var(--text3)"}}>이번 달 지출 내역 없음</span>
              </div>
          }
        </div>

        {/* 전월 */}
        <div style={{borderTop:"1px solid var(--border)",paddingTop:14}}>
          <div style={{marginBottom:8}}>
            <span style={{fontSize:12,fontWeight:600,color:"var(--text2)"}}>
              {prevLabel} ({fmtS(prevTotal)}원)
            </span>
          </div>
          {hasPrev
            ? <StackedBar data={prevCatData} total={prevTotal} height={18} showLegend/>
            : <div style={{
                height:18,borderRadius:8,background:"var(--track)",
                display:"flex",alignItems:"center",paddingLeft:12
              }}>
                <span style={{fontSize:11,color:"var(--text3)"}}>전월 데이터 없음</span>
              </div>
          }
        </div>

        {/* 전월 대비 증감 */}
        <div style={{marginTop:14,paddingTop:12,borderTop:"1px solid var(--border)"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:10}}>전월 대비 증감</div>
          {hasPrev && curTotal > 0 ? (
            <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
              {CATS.map(c=>{
                const cur = catData.find(d=>d.cat===c.id)?.amount||0;
                const prv = prevCatData.find(d=>d.cat===c.id)?.amount||0;
                if(!cur && !prv) return null;
                const diff = cur - prv;
                const isUp = diff > 0;
                const isNew = prv === 0 && cur > 0;
                const isGone = cur === 0 && prv > 0;
                return(
                  <div key={c.id} style={{
                    background:"var(--bg3)",borderRadius:10,padding:"8px 11px",
                    display:"flex",alignItems:"center",gap:7,
                    border:`1px solid ${isUp?"var(--redD)":isGone?"var(--border)":"var(--greenD)"}`
                  }}>
                    <span style={{fontSize:14}}>{c.icon}</span>
                    <div>
                      <div style={{fontSize:10,color:"var(--text2)",marginBottom:1}}>{c.label}</div>
                      <div style={{fontSize:12,fontWeight:700,
                        color:isNew?"var(--blue)":isGone?"var(--text3)":isUp?"var(--red)":"var(--green)"
                      }}>
                        {isNew ? "신규" : isGone ? "없음" : `${isUp?"+":""}${fmtS(diff)}원`}
                      </div>
                    </div>
                  </div>
                );
              }).filter(Boolean)}
            </div>
          ) : (
            <div style={{
              padding:"16px",borderRadius:12,background:"var(--bg3)",
              textAlign:"center",color:"var(--text3)",fontSize:12
            }}>
              {!hasPrev && curTotal > 0
                ? `${prevLabel} 데이터가 없어 비교할 수 없어요`
                : "이번 달 또는 전월 데이터가 없어요"
              }
            </div>
          )}
        </div>
      </Card>

      {/* 총괄 */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:12}}>■ 총괄</div>
        {[
          {l:"월 총 예산",  v:fmt(totalBudget),                        c:"var(--text2)"},
          {l:"고정비+할부", v:fmt(fixedTotal+installTotal),             c:"var(--gold)"},
          {t:"div"},
          {l:"누적 지출",   v:fmt(totalSpent),                         c:"var(--text)"},
          {l:"잔여 예산",   v:fmt(totalBudget-totalSpent),              c:totalBudget-totalSpent>=0?"var(--green)":"var(--red)"},
          {l:"월말 예상",   v:totalSpent>0?fmt(projected):"—",         c:projected>totalBudget?"var(--red)":"var(--gold)"},
        ].map((r,i)=>r.t?<div key={i} style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>:(
          <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:"1px solid var(--border)"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>{r.l}</span>
            <span style={{fontSize:13,fontWeight:700,color:r.c}}>{r.v}</span>
          </div>
        ))}
      </Card>

      {/* 카테고리별 KPI */}
      <Card className="u4" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 카테고리별 KPI</div>
        {CATS.map(cat=>{
          const spent  = tx.filter(t=>t.cat===cat.id).reduce((s,t)=>s+t.amount,0);
          const budget = budgets[cat.id]||0;
          if(!budget && !spent) return null;
          const pct = budget>0 ? Math.round(spent/budget*100) : 0;
          return(
            <div key={cat.id} style={{marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:14}}>{cat.icon}</span>
                  <span style={{fontSize:12,fontWeight:500}}>{cat.label}</span>
                  <span style={{fontSize:12}}>{pct>100?"🔴":pct>85?"🟡":"🟢"}</span>
                </div>
                <div style={{display:"flex",alignItems:"baseline",gap:4}}>
                  <span style={{fontSize:12,fontWeight:700}}>{fmtS(spent)}</span>
                  <span style={{fontSize:10,color:"var(--text2)"}}>/ {fmtS(budget)}원</span>
                  <span style={{fontSize:11,fontWeight:700,minWidth:34,textAlign:"right",
                    color:pct>100?"var(--red)":pct>85?"var(--gold)":"var(--green)"
                  }}>{pct}%</span>
                </div>
              </div>
              <Bar pct={pct} color={cat.color} h={4}/>
            </div>
          );
        })}
        {CATS.every(c=>(budgets[c.id]||0)===0 && tx.filter(t=>t.cat===c.id).length===0) && (
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            예산을 설정하거나 지출을 입력하면 KPI가 표시됩니다
          </div>
        )}
      </Card>

      {/* 파트너별 비교 */}
      <Card className="u5" style={{padding:"18px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:12}}>■ 파트너별 비교</div>
        {totalSpent > 0 ? (
          <>
            <div style={{display:"flex",borderRadius:8,overflow:"hidden",height:16,marginBottom:12}}>
              <div style={{width:`${hSpent/totalSpent*100}%`,background:"var(--h)",transition:"width .7s ease"}}/>
              <div style={{flex:1,background:"var(--w)"}}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {[{who:"husband",amt:hSpent},{who:"wife",amt:wSpent}].map(p=>(
                <div key={p.who} style={{background:"var(--bg3)",borderRadius:13,padding:"13px"}}>
                  <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:7}}>
                    <div style={{width:7,height:7,borderRadius:"50%",background:p.who==="husband"?"var(--h)":"var(--w)"}}/>
                    <span style={{fontSize:11,color:"var(--text2)"}}>{p.who==="husband"?names.husband:names.wife}</span>
                  </div>
                  <div style={{fontSize:17,fontWeight:700}}>{fmt(p.amt)}</div>
                  <div style={{fontSize:11,color:"var(--text2)",marginTop:2}}>
                    {tx.filter(t=>t.who===p.who).length}건 · {totalSpent>0?Math.round(p.amt/totalSpent*100):0}%
                  </div>
                </div>
              ))}
            </div>
          </>
        ):(
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            지출을 입력하면 파트너별 비교가 표시됩니다
          </div>
        )}
      </Card>
    </div>
  );
}

function SimulatorView({sliderCfg,onUpdateSimCfg}){
  const [init,   setInit]   = useState(sliderCfg.simInitAmt);
  const [monthly,setMonthly]= useState(sliderCfg.simMonthly);
  const [rate,   setRate]   = useState(sliderCfg.simRate);
  const [years,  setYears]  = useState(sliderCfg.simYears);
  const [goal,   setGoal]   = useState(sliderCfg.simGoal);

  const reset=()=>{setInit(sliderCfg.simInitAmt);setMonthly(sliderCfg.simMonthly);setRate(sliderCfg.simRate);setYears(sliderCfg.simYears);setGoal(sliderCfg.simGoal);};

  const data=useMemo(()=>{
    const r=rate/100;
    return Array.from({length:years+1},(_,y)=>({
      year:y,
      복리성장:Math.round(init*Math.pow(1+r,y)+monthly*12*(r>0?(Math.pow(1+r,y)-1)/r:y)),
      단순저축:Math.round(init+monthly*12*y),
      원금:init,
    }));
  },[init,monthly,rate,years]);

  const final=data[data.length-1];
  const multiple=(final.복리성장/Math.max(init,1)).toFixed(1);
  const goalYear=data.findIndex(d=>d.복리성장>=goal);

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1">
        <div style={{padding:"22px 0 4px",display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
          <SectionHeader sub="Finance Simulator" title="재무 시뮬레이터"/>
          <button onClick={reset} style={{fontSize:11,color:"var(--text2)",background:"rgba(255,255,255,.04)",border:"1px solid var(--border)",borderRadius:8,padding:"5px 12px",cursor:"pointer",marginBottom:14}}>전체 초기화</button>
        </div>
      </div>

      {/* Sliders */}
      <Card className="u2" style={{padding:"20px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:16}}>■ 변수 조정</div>
        <SliderRow label="초기 투자금" value={init} min={1000000} max={100000000} step={1000000}
          onChange={setInit} fillColor="var(--gold)"
          showReset onReset={()=>setInit(sliderCfg.simInitAmt)}/>
        <SliderRow label="월 저축액" value={monthly} min={100000} max={3000000} step={50000}
          onChange={setMonthly} fillColor="var(--blue)"
          showReset onReset={()=>setMonthly(sliderCfg.simMonthly)}/>
        <SliderRow label="연 수익률" value={rate} min={1} max={20} step={0.5}
          onChange={setRate} fillColor="var(--green)"
          formatVal={v=>v.toFixed(1)+"%"}
          showReset onReset={()=>setRate(sliderCfg.simRate)}/>
        <SliderRow label="투자 기간" value={years} min={1} max={40} step={1}
          onChange={setYears} fillColor="var(--pink)"
          formatVal={v=>v+"년"}
          showReset onReset={()=>setYears(sliderCfg.simYears)}/>

        <div style={{borderTop:"1px solid var(--border)",paddingTop:16,marginTop:4}}>
          <SliderRow label="🎯 목표 금액" value={goal} min={10000000} max={1000000000} step={10000000}
            onChange={setGoal} fillColor="var(--purple)"
            formatVal={v=>fmtS(v)+"원"}
            showReset onReset={()=>setGoal(sliderCfg.simGoal)}/>
          <div style={{
            background:goalYear>0?"var(--greenD)":"var(--redD)",
            border:`1px solid ${goalYear>0?"rgba(77,171,135,.3)":"rgba(217,95,95,.3)"}`,
            borderRadius:10,padding:"10px 14px",fontSize:12,
            color:goalYear>0?"var(--green)":"var(--red)"
          }}>
            {goalYear>0
              ?`✓ ${goalYear}년 후 달성 예상 (${YEAR+goalYear}년)`
              :`✗ ${years}년 내 달성 불가 — 저축액이나 수익률을 높여보세요`
            }
          </div>
        </div>
      </Card>

      {/* Result */}
      <div className="u3" style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:10}}>
        {[
          {label:"최종 금액",  val:fmtS(final.복리성장)+"원",c:"var(--goldL)", icon:"💰"},
          {label:"복리 추가수익",val:fmtS(final.복리성장-final.단순저축)+"원",c:"var(--green)",icon:"📈"},
          {label:"원금 대비",  val:multiple+"배",             c:"var(--purple)",icon:"✨"},
        ].map(c=>(
          <Card key={c.label} style={{padding:"13px 8px",textAlign:"center"}}>
            <div style={{fontSize:18,marginBottom:5}}>{c.icon}</div>
            <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{c.label}</div>
            <div style={{fontSize:13,fontWeight:700,color:c.c,lineHeight:1.2}}>{c.val}</div>
          </Card>
        ))}
      </div>

      {/* Chart */}
      <Card className="u4" style={{padding:"18px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 성장 곡선</div>
        <div style={{height:210}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{top:5,right:8,left:0,bottom:5}}>
              <XAxis dataKey="year" tick={{fill:"var(--text3)",fontSize:10}} tickLine={false} axisLine={false} tickFormatter={v=>v+"년"}/>
              <YAxis tick={{fill:"var(--text3)",fontSize:10}} tickLine={false} axisLine={false} tickFormatter={fmtS} width={40}/>
              <Tooltip content={simTooltip}/>
              {goalYear>0&&<ReferenceLine x={goalYear} stroke="rgba(200,168,75,.5)" strokeDasharray="4 4"/>}
              <Line type="monotone" dataKey="복리성장" stroke="#5c8de8" strokeWidth={2.5} dot={false}/>
              <Line type="monotone" dataKey="단순저축" stroke="#4dab87" strokeWidth={1.5} dot={false} strokeDasharray="5 4"/>
              <Line type="monotone" dataKey="원금"    stroke="rgba(255,255,255,.15)" strokeWidth={1} dot={false} strokeDasharray="3 6"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div style={{display:"flex",gap:16,marginTop:10,justifyContent:"center"}}>
          {[{c:"#5c8de8",l:"복리 성장"},{c:"#4dab87",l:"단순 저축"},{c:"rgba(255,255,255,.25)",l:"원금"}].map(l=>(
            <div key={l.l} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:14,height:2,background:l.c,borderRadius:1}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.l}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function CalendarView({tx, cards, names, budgets}) {
  const [selDate, setSelDate] = useState(today_str());
  const [selCard, setSelCard] = useState(null); // 카드 결제일 팝업

  // 현재 표시 월 (네비게이션 가능)
  const [viewYear,  setViewYear]  = useState(YEAR);
  const [viewMonth, setViewMonth] = useState(MONTH); // 1-indexed

  const firstDay    = new Date(viewYear, viewMonth-1, 1).getDay(); // 0=일
  const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
  const isCurrentMonth = viewYear===YEAR && viewMonth===MONTH;

  // 날짜별 지출 합계
  const dailyMap = {};
  tx.forEach(t => {
    const [ty, tm] = t.date.split("-").map(Number);
    if (ty===viewYear && tm===viewMonth) {
      dailyMap[t.date] = (dailyMap[t.date]||0) + t.amount;
    }
  });

  // 이 달 최대 지출 (히트맵 기준)
  const maxDaily = Math.max(...Object.values(dailyMap), 1);

  // 이 달 총 예산 대비 일 기준
  const totalBudget = Object.values(budgets).reduce((s,v)=>s+v,0);
  const dailyBudget = totalBudget / daysInMonth;

  // 카드 결제일 — 이 달에 해당하는 것들
  const cardPayDates = cards.map(card => {
    try {
      const { payDate, cycleStart, cycleEnd, daysUntilPay } = getBillingPeriod(card,
        new Date(viewYear, viewMonth-1, 15)); // 해당 월 기준
      const pY = payDate.getFullYear(), pM = payDate.getMonth()+1, pD = payDate.getDate();
      if (pY===viewYear && pM===viewMonth) {
        return { card, payDay: pD, payDate, cycleStart, cycleEnd, daysUntilPay };
      }
    } catch { return null; }
    return null;
  }).filter(Boolean);

  // 카드 결제일 맵 (날짜 → 카드 배열)
  const payDateMap = {};
  cardPayDates.forEach(cp => {
    const key = `${viewYear}-${String(viewMonth).padStart(2,"0")}-${String(cp.payDay).padStart(2,"0")}`;
    if (!payDateMap[key]) payDateMap[key] = [];
    payDateMap[key].push(cp);
  });

  // 선택된 날 내역
  const selTx   = tx.filter(t => t.date === selDate).sort((a,b)=>b.id-a.id);
  const selTotal = selTx.reduce((s,t)=>s+t.amount, 0);
  const selPayCards = payDateMap[selDate] || [];

  const prevMonth = () => {
    if (viewMonth===1) { setViewYear(y=>y-1); setViewMonth(12); }
    else setViewMonth(m=>m-1);
  };
  const nextMonth = () => {
    if (viewMonth===12) { setViewYear(y=>y+1); setViewMonth(1); }
    else setViewMonth(m=>m+1);
  };

  const DNAMES = ["일","월","화","수","목","금","토"];
  const selDateLabel = `${selDate.split("-")[1]}월 ${selDate.split("-")[2].replace(/^0/,"")}일`;

  return (
    <div style={{padding:"0 16px 96px", overflowY:"auto", height:"100%"}}>

      {/* 월 네비게이션 */}
      <div className="u1" style={{padding:"22px 0 14px", display:"flex", alignItems:"center", justifyContent:"space-between"}}>
        <button onClick={prevMonth} style={{
          width:34,height:34,borderRadius:10,border:"1px solid var(--border)",
          background:"var(--bg2)",cursor:"pointer",fontSize:16,color:"var(--text2)",
          display:"flex",alignItems:"center",justifyContent:"center"
        }}>‹</button>
        <div style={{textAlign:"center"}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase"}}>{viewYear}</div>
          <div className="serif" style={{fontSize:22,lineHeight:1.2}}>{viewMonth}월</div>
        </div>
        <button onClick={nextMonth} style={{
          width:34,height:34,borderRadius:10,border:"1px solid var(--border)",
          background:"var(--bg2)",cursor:"pointer",fontSize:16,color:"var(--text2)",
          display:"flex",alignItems:"center",justifyContent:"center"
        }}>›</button>
      </div>

      {/* 이달 요약 */}
      {isCurrentMonth && (
        <div className="u2" style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
          {[
            {l:"이달 지출", v:fmtS(tx.filter(t=>t.date.startsWith(`${YEAR}-${String(MONTH).padStart(2,"0")}`)).reduce((s,t)=>s+t.amount,0))+"원", c:"var(--text)"},
            {l:"결제 예정", v:cards.length>0?fmtS(cardPayDates.reduce((s,cp)=>{
              const s2=toDateStr(cp.cycleStart),e2=toDateStr(cp.cycleEnd);
              return s+tx.filter(t=>t.cardId===cp.card.id&&t.date>=s2&&t.date<=e2).reduce((a,t)=>a+t.amount,0);
            },0))+"원":"—", c:"var(--pink)"},
            {l:"카드 수", v:cards.length+"개", c:"var(--blue)"},
          ].map(s=>(
            <Card key={s.l} style={{padding:"11px 10px",textAlign:"center"}}>
              <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{s.l}</div>
              <div style={{fontSize:13,fontWeight:700,color:s.c}}>{s.v}</div>
            </Card>
          ))}
        </div>
      )}

      {/* 달력 */}
      <Card className="u3" style={{padding:"14px",marginBottom:12}}>
        {/* 요일 헤더 */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",marginBottom:6}}>
          {DNAMES.map((d,i)=>(
            <div key={d} style={{
              textAlign:"center",fontSize:11,fontWeight:600,
              color:i===0?"var(--red)":i===6?"var(--blue)":"var(--text3)",
              padding:"3px 0"
            }}>{d}</div>
          ))}
        </div>

        {/* 날짜 그리드 */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
          {Array(firstDay).fill(null).map((_,i)=><div key={"e"+i}/>)}
          {Array(daysInMonth).fill(null).map((_,i)=>{
            const d = i+1;
            const dateStr = `${viewYear}-${String(viewMonth).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
            const amt = dailyMap[dateStr]||0;
            const isSel = dateStr===selDate;
            const isToday = dateStr===today_str();
            const payCards = payDateMap[dateStr]||[];
            const hasPayDay = payCards.length>0;
            const isOver = amt > dailyBudget * 1.5;
            const weekday = (firstDay + i) % 7;

            // 히트맵 강도 (0~1)
            const intensity = amt>0 ? Math.min(amt/maxDaily, 1) : 0;
            const heatBg = amt>0
              ? `rgba(${isOver?"217,95,95":"77,171,135"}, ${0.15 + intensity*0.5})`
              : "transparent";

            return (
              <div
                key={d}
                onClick={()=>setSelDate(dateStr)}
                style={{
                  borderRadius:9,padding:"5px 2px 4px",cursor:"pointer",
                  textAlign:"center",position:"relative",
                  background: isSel ? "var(--goldD)" : heatBg,
                  border:`1px solid ${isSel?"var(--gold)":"transparent"}`,
                  transition:"all .12s",
                  minHeight:46,
                }}
              >
                <div style={{
                  fontSize:12,fontWeight:isToday?700:400,lineHeight:1,
                  color:isToday?"var(--gold)":isSel?"var(--gold)":weekday===0?"var(--red)":weekday===6?"var(--blue)":"var(--text)"
                }}>{d}</div>

                {/* 지출 금액 */}
                {amt>0 && (
                  <div style={{fontSize:8,color:isSel?"var(--goldL)":"var(--text2)",marginTop:2,lineHeight:1}}>
                    {fmtS(amt)}
                  </div>
                )}

                {/* 카드 결제일 배지 */}
                {hasPayDay && (
                  <div style={{
                    position:"absolute",bottom:2,right:2,
                    width:5,height:5,borderRadius:"50%",
                    background:"var(--pink)"
                  }}/>
                )}

                {/* 오늘 표시 */}
                {isToday && (
                  <div style={{
                    position:"absolute",top:2,right:2,
                    width:5,height:5,borderRadius:"50%",
                    background:"var(--gold)"
                  }}/>
                )}
              </div>
            );
          })}
        </div>

        {/* 범례 */}
        <div style={{display:"flex",gap:14,marginTop:12,paddingTop:10,borderTop:"1px solid var(--border)",flexWrap:"wrap"}}>
          {[
            {color:"var(--gold)",label:"오늘"},
            {color:"rgba(77,171,135,.7)",label:"지출 있음"},
            {color:"rgba(217,95,95,.7)",label:"과지출 (1.5배↑)"},
            {color:"var(--pink)",label:"💳 카드 결제일"},
          ].map(l=>(
            <div key={l.label} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:l.color,flexShrink:0}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.label}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* 선택된 날 상세 */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{
          padding:"13px 15px 10px",
          display:"flex",justifyContent:"space-between",alignItems:"center",
          borderBottom:"1px solid var(--border)"
        }}>
          <div>
            <span style={{fontSize:13,fontWeight:700}}>{selDateLabel}</span>
            {selPayCards.length>0 && (
              <span style={{
                marginLeft:8,fontSize:10,fontWeight:700,
                background:"var(--pinkD)",color:"var(--pink)",
                padding:"2px 7px",borderRadius:99
              }}>💳 결제일</span>
            )}
          </div>
          <span style={{fontSize:13,fontWeight:700,color:selTotal>0?"var(--text)":"var(--text3)"}}>
            {selTotal>0 ? fmt(selTotal) : "지출 없음"}
          </span>
        </div>

        {/* 카드 결제일 정보 */}
        {selPayCards.map(cp=>{
          const s=toDateStr(cp.cycleStart), e=toDateStr(cp.cycleEnd);
          const cardTotal = tx.filter(t=>t.cardId===cp.card.id&&t.date>=s&&t.date<=e).reduce((a,t)=>a+t.amount,0);
          return(
            <div key={cp.card.id} style={{
              padding:"12px 15px",
              background:`linear-gradient(135deg,${cp.card.color}28,${cp.card.color}10)`,
              borderBottom:"1px solid var(--border)"
            }}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:15}}>{cp.card.icon}</span>
                  <span style={{fontSize:13,fontWeight:700}}>{cp.card.name}</span>
                  <span style={{fontSize:10,color:"var(--text2)"}}>결제일</span>
                </div>
                <span style={{fontSize:16,fontWeight:700,color:"var(--pink)"}}>{fmt(cardTotal)}</span>
              </div>
              <div style={{fontSize:11,color:"var(--text2)"}}>
                정산 기간: {fmtPeriodLabel(cp.cycleStart,cp.cycleEnd)}
              </div>
            </div>
          );
        })}

        {/* 당일 지출 내역 */}
        {selTx.length===0 && selPayCards.length===0 ? (
          <div style={{padding:"22px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            이 날의 기록이 없어요
          </div>
        ):selTx.map(t=>{
          const c = CAT[t.cat]||CATS[8];
          const cardName = t.cardId ? cards.find(c=>c.id===t.cardId)?.name : null;
          return(
            <div key={t.id} style={{
              padding:"10px 15px",borderBottom:"1px solid var(--border)",
              display:"flex",alignItems:"center",gap:10
            }}>
              <div style={{
                width:34,height:34,borderRadius:9,flexShrink:0,
                background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15
              }}>{c.icon}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:2,flexWrap:"wrap"}}>
                  <span style={{fontSize:12,fontWeight:600}}>{c.label}</span>
                  <Chip who={t.who} names={names}/>
                  {cardName && (
                    <span style={{fontSize:9,color:"var(--pink)",background:"var(--pinkD)",padding:"1px 6px",borderRadius:99}}>
                      {cardName}
                    </span>
                  )}
                </div>
                {t.memo && <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo}</div>}
              </div>
              <span style={{fontSize:13,fontWeight:700,flexShrink:0}}>-{fmtS(t.amount)}원</span>
            </div>
          );
        })}
      </Card>
function PlanView({plan, setPlan, tx, budgets}) {
  const [editSection, setEditSection] = useState(null); // 'annual' | 'events' | number(month)
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEvent, setNewEvent] = useState({title:"", amount:"", month:MONTH, cat:"etc"});

  // ── 연간 실적 계산 ───────────────────────────────────────
  const yearTx       = tx.filter(t => t.date.startsWith(`${YEAR}`));
  const yearSpent    = yearTx.reduce((s,t) => s+t.amount, 0);
  const yearSavingGoal = plan.yearSavingGoal || 0;
  // 연간 예상 수입 (plan에서 설정)
  const yearIncome   = plan.yearIncome || 0;
  const yearActualSaving = Math.max(0, yearIncome - yearSpent);
  const savingPct    = yearSavingGoal > 0 ? Math.round(yearActualSaving / yearSavingGoal * 100) : 0;

  // 연간 지출 한도
  const yearSpendLimit = plan.yearSpendLimit || 0;
  const spendPct     = yearSpendLimit > 0 ? Math.round(yearSpent / yearSpendLimit * 100) : 0;
  const yearProjected = DAY > 0 ? Math.round(yearSpent / (MONTH*30+DAY) * 365) : 0;

  // 월별 지출 집계
  const monthlySpent = Array.from({length:12}, (_,i) => {
    const prefix = `${YEAR}-${String(i+1).padStart(2,"0")}`;
    return tx.filter(t=>t.date.startsWith(prefix)).reduce((s,t)=>s+t.amount,0);
  });

  // 이달 월간 계획 예산 (plan.monthBudgets[MONTH-1])
  const monthPlanBudgets = plan.monthBudgets || Array(12).fill(null).map(()=>({...budgets}));

  const iStyle = {
    width:"100%", background:"var(--bg4)", border:"1px solid var(--border)",
    borderRadius:10, padding:"10px 13px", color:"var(--text)", fontSize:13, outline:"none"
  };
  const numStyle = {...iStyle, textAlign:"right"};

  const updatePlan = (key, val) => setPlan(p => ({...p, [key]: val}));

  // 이벤트 추가
  const addEvent = () => {
    if (!newEvent.title || !newEvent.amount) return;
    setPlan(p => ({...p, events:[...(p.events||[]),{id:Date.now(),...newEvent,amount:parseInt(newEvent.amount)}]}));
    setNewEvent({title:"",amount:"",month:MONTH,cat:"etc"});
    setShowAddEvent(false);
  };
  const delEvent = id => setPlan(p => ({...p, events:(p.events||[]).filter(e=>e.id!==id)}));

  // 이번 달 이후 이벤트 정렬
  const upcomingEvents = [...(plan.events||[])].filter(e=>e.month >= MONTH).sort((a,b)=>a.month-b.month);
  const pastEvents     = [...(plan.events||[])].filter(e=>e.month < MONTH).sort((a,b)=>a.month-b.month);

  return (
    <div style={{padding:"0 16px 96px", overflowY:"auto", height:"100%"}}>
      <div className="u1" style={{padding:"22px 0 14px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>Annual & Monthly Plan</div>
        <div className="serif" style={{fontSize:21}}>{YEAR}년 재무 계획</div>
      </div>

      {/* ── 연간 재무 목표 ── */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ 연간 재무 목표</div>
          <button onClick={()=>setEditSection(editSection==="annual"?null:"annual")} style={{
            fontSize:11,color:"var(--gold)",background:"var(--goldD)",border:"1px solid var(--gold)",
            borderRadius:7,padding:"3px 10px",cursor:"pointer"
          }}>{editSection==="annual"?"완료":"수정"}</button>
        </div>

        {editSection==="annual" ? (
          <div>
            {[
              {label:"연간 예상 수입", key:"yearIncome",    placeholder:"예: 84000000"},
              {label:"연간 저축 목표", key:"yearSavingGoal",placeholder:"예: 36000000"},
              {label:"연간 지출 한도", key:"yearSpendLimit",placeholder:"예: 48000000"},
            ].map(f=>(
              <div key={f.key} style={{marginBottom:10}}>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>{f.label}</div>
                <input type="number" placeholder={f.placeholder}
                  value={plan[f.key]||""}
                  onChange={e=>updatePlan(f.key, parseInt(e.target.value)||0)}
                  style={numStyle}/>
              </div>
            ))}
          </div>
        ) : (
          <div>
            {/* 저축 목표 */}
            <div style={{marginBottom:16}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:16}}>💰</span>
                  <span style={{fontSize:13,fontWeight:600}}>연간 저축 목표</span>
                </div>
                <div>
                  <span style={{fontSize:14,fontWeight:700,color:"var(--green)"}}>{fmtS(yearActualSaving)}원</span>
                  <span style={{fontSize:11,color:"var(--text2)"}}> / {fmtS(yearSavingGoal)}원</span>
                </div>
              </div>
              {yearSavingGoal > 0 ? (
                <>
                  <Bar pct={savingPct} color="var(--green)" h={8}/>
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
                    <span style={{fontSize:11,color:"var(--text2)"}}>달성률 {savingPct}%</span>
                    <span style={{fontSize:11,color:savingPct>=100?"var(--green)":"var(--text2)"}}>
                      {savingPct>=100 ? "🎉 목표 달성!" : `${fmtS(yearSavingGoal-yearActualSaving)}원 남음`}
                    </span>
                  </div>
                </>
              ) : (
                <div style={{fontSize:11,color:"var(--text3)",textAlign:"center",padding:"8px 0"}}>수정 버튼을 눌러 목표를 설정하세요</div>
              )}
            </div>

            {/* 지출 한도 */}
            <div style={{paddingTop:14,borderTop:"1px solid var(--border)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:16}}>📉</span>
                  <span style={{fontSize:13,fontWeight:600}}>연간 지출 한도</span>
                </div>
                <div>
                  <span style={{fontSize:14,fontWeight:700,color:spendPct>100?"var(--red)":"var(--text)"}}>{fmtS(yearSpent)}원</span>
                  <span style={{fontSize:11,color:"var(--text2)"}}> / {fmtS(yearSpendLimit)}원</span>
                </div>
              </div>
              {yearSpendLimit > 0 ? (
                <>
                  <Bar pct={spendPct} color="var(--blue)" h={8}/>
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
                    <span style={{fontSize:11,color:"var(--text2)"}}>집행률 {spendPct}%</span>
                    <span style={{fontSize:11,color:yearProjected>yearSpendLimit?"var(--red)":"var(--green)"}}>
                      연말 예상 {fmtS(yearProjected)}원 {yearProjected>yearSpendLimit?"⚠️ 한도 초과 예상":"✓"}
                    </span>
                  </div>
                </>
              ) : (
                <div style={{fontSize:11,color:"var(--text3)",textAlign:"center",padding:"8px 0"}}>수정 버튼을 눌러 한도를 설정하세요</div>
              )}
            </div>
          </div>
        )}
      </Card>

      {/* ── 월별 지출 현황 바 ── */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ {YEAR}년 월별 지출 현황</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:6}}>
          {MONTH_NAMES.map((m,i)=>{
            const spent  = monthlySpent[i];
            const mBudget= Object.values(budgets).reduce((s,v)=>s+v,0);
            const pct    = mBudget>0 ? Math.min(spent/mBudget*100, 100) : 0;
            const isCur  = i+1 === MONTH;
            const isFuture = i+1 > MONTH;
            const hasEvents = (plan.events||[]).some(e=>e.month===i+1);
            return (
              <div key={m} style={{textAlign:"center"}}>
                <div style={{
                  height:60, background:"var(--bg3)", borderRadius:8, overflow:"hidden",
                  position:"relative", marginBottom:4,
                  border:`1px solid ${isCur?"var(--gold)":"var(--border)"}`
                }}>
                  {!isFuture && spent>0 && (
                    <div style={{
                      position:"absolute", bottom:0, left:0, right:0,
                      height:`${pct}%`,
                      background:pct>=100?"var(--red)":isCur?"var(--gold)":"var(--blue)",
                      opacity:isFuture?0.3:1,
                      transition:"height .6s ease"
                    }}/>
                  )}
                  {hasEvents && (
                    <div style={{position:"absolute",top:3,right:3,fontSize:8}}>📌</div>
                  )}
                </div>
                <div style={{fontSize:9,color:isCur?"var(--gold)":"var(--text2)",fontWeight:isCur?700:400}}>{m}</div>
                {!isFuture && spent>0 && (
                  <div style={{fontSize:8,color:"var(--text3)"}}>{fmtS(spent)}</div>
                )}
              </div>
            );
          })}
        </div>
        <div style={{display:"flex",gap:14,marginTop:12,paddingTop:10,borderTop:"1px solid var(--border)"}}>
          {[{c:"var(--gold)",l:"이번 달"},{c:"var(--blue)",l:"지출 있음"},{c:"var(--red)",l:"예산 초과"}].map(l=>(
            <div key={l.l} style={{display:"flex",alignItems:"center",gap:4}}>
              <div style={{width:7,height:7,borderRadius:2,background:l.c}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.l}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* ── 이달 카테고리별 플래닝 ── */}
      <Card className="u4" style={{padding:"18px",marginBottom:10}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ {MONTH}월 카테고리별 플래닝</div>
          <button onClick={()=>setEditSection(editSection==="month"?null:"month")} style={{
            fontSize:11,color:"var(--blue)",background:"var(--blueD)",border:"1px solid var(--blue)",
            borderRadius:7,padding:"3px 10px",cursor:"pointer"
          }}>{editSection==="month"?"완료":"조정"}</button>
        </div>
        <div style={{fontSize:11,color:"var(--text3)",marginBottom:14}}>
          현재 예산 설정과 별개로 이달 목표를 따로 잡을 수 있어요
        </div>

        {CATS.map(cat=>{
          const planKey  = `monthPlan_${YEAR}_${MONTH}_${cat.id}`;
          const planAmt  = plan[planKey] ?? (budgets[cat.id]||0);
          const spent    = tx.filter(t=>t.cat===cat.id&&t.date.startsWith(`${YEAR}-${String(MONTH).padStart(2,"0")}`)).reduce((s,t)=>s+t.amount,0);
          const pct      = planAmt > 0 ? Math.round(spent/planAmt*100) : 0;
          if(!planAmt && !spent) return null;
          return (
            <div key={cat.id} style={{marginBottom:14}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:14}}>{cat.icon}</span>
                  <span style={{fontSize:12,fontWeight:500}}>{cat.label}</span>
                  <span style={{fontSize:11}}>{pct>100?"🔴":pct>85?"🟡":"🟢"}</span>
                </div>
                {editSection==="month" ? (
                  <input type="number" value={planAmt||""}
                    onChange={e=>updatePlan(planKey, parseInt(e.target.value)||0)}
                    style={{width:90,background:"var(--bg4)",border:`1px solid ${cat.color}66`,
                      borderRadius:8,padding:"4px 8px",color:cat.color,fontSize:12,
                      fontWeight:700,textAlign:"right",outline:"none"}}/>
                ) : (
                  <div style={{display:"flex",alignItems:"baseline",gap:4}}>
                    <span style={{fontSize:12,fontWeight:700}}>{fmtS(spent)}</span>
                    <span style={{fontSize:10,color:"var(--text2)"}}>/ {fmtS(planAmt)}원</span>
                    <span style={{fontSize:11,fontWeight:700,color:pct>100?"var(--red)":pct>85?"var(--gold)":"var(--green)",minWidth:32,textAlign:"right"}}>{pct}%</span>
                  </div>
                )}
              </div>
              {editSection!=="month" && <Bar pct={pct} color={cat.color} h={4}/>}
            </div>
          );
        })}
      </Card>

      {/* ── 큰 지출 이벤트 예고 ── */}
      <Card className="u5" style={{overflow:"hidden",marginBottom:10}}>
        <div style={{padding:"14px 16px 10px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ 큰 지출 이벤트 예고</div>
          <span style={{fontSize:11,color:"var(--text2)"}}>{(plan.events||[]).length}개</span>
        </div>

        {/* 예정 이벤트 */}
        {upcomingEvents.length===0 && pastEvents.length===0 ? (
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            예정된 큰 지출을 미리 등록해두세요<br/>
            <span style={{fontSize:11}}>냉장고 구매, 여행, 경조사 등</span>
          </div>
        ) : (
          <>
            {upcomingEvents.map(e=>{
              const c = CAT[e.cat]||CATS[8];
              const isPast2 = e.month < MONTH;
              return (
                <div key={e.id} style={{
                  padding:"11px 15px",borderTop:"1px solid var(--border)",
                  display:"flex",alignItems:"center",gap:10
                }}>
                  <div style={{
                    width:36,height:36,borderRadius:10,flexShrink:0,
                    background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16
                  }}>{c.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:600,marginBottom:2}}>{e.title}</div>
                    <div style={{fontSize:10,color:"var(--text2)"}}>
                      {MONTH_NAMES[e.month-1]} · {c.label}
                    </div>
                  </div>
                  <div style={{textAlign:"right",marginRight:6}}>
                    <div style={{fontSize:14,fontWeight:700}}>{fmtS(e.amount)}원</div>
                    <div style={{fontSize:10,color:e.month===MONTH?"var(--red)":"var(--text2)"}}>
                      {e.month===MONTH?"이번달!":e.month > MONTH?`${e.month-MONTH}개월 후`:""}
                    </div>
                  </div>
                  <button onClick={()=>delEvent(e.id)} style={{
                    width:24,height:24,borderRadius:6,border:"none",cursor:"pointer",
                    background:"transparent",color:"var(--text3)",fontSize:12,flexShrink:0
                  }}>✕</button>
                </div>
              );
            })}
            {pastEvents.length>0 && (
              <div style={{padding:"8px 15px",background:"var(--bg3)"}}>
                <div style={{fontSize:10,color:"var(--text3)"}}>지난 이벤트 {pastEvents.length}개</div>
              </div>
            )}
          </>
        )}

        {/* 이벤트 추가 */}
        {showAddEvent ? (
          <div style={{padding:"14px 15px",borderTop:"1px solid var(--border)"}}>
            <input placeholder="이벤트명 (예: 냉장고 구매)" value={newEvent.title}
              onChange={e=>setNewEvent(v=>({...v,title:e.target.value}))}
              style={{...iStyle,marginBottom:8}}/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
              <div>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>예상 금액</div>
                <input type="number" placeholder="금액" value={newEvent.amount}
                  onChange={e=>setNewEvent(v=>({...v,amount:e.target.value}))}
                  style={iStyle}/>
              </div>
              <div>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>예정 월</div>
                <select value={newEvent.month} onChange={e=>setNewEvent(v=>({...v,month:+e.target.value}))}
                  style={{...iStyle,cursor:"pointer"}}>
                  {MONTH_NAMES.map((m,i)=>(
                    <option key={i} value={i+1}>{m}</option>
                  ))}
                </select>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:10}}>
              {CATS.slice(0,6).map(c=>(
                <button key={c.id} onClick={()=>setNewEvent(v=>({...v,cat:c.id}))} style={{
                  background:newEvent.cat===c.id?c.color+"25":"var(--bg4)",
                  border:`1px solid ${newEvent.cat===c.id?c.color+"66":"var(--border)"}`,
                  borderRadius:10,padding:"8px 4px",cursor:"pointer",
                  display:"flex",flexDirection:"column",alignItems:"center",gap:3
                }}>
                  <span style={{fontSize:15}}>{c.icon}</span>
                  <span style={{fontSize:9,color:"var(--text2)"}}>{c.label}</span>
                </button>
              ))}
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setShowAddEvent(false)} style={{
                flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",
                borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12
              }}>취소</button>
              <button onClick={addEvent} style={{
                flex:2,padding:"11px",background:"var(--purpleD)",border:"1px solid var(--purple)",
                borderRadius:11,color:"var(--purple)",fontWeight:700,fontSize:12,cursor:"pointer"
              }}>추가</button>
            </div>
          </div>
        ) : (
          <button onClick={()=>setShowAddEvent(true)} style={{
            display:"block",width:"100%",padding:"12px",
            background:"transparent",border:"none",borderTop:"1px solid var(--border)",
            color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600
          }}>+ 이벤트 추가</button>
        )}
      </Card>
    </div>
  );
}

function ReportView({tx, budgets, fixed, install, names, cards, plan, setPlan}) {
  const [tab, setTab] = useState("report");
  return (
    <div style={{height:"100%",display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",gap:6,padding:"14px 16px 0",background:"var(--bg)",flexShrink:0}}>
        {[{id:"report",l:"📊 리포트"},{id:"calendar",l:"📅 캘린더"},{id:"plan",l:"🎯 계획"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flex:1,padding:"10px 6px",borderRadius:12,cursor:"pointer",
            fontWeight:700,fontSize:11,
            background:tab===t.id?"var(--goldD)":"var(--bg2)",
            border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,
            color:tab===t.id?"var(--gold)":"var(--text2)",
            transition:"all .15s"
          }}>{t.l}</button>
        ))}
      </div>
      <div style={{flex:1,overflow:"hidden"}}>
        {tab==="report"   && <ReportContent tx={tx} budgets={budgets} fixed={fixed} install={install} names={names}/>}
        {tab==="calendar" && <CalendarView  tx={tx} cards={cards} names={names} budgets={budgets}/>}
        {tab==="plan"     && <PlanView      plan={plan} setPlan={setPlan} tx={tx} budgets={budgets}/>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// REPORT CONTENT (기존 ReportView 내용)
// ─────────────────────────────────────────────────────────────
function StackedBar({data,total,height=24,showLegend=false}){
  return(
    <div>
      <div style={{display:"flex",height,borderRadius:10,overflow:"hidden"}}>
        {data.filter(d=>d.amount>0).map(d=>{
          const c=CAT[d.cat]; const w=total>0?d.amount/total*100:0;
          return <div key={d.cat} style={{width:`${w}%`,background:c?.color||"#888",transition:"width .7s ease",minWidth:w>1?1:0}} title={`${c?.label} ${Math.round(w)}%`}/>;
        })}
      </div>
      {showLegend&&(
        <div style={{display:"flex",flexWrap:"wrap",gap:"5px 12px",marginTop:8}}>
          {data.filter(d=>d.amount>0&&total>0&&d.amount/total>.03).map(d=>{
            const c=CAT[d.cat]; const p=Math.round(d.amount/total*100);
            return(<div key={d.cat} style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:6,height:6,borderRadius:1,background:c?.color}}/><span style={{fontSize:10,color:"var(--text2)"}}>{c?.label} {p}%</span></div>);
          })}
        </div>
      )}
    </div>
  );
}-e 
export { ReportView };
