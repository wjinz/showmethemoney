import { useState, useCallback, useMemo, useRef } from "react";
import { Ring, Bar, Chip, Card, SectionHeader, SliderRow } from "../components/shared";
import { CATS, CAT, MONTH_NAMES, CARD_PRESETS_COLOR } from "../constants";
import { fmt, fmtS, DAY, DAYS, MONTH, YEAR, today_str, getBillingPeriod, toDateStr, fmtMonthDay, fmtPeriodLabel } from "../utils";

import { CATS, INIT_BUDGETS, DEFAULT_SLIDER_CFG } from "../constants";

function SettingsView({names,setNames,budgets,setBudgets,sliderCfg,setSliderCfg,theme,setTheme,resetAll,householdId,myRole,leaveHousehold}){
  const [n,setN]     = useState({...names});
  const [tab,setTab] = useState("budget");
  const [cfg,setCfg] = useState({...sliderCfg});
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const budgetMax    = sliderCfg.budgetSliderMax;
  const iStyle       = {width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"9px 13px",color:"var(--text)",fontSize:13,outline:"none"};

  const saveCfg=()=>setSliderCfg({...cfg});

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub="Settings" title="설정"/></div>

      {/* 테마 선택 */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 화면 모드</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          {[
            {id:"dark", label:"🌙 다크 모드", desc:"어두운 배경"},
            {id:"light",label:"☀️ 라이트 모드",desc:"밝은 배경"},
          ].map(t=>(
            <button key={t.id} onClick={()=>setTheme(t.id)} style={{
              padding:"14px 10px",borderRadius:14,cursor:"pointer",textAlign:"center",
              background:theme===t.id?"var(--goldD)":"var(--bg3)",
              border:`2px solid ${theme===t.id?"var(--gold)":"var(--border)"}`,
              transition:"all .2s"
            }}>
              <div style={{fontSize:22,marginBottom:6}}>{t.label.split(" ")[0]}</div>
              <div style={{fontSize:12,fontWeight:700,color:theme===t.id?"var(--gold)":"var(--text2)"}}>{t.label.split(" ").slice(1).join(" ")}</div>
              <div style={{fontSize:10,color:"var(--text3)",marginTop:2}}>{t.desc}</div>
            </button>
          ))}
        </div>
      </Card>
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 이름 설정</div>
        {["husband","wife"].map(w=>(
          <div key={w} style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>{w==="husband"?"남편":"와이프"}</div>
            <input value={n[w]} onChange={e=>setN(v=>({...v,[w]:e.target.value}))} style={iStyle}/>
          </div>
        ))}
        <button onClick={()=>setNames(n)} style={{width:"100%",marginTop:6,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>저장</button>
      </Card>

      {/* 가정 연결 정보 */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 가정 연결 정보</div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>가정 코드</div>
            <div style={{fontSize:24,fontWeight:700,letterSpacing:".12em",color:"var(--gold)"}}>{householdId}</div>
          </div>
          <div style={{
            background:myRole==="husband"?"var(--hD)":"var(--wD)",
            color:myRole==="husband"?"var(--h)":"var(--w)",
            padding:"8px 16px",borderRadius:99,fontWeight:700,fontSize:13
          }}>
            {myRole==="husband"?names.husband:names.wife}
          </div>
        </div>
        <div style={{
          background:"var(--bg3)",borderRadius:12,padding:"12px 14px",
          fontSize:12,color:"var(--text2)",lineHeight:1.7,marginBottom:12
        }}>
          이 코드를 와이프에게 공유하세요.<br/>
          앱 첫 화면에서 <strong style={{color:"var(--text)"}}>코드로 참여하기</strong> 선택 후<br/>
          <strong style={{color:"var(--gold)"}}>{householdId}</strong>를 입력하면 연결됩니다.
        </div>
        <button onClick={()=>{
          if(window.confirm("가계부에서 나가면 이 기기의 연결이 끊깁니다.\n데이터는 유지됩니다. 나가시겠어요?"))
            leaveHousehold();
        }} style={{
          width:"100%",padding:"10px",background:"transparent",
          border:"1px solid var(--border2)",borderRadius:10,
          color:"var(--text3)",fontSize:12,cursor:"pointer"
        }}>다른 코드로 연결하기</button>
      </Card>
      <div className="u3" style={{display:"flex",gap:6,marginBottom:12}}>
        {[{id:"budget",l:"예산 슬라이더"},{id:"sim",l:"시뮬레이터 초기값"},{id:"pace",l:"Pace 설정"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px 4px",borderRadius:10,cursor:"pointer",fontWeight:700,fontSize:11,background:tab===t.id?"var(--goldD)":"transparent",border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,color:tab===t.id?"var(--goldL)":"var(--text2)"}}>{t.l}</button>
        ))}
      </div>

      {/* ── 예산 슬라이더 탭 ── */}
      {tab==="budget"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ 카테고리별 예산</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:14}}>슬라이더 최대값: {fmtS(budgetMax)}원 (하단 Pace 설정에서 변경)</div>
          {/* Live stacked bar */}
          <div style={{display:"flex",height:20,borderRadius:9,overflow:"hidden",marginBottom:12}}>
            {CATS.map(c=>{
              const pct=totalBudget>0?(budgets[c.id]||0)/totalBudget*100:0;
              return <div key={c.id} style={{width:`${pct}%`,background:c.color,transition:"width .3s ease",minWidth:pct>0?2:0}} title={`${c.label} ${Math.round(pct)}%`}/>;
            })}
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:"4px 10px",marginBottom:16}}>
            {CATS.filter(c=>totalBudget>0&&(budgets[c.id]||0)/totalBudget>.02).map(c=>(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:4}}>
                <div style={{width:6,height:6,borderRadius:1,background:c.color}}/>
                <span style={{fontSize:9,color:"var(--text2)"}}>{c.label} {Math.round((budgets[c.id]||0)/totalBudget*100)}%</span>
              </div>
            ))}
          </div>
          {CATS.map(c=>{
            const val = budgets[c.id]||0;
            const pct = totalBudget>0 ? Math.round(val/totalBudget*100) : 0;
            return(
              <div key={c.id} style={{marginBottom:18}}>
                {/* 라벨 + 직접입력 */}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <div style={{display:"flex",alignItems:"center",gap:6}}>
                    <span style={{fontSize:15}}>{c.icon}</span>
                    <span style={{fontSize:13,fontWeight:500}}>{c.label}</span>
                    <span style={{fontSize:10,color:"var(--text3)",background:"var(--bg3)",borderRadius:99,padding:"1px 6px"}}>{pct}%</span>
                  </div>
                  <input
                    type="number"
                    value={val===0?"":val}
                    placeholder="0"
                    onChange={e=>{
                      const v=parseInt(e.target.value)||0;
                      setBudgets(b=>({...b,[c.id]:v}));
                    }}
                    style={{
                      width:100,background:"var(--bg4)",border:"1px solid var(--border2)",
                      borderRadius:8,padding:"5px 9px",fontSize:13,fontWeight:700,
                      color:c.color,textAlign:"right",outline:"none"
                    }}
                  />
                </div>
                {/* 슬라이더 */}
                <input
                  type="range"
                  min={0} max={budgetMax} step={10000}
                  value={Math.min(val, budgetMax)}
                  onChange={e=>setBudgets(b=>({...b,[c.id]:+e.target.value}))}
                  style={{background:`linear-gradient(to right, ${c.color} 0%, ${c.color} ${Math.min(val,budgetMax)/budgetMax*100}%, var(--track) ${Math.min(val,budgetMax)/budgetMax*100}%, var(--track) 100%)`}}
                />
              </div>
            );
          })}
          <div style={{paddingTop:14,borderTop:"1px solid var(--border)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>총 예산</span>
            <span style={{fontSize:17,fontWeight:700,color:"var(--goldL)"}}>{fmt(totalBudget)}</span>
          </div>
          <button onClick={()=>setBudgets({...INIT_BUDGETS})} style={{width:"100%",marginTop:12,padding:"11px",background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:11,color:"var(--red)",fontWeight:700,fontSize:12,cursor:"pointer"}}>예산 전체 초기화</button>
        </Card>
      )}

      {/* ── 시뮬레이터 초기값 탭 ── */}
      {tab==="sim"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ 시뮬레이터 초기값 설정</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16}}>시뮬레이터 탭 진입 시 기본값으로 사용됩니다</div>
          {[
            {key:"simInitAmt",  l:"초기 투자금",    min:1000000,  max:100000000, step:1000000, fv:undefined},
            {key:"simMonthly",  l:"월 저축액",      min:100000,   max:3000000,   step:50000,  fv:undefined},
            {key:"simRate",     l:"연 수익률",      min:1,        max:20,        step:0.5,    fv:(v)=>v.toFixed(1)+"%"},
            {key:"simYears",    l:"투자 기간",      min:1,        max:40,        step:1,      fv:(v)=>v+"년"},
            {key:"simGoal",     l:"목표 금액",      min:10000000, max:1000000000,step:10000000,fv:(v)=>fmtS(v)+"원"},
          ].map(r=>(
            <SliderRow key={r.key}
              label={r.l}
              value={cfg[r.key]}
              min={r.min} max={r.max} step={r.step}
              onChange={v=>setCfg(c=>({...c,[r.key]:v}))}
              fillColor="var(--blue)"
              formatVal={r.fv}
            />
          ))}
          <div style={{display:"flex",gap:8,marginTop:4}}>
            <button onClick={()=>setCfg({...sliderCfg})} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>되돌리기</button>
            <button onClick={saveCfg} style={{flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>초기값 저장</button>
          </div>
        </Card>
      )}

      {/* ── Pace 설정 탭 ── */}
      {tab==="pace"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ Pace 슬라이더 범위 설정</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16}}>홈 화면 일평균 목표 지출 슬라이더의 최대값을 설정합니다</div>
          <SliderRow
            label="일 지출 슬라이더 최대값"
            value={cfg.paceMaxDaily}
            min={50000} max={1000000} step={50000}
            onChange={v=>setCfg(c=>({...c,paceMaxDaily:v}))}
            fillColor="var(--gold)"
            formatVal={v=>fmtS(v)+"원/일"}
          />
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16,marginTop:-4}}>예산 슬라이더 최대값 (카테고리별)</div>
          <SliderRow
            label="예산 슬라이더 최대값"
            value={cfg.budgetSliderMax}
            min={500000} max={5000000} step={100000}
            onChange={v=>setCfg(c=>({...c,budgetSliderMax:v}))}
            fillColor="var(--purple)"
            formatVal={v=>fmtS(v)+"원"}
          />
          <div style={{display:"flex",gap:8,marginTop:8}}>
            <button onClick={()=>setCfg({...sliderCfg})} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>되돌리기</button>
            <button onClick={saveCfg} style={{flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>저장</button>
          </div>
          <button onClick={()=>{setCfg({...DEFAULT_SLIDER_CFG});setSliderCfg({...DEFAULT_SLIDER_CFG});}} style={{width:"100%",marginTop:10,padding:"10px",background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:10,color:"var(--red)",fontWeight:700,fontSize:12,cursor:"pointer"}}>모든 슬라이더 공장초기화</button>
        </Card>
      )}

      <div style={{textAlign:"center",padding:"20px 0",color:"var(--text3)",fontSize:10,letterSpacing:".06em"}}>가정 경영 가계부 v5.0</div>

      {/* 데이터 초기화 */}
      <Card style={{padding:"18px",marginBottom:20,border:"1px solid var(--redD)"}}>
        <div style={{fontSize:11,color:"var(--red)",letterSpacing:".06em",marginBottom:10}}>■ 데이터 초기화</div>
        <div style={{fontSize:12,color:"var(--text2)",marginBottom:14,lineHeight:1.6}}>
          지출 내역, 고정비, 할부 내역을 모두 삭제합니다.<br/>
          예산과 설정값은 유지됩니다.
        </div>
        <button onClick={()=>{if(window.confirm("모든 내역을 초기화할까요? 이 작업은 되돌릴 수 없습니다.")) resetAll();}} style={{
          width:"100%",padding:"12px",background:"var(--redD)",
          border:"1px solid var(--red)",borderRadius:11,
          color:"var(--red)",fontWeight:700,fontSize:13,cursor:"pointer"
        }}>모든 내역 초기화</button>
      </Card>
    </div>
  );
}
-e 
export { SettingsView };
