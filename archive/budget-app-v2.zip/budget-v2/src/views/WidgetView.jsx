import { fmt, fmtS, MONTH, YEAR } from "../utils";
import { Card } from "../components/shared";

function WidgetView({ tx, budgets, names, onClose }) {
  const totalBudget = Object.values(budgets).reduce((s, v) => s + v, 0);
  const monthStr    = `${YEAR}-${String(MONTH).padStart(2,"0")}`;
  const monthSpent  = tx.filter(t => t.date.startsWith(monthStr)).reduce((s,t) => s+t.amount, 0);
  const pct         = totalBudget > 0 ? Math.round(monthSpent / totalBudget * 100) : 0;

  return (
    <div style={{
      position:"fixed", inset:0, zIndex:300,
      background:"rgba(0,0,0,.8)", backdropFilter:"blur(10px)",
      display:"flex", alignItems:"center", justifyContent:"center",
      padding:"24px"
    }} onClick={onClose}>
      <Card style={{ padding:"28px", width:"100%", maxWidth:340, textAlign:"center" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ fontSize:11, color:"var(--text2)", marginBottom:6 }}>{YEAR}년 {MONTH}월 현황</div>
        <div style={{ fontSize:32, fontWeight:700, marginBottom:4 }}>{fmtS(monthSpent)}원</div>
        <div style={{ fontSize:13, color:"var(--text2)", marginBottom:16 }}>
          예산 {fmtS(totalBudget)}원의 <span style={{color: pct>100?"var(--red)":"var(--green)", fontWeight:700}}>{pct}%</span>
        </div>
        <button onClick={onClose} style={{
          width:"100%", padding:"11px", background:"var(--bg3)",
          border:"1px solid var(--border)", borderRadius:12,
          color:"var(--text2)", cursor:"pointer", fontSize:13
        }}>닫기</button>
      </Card>
    </div>
  );
}

export { WidgetView };
