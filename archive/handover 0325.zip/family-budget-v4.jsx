import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

// ─────────────────────────────────────────────────────────────
// GLOBAL STYLES
// ─────────────────────────────────────────────────────────────
const G = `
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Noto+Sans+KR:wght@400;500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}

/* ── 다크 모드 (기본) ── */
:root{
  --bg:#09090f;--bg2:#0f1018;--bg3:#15161f;--bg4:#1c1d28;
  --border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.13);
  --gold:#c8a84b;--goldL:#e2c97e;--goldD:rgba(200,168,75,0.13);
  --red:#d95f5f;--redD:rgba(217,95,95,0.13);
  --green:#4dab87;--greenD:rgba(77,171,135,0.13);
  --blue:#5c8de8;--blueD:rgba(92,141,232,0.13);
  --pink:#d97fa8;--pinkD:rgba(217,127,168,0.13);
  --purple:#9b7ee0;--purpleD:rgba(155,126,224,0.13);
  --text:#eeeae0;--text2:#9a9490;--text3:#5a5650;
  --h:var(--blue);--hD:var(--blueD);
  --w:var(--pink);--wD:var(--pinkD);
  --nav-bg:rgba(9,9,15,0.97);
  --track:rgba(255,255,255,0.08);
  --dim:rgba(255,255,255,0.04);
}

/* ── 라이트 모드 ── */
.light{
  --bg:#f0ede8;--bg2:#ffffff;--bg3:#e6e2dc;--bg4:#d8d4cc;
  --border:rgba(0,0,0,0.09);--border2:rgba(0,0,0,0.16);
  --gold:#8a6a00;--goldL:#6a5000;--goldD:rgba(138,106,0,0.1);
  --red:#aa2020;--redD:rgba(170,32,32,0.1);
  --green:#0f6e42;--greenD:rgba(15,110,66,0.1);
  --blue:#1448a8;--blueD:rgba(20,72,168,0.1);
  --pink:#8c2858;--pinkD:rgba(140,40,88,0.1);
  --purple:#502896;--purpleD:rgba(80,40,150,0.1);
  /* 텍스트 — 라이트는 확실히 진하게 */
  --text:#141210;
  --text2:#44403c;
  --text3:#80786e;
  --h:var(--blue);--hD:var(--blueD);
  --w:var(--pink);--wD:var(--pinkD);
  --nav-bg:rgba(240,237,232,0.97);
  --track:rgba(0,0,0,0.10);
  --dim:rgba(0,0,0,0.04);
}

/* 라이트 슬라이더 thumb */
.light input[type=range]::-webkit-slider-thumb{
  background:var(--bg2);border:3px solid var(--bg4);
  box-shadow:0 2px 8px rgba(0,0,0,0.18);
}
.light input[type=range]::-moz-range-thumb{
  background:var(--bg2);border:3px solid var(--bg4);
}

/* ★ body는 기본 배경만 — 텍스트 색은 .app-root가 관리 */
body{background:var(--bg);font-family:'Noto Sans KR',sans-serif;font-size:14px;-webkit-font-smoothing:antialiased}

/* ★ .app-root: 모든 텍스트 색상이 여기서 시작 — 라이트/다크 모두 정확히 cascade */
.app-root{color:var(--text);background:var(--bg)}

.serif{font-family:'DM Serif Display',serif}
input,button,textarea{font-family:'Noto Sans KR',sans-serif;color:var(--text)}
input::placeholder{color:var(--text3)}
::-webkit-scrollbar{width:3px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}

input[type=range]{
  -webkit-appearance:none;appearance:none;
  width:100%;height:6px;border-radius:99px;
  outline:none;cursor:pointer;border:none;
}
input[type=range]::-webkit-slider-thumb{
  -webkit-appearance:none;appearance:none;
  width:22px;height:22px;border-radius:50%;
  background:#fff;border:3px solid var(--bg);
  box-shadow:0 2px 10px rgba(0,0,0,.4);
  cursor:pointer;transition:transform .15s;
}
input[type=range]::-webkit-slider-thumb:active{transform:scale(1.2)}
input[type=range]::-moz-range-thumb{
  width:20px;height:20px;border-radius:50%;
  background:#fff;border:3px solid var(--bg);
  box-shadow:0 2px 10px rgba(0,0,0,.4);cursor:pointer;
}
input[type=range]::-moz-range-track{height:6px;border-radius:99px;background:var(--track)}

@keyframes up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@keyframes spin{to{transform:rotate(360deg)}}
.u1{animation:up .35s ease both}
.u2{animation:up .35s .07s ease both}
.u3{animation:up .35s .14s ease both}
.u4{animation:up .35s .21s ease both}
.u5{animation:up .35s .28s ease both}
`;

// ─────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────
const CATS = [
  {id:"food",     label:"식비",      icon:"🍽", color:"#d4845a"},
  {id:"housing",  label:"주거/관리",  icon:"🏠", color:"#d4b84a"},
  {id:"education",label:"교육",      icon:"📚", color:"#9b7ee0"},
  {id:"transport",label:"교통",      icon:"🚇", color:"#5c8de8"},
  {id:"medical",  label:"의료",      icon:"💊", color:"#4dab87"},
  {id:"culture",  label:"문화/여가", icon:"🎬", color:"#4dccd4"},
  {id:"clothing", label:"의류",      icon:"👗", color:"#d97fa8"},
  {id:"sub",      label:"구독",      icon:"📱", color:"#7dd47a"},
  {id:"etc",      label:"기타",      icon:"📦", color:"#6a6560"},
];
const CAT = Object.fromEntries(CATS.map(c=>[c.id,c]));

// 예산 기본값 — 처음 설치 시 사용
const INIT_BUDGETS = {
  food:500000,transport:150000,medical:200000,education:300000,
  housing:600000,culture:150000,clothing:100000,sub:80000,etc:80000
};
// 슬라이더 전체 초기값 — 설정탭에서 관리
const DEFAULT_SLIDER_CFG = {
  // Pace 슬라이더
  paceMaxDaily: 300000,    // 최대 일 지출 (원)
  // 재무 시뮬레이터
  simInitAmt:   10000000,
  simMonthly:   500000,
  simRate:      5,
  simYears:     20,
  simGoal:      300000000,
  // 예산 슬라이더 최대값
  budgetSliderMax: 2000000,
};

const EMPTY_TX      = [];
const EMPTY_FIXED   = [];
const EMPTY_INSTALL = [];
const EMPTY_CARDS   = [];

// ─────────────────────────────────────────────────────────────
// 날짜 상수 — 앱 전역에서 사용
// ─────────────────────────────────────────────────────────────
const NOW   = new Date();
const DAYS  = new Date(NOW.getFullYear(),NOW.getMonth()+1,0).getDate();
const DAY   = NOW.getDate();
const MONTH = NOW.getMonth()+1;
const YEAR  = NOW.getFullYear();
const today_str = () => NOW.toISOString().split("T")[0];
const fmt  = n => n.toLocaleString("ko-KR")+"원";
const fmtS = n => {
  if(n>=100000000) return (n/100000000).toFixed(1)+"억";
  if(n>=10000)     return Math.round(n/10000)+"만";
  return n.toLocaleString();
};

// ─────────────────────────────────────────────────────────────
// ★ 카드 정산 핵심 알고리즘
// ─────────────────────────────────────────────────────────────
//
// 한국 신용카드 정산 패턴:
//   A형) 당월 X일 ~ 당월 말일 → 다음달 Y일 결제  (e.g. 1일~말일 → 다음달 15일)
//   B형) 당월 X일 ~ 다음달 Z일 → 다음달 Y일 결제  (e.g. 13일~다음달14일 → 다음달 23일)
//
// billingEndNextMonth = false → A형
// billingEndNextMonth = true  → B형

function getBillingPeriod(card, today = NOW) {
  const { billingStartDay, billingEndDay, billingEndNextMonth, paymentDay } = card;
  const y = today.getFullYear();
  const m = today.getMonth(); // 0-indexed
  const d = today.getDate();

  let sY, sM, eY, eM, pY, pM;

  if (billingEndNextMonth) {
    // B형: 당월 X일 ~ 다음달 Z일
    if (d >= billingStartDay) {
      // 오늘이 시작일 이후 → 이번달이 시작월
      sY=y; sM=m;
      eY=(m===11?y+1:y); eM=(m===11?0:m+1);
    } else {
      // 오늘이 시작일 이전 → 지난달이 시작월
      sY=(m===0?y-1:y); sM=(m===0?11:m-1);
      eY=y; eM=m;
    }
    pY=eY; pM=eM; // 결제일은 마감월과 같은달
  } else {
    // A형: 당월 X일 ~ 당월 Z일
    if (d >= billingStartDay) {
      sY=y; sM=m; eY=y; eM=m;
      pY=(m===11?y+1:y); pM=(m===11?0:m+1);
    } else {
      sY=(m===0?y-1:y); sM=(m===0?11:m-1);
      eY=sY; eM=sM;
      pY=y; pM=m;
    }
  }

  const cycleStart = new Date(sY, sM, billingStartDay);
  // billingEndDay가 31 등일 때 월 말일 처리
  const lastDayOfEndMonth = new Date(eY, eM+1, 0).getDate();
  const actualEndDay = Math.min(billingEndDay, lastDayOfEndMonth);
  const cycleEnd  = new Date(eY, eM, actualEndDay);
  const payDate   = new Date(pY, pM, paymentDay);

  const msDay = 1000*60*60*24;
  const daysUntilPay = Math.ceil((payDate - today) / msDay);

  return { cycleStart, cycleEnd, payDate, daysUntilPay };
}

function toDateStr(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function fmtMonthDay(d) {
  return `${d.getMonth()+1}월 ${d.getDate()}일`;
}
function fmtPeriodLabel(s, e) {
  const sm=s.getMonth()+1, sd=s.getDate(), em=e.getMonth()+1, ed=e.getDate();
  return sm===em ? `${sm}월 ${sd}일 ~ ${ed}일` : `${sm}/${sd} ~ ${em}/${ed}`;
}

const CARD_PRESETS_COLOR = ["#1c2340","#2d1a3a","#1a3020","#3a1a1a","#2a2a18","#1a2a3a","#3a2a10","#282828"];
const CARD_ICONS_LIST    = ["💳","🏦","💰","🪙","🎴","⭐","🔵","🔴"];

// ─────────────────────────────────────────────────────────────
// ★ 핵심: 통일된 SliderRow — CSS gradient fill (thumb 정렬 완벽)
// ─────────────────────────────────────────────────────────────
function SliderRow({ label, value, min, max, step=1000, onChange, fillColor, formatVal, showReset=false, onReset, defaultValue }) {
  // pct 계산: value를 min~max 사이로 클램프한 뒤 비율
  const clamped = Math.min(Math.max(value, min), max);
  const pct     = max > min ? ((clamped - min) / (max - min)) * 100 : 0;
  const fill    = fillColor || "var(--gold)";
  // CSS gradient로 fill (no overlay div, no z-index issue)
  const trackBg = `linear-gradient(to right, ${fill} 0%, ${fill} ${pct}%, var(--track) ${pct}%, var(--track) 100%)`;

  return (
    <div style={{marginBottom:16}}>
      {/* Label row */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
        <span style={{fontSize:12,color:"var(--text2)"}}>{label}</span>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          {showReset && (
            <button onClick={onReset} style={{
              fontSize:10,color:"var(--text3)",background:"var(--dim)",
              border:"1px solid var(--border)",borderRadius:6,padding:"2px 7px",cursor:"pointer"
            }}>초기화</button>
          )}
          <span style={{fontSize:15,fontWeight:700,color:fill,letterSpacing:"-.01em"}}>
            {formatVal ? formatVal(clamped) : fmt(clamped)}
          </span>
        </div>
      </div>
      {/* Track */}
      <input
        type="range"
        min={min} max={max} step={step}
        value={clamped}
        onChange={e => onChange(+e.target.value)}
        style={{ background: trackBg }}
      />
      {/* Min/max labels */}
      <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
        <span style={{fontSize:10,color:"var(--text3)"}}>
          {formatVal ? formatVal(min) : fmtS(min)+"원"}
        </span>
        <span style={{fontSize:10,color:"var(--text3)"}}>
          {formatVal ? formatVal(max) : fmtS(max)+"원"}
        </span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SHARED COMPONENTS
// ─────────────────────────────────────────────────────────────
function Ring({pct=0,size=104,stroke=6,children}){
  const r=(size-stroke)/2, c=2*Math.PI*r, p=Math.min(pct,100)/100*c;
  const color=pct>100?"var(--red)":pct>85?"#d4b84a":"var(--green)";
  return(
    <div style={{position:"relative",width:size,height:size,flexShrink:0}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)",position:"absolute"}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
          strokeDasharray={`${p} ${c}`} strokeLinecap="round" style={{transition:"stroke-dasharray .7s"}}/>
      </svg>
      <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
        {children}
      </div>
    </div>
  );
}
function Bar({pct=0,color="#888",h=5}){
  return(
    <div style={{background:"var(--track)",borderRadius:99,height:h,overflow:"hidden"}}>
      <div style={{width:`${Math.min(pct,100)}%`,height:"100%",background:pct>100?"var(--red)":color,borderRadius:99,transition:"width .7s ease",minWidth:pct>0?2:0}}/>
    </div>
  );
}
function Chip({who,names}){
  const isH=who==="husband";
  return <span style={{fontSize:10,fontWeight:700,background:isH?"var(--hD)":"var(--wD)",color:isH?"var(--h)":"var(--w)",padding:"2px 7px",borderRadius:99,flexShrink:0}}>{isH?names.husband:names.wife}</span>;
}
function Card({children,style={},className=""}){
  return <div className={className} style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:18,...style}}>{children}</div>;
}
function SectionHeader({sub,title}){
  return(
    <div style={{padding:"22px 0 14px"}}>
      <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>{sub}</div>
      <div className="serif" style={{fontSize:21}}>{title}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// HOME VIEW
// ─────────────────────────────────────────────────────────────
function HomeView({tx,budgets,fixed,install,names,onAdd,sliderCfg}){
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const fixedTotal   = fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal = install.reduce((s,i)=>s+i.monthly,0);
  const totalSpent   = tx.reduce((s,t)=>s+t.amount,0);
  const pct          = Math.round(totalSpent/totalBudget*100);
  const paceTarget   = Math.round(DAY/DAYS*totalBudget);
  const pacePct      = paceTarget>0?Math.round(totalSpent/paceTarget*100):0;
  const remaining    = totalBudget-totalSpent;
  const hSpent       = tx.filter(t=>t.who==="husband").reduce((s,t)=>s+t.amount,0);
  const wSpent       = tx.filter(t=>t.who==="wife").reduce((s,t)=>s+t.amount,0);
  const recent       = [...tx].sort((a,b)=>b.id-a.id).slice(0,4);

  const daysLeft       = Math.max(DAYS - DAY, 1);
  const defaultPaceVal = Math.min(Math.round(remaining / daysLeft), sliderCfg.paceMaxDaily);
  const [paceDaily, setPaceDaily] = useState(Math.max(0, defaultPaceVal));

  const paceMax     = sliderCfg.paceMaxDaily;
  const projected   = totalSpent + paceDaily * daysLeft;
  const projOver    = projected > totalBudget;
  const paceColor   = pacePct<=90?"var(--green)":pacePct<=110?"#d4b84a":"var(--red)";
  const paceStatus  = pacePct<=90?"양호 ✓":pacePct<=110?"보통":"주의";
  const fillColor   = projOver ? "var(--red)" : "var(--green)";

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      {/* Header */}
      <div className="u1" style={{padding:"22px 0 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <div>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>{YEAR}년 {MONTH}월 · {DAY}일차</div>
          <div className="serif" style={{fontSize:21}}>가정 경영현황</div>
        </div>
        <div style={{background:paceColor+"22",color:paceColor,fontSize:11,fontWeight:700,padding:"5px 11px",borderRadius:99,border:`1px solid ${paceColor}44`}}>
          PACE {paceStatus}
        </div>
      </div>

      {/* Main card */}
      <Card className="u2" style={{padding:"18px",marginBottom:10,overflow:"hidden",position:"relative"}}>
        <div style={{position:"absolute",top:-50,right:-50,width:180,height:180,borderRadius:"50%",background:"radial-gradient(circle,var(--goldD) 0%,transparent 70%)",pointerEvents:"none"}}/>
        {/* Ring + stats */}
        <div style={{display:"flex",gap:18,alignItems:"center",marginBottom:16}}>
          <Ring pct={pct} size={100} stroke={7}>
            <div style={{fontSize:20,fontWeight:700,color:"var(--gold)"}}>{pct}%</div>
            <div style={{fontSize:9,color:"var(--text2)",letterSpacing:".05em",marginTop:1}}>집행률</div>
          </Ring>
          <div style={{flex:1}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:2}}>누적 지출</div>
            <div style={{fontSize:21,fontWeight:700,letterSpacing:"-.02em"}}>{fmtS(totalSpent)}<span style={{fontSize:13,color:"var(--text2)",marginLeft:2}}>원</span></div>
            <div style={{fontSize:12,color:"var(--text2)",marginTop:1}}>/ {fmtS(totalBudget)}원</div>
            <div style={{display:"flex",gap:14,marginTop:10}}>
              <div><div style={{fontSize:10,color:"var(--text2)"}}>잔여</div><div style={{fontSize:12,fontWeight:700,color:remaining>=0?"var(--green)":"var(--red)"}}>{fmtS(remaining)}원</div></div>
              <div><div style={{fontSize:10,color:"var(--text2)"}}>고정+할부</div><div style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>{fmtS(fixedTotal+installTotal)}원</div></div>
            </div>
          </div>
        </div>

        {/* ④ Pace Slider */}
        <div style={{background:"var(--bg4)",borderRadius:14,padding:"16px",border:"1px solid var(--border2)"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
            <div>
              <div style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>📊 남은 {daysLeft}일 시나리오</div>
              <div style={{fontSize:10,color:"var(--text2)",marginTop:3}}>슬라이더로 일 지출 조정 → 월말 예상 변화</div>
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <div style={{fontSize:10,color:"var(--text2)"}}>월말 예상</div>
              <div style={{fontSize:16,fontWeight:700,color:projOver?"var(--red)":"var(--green)"}}>{fmtS(projected)}원</div>
              <div style={{fontSize:10,color:projOver?"var(--red)":"var(--green)",marginTop:1}}>{projOver?"▲ 예산 초과":"✓ 예산 내"}</div>
            </div>
          </div>

          <SliderRow
            label="일평균 목표 지출"
            value={paceDaily}
            min={0}
            max={paceMax}
            step={5000}
            onChange={setPaceDaily}
            fillColor={fillColor}
            formatVal={v => fmtS(v)+"원/일"}
            showReset
            onReset={() => setPaceDaily(Math.max(0, defaultPaceVal))}
          />

          <div style={{display:"flex",gap:8}}>
            {[{label:"현재 페이스",val:Math.round(totalSpent/DAY),c:"var(--text2)"},{label:"조정 후",val:paceDaily,c:fillColor}].map(b=>(
              <div key={b.label} style={{flex:1,background:"var(--bg3)",borderRadius:10,padding:"9px 12px"}}>
                <div style={{fontSize:10,color:"var(--text2)",marginBottom:3}}>{b.label}</div>
                <div style={{fontSize:14,fontWeight:700,color:b.c}}>{fmtS(b.val)}<span style={{fontSize:10,color:"var(--text2)",marginLeft:2}}>원/일</span></div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Partner */}
      <Card className="u3" style={{padding:"14px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",marginBottom:10}}>파트너별 지출</div>
        <div style={{display:"flex",height:5,borderRadius:99,overflow:"hidden",marginBottom:10}}>
          <div style={{width:`${totalSpent>0?hSpent/totalSpent*100:50}%`,background:"var(--h)",transition:"width .7s ease"}}/>
          <div style={{flex:1,background:"var(--w)"}}/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
          {[{w:"husband",a:hSpent},{w:"wife",a:wSpent}].map(p=>(
            <div key={p.w} style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:p.w==="husband"?"var(--h)":"var(--w)"}}/>
              <div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{p.w==="husband"?names.husband:names.wife}</div>
                <div style={{fontSize:13,fontWeight:700}}>{fmtS(p.a)}원</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          {["husband","wife"].map(w=>(
            <button key={w} onClick={()=>onAdd(w)} style={{
              background:w==="husband"?"var(--hD)":"var(--wD)",
              border:`1px solid ${w==="husband"?"rgba(92,141,232,.25)":"rgba(217,127,168,.25)"}`,
              borderRadius:11,padding:"11px",cursor:"pointer",
              color:w==="husband"?"var(--h)":"var(--w)",fontWeight:700,fontSize:13,
              display:"flex",alignItems:"center",gap:6,justifyContent:"center"
            }}><span style={{fontSize:17,lineHeight:1}}>+</span>{w==="husband"?names.husband:names.wife}</button>
          ))}
        </div>
      </Card>

      {/* Recent */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{padding:"12px 14px 8px",display:"flex",justifyContent:"space-between"}}>
          <span style={{fontSize:12,fontWeight:700}}>최근 내역</span>
          <span style={{fontSize:10,color:"var(--text2)"}}>{tx.length}건</span>
        </div>
        {recent.length===0?(
          <div style={{padding:"28px 14px",textAlign:"center"}}>
            <div style={{fontSize:28,marginBottom:8}}>📋</div>
            <div style={{fontSize:13,color:"var(--text2)",marginBottom:4}}>아직 입력된 내역이 없어요</div>
            <div style={{fontSize:11,color:"var(--text3)"}}>✚ 입력 탭에서 지출을 기록해보세요</div>
          </div>
        ):recent.map(t=>{
          const c=CAT[t.cat]||CATS[8];
          return(
            <div key={t.id} style={{padding:"9px 14px",borderTop:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:33,height:33,borderRadius:9,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{c.icon}</div>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:2}}><span style={{fontSize:12,fontWeight:500}}>{c.label}</span><Chip who={t.who} names={names}/></div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo||"—"} · {t.date.slice(5)}</div>
              </div>
              <span style={{fontSize:13,fontWeight:700,flexShrink:0}}>-{fmtS(t.amount)}원</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CALENDAR VIEW
// ─────────────────────────────────────────────────────────────
function CalendarView({tx, cards, names, budgets}) {
  const [selDate, setSelDate] = useState(today_str());
  const [selCard, setSelCard] = useState(null); // 카드 결제일 팝업

  // 현재 표시 월 (네비게이션 가능)
  const [viewYear,  setViewYear]  = useState(YEAR);
  const [viewMonth, setViewMonth] = useState(MONTH); // 1-indexed

  const firstDay    = new Date(viewYear, viewMonth-1, 1).getDay(); // 0=일
  const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
  const isCurrentMonth = viewYear===YEAR && viewMonth===MONTH;

  // 날짜별 지출 합계
  const dailyMap = {};
  tx.forEach(t => {
    const [ty, tm] = t.date.split("-").map(Number);
    if (ty===viewYear && tm===viewMonth) {
      dailyMap[t.date] = (dailyMap[t.date]||0) + t.amount;
    }
  });

  // 이 달 최대 지출 (히트맵 기준)
  const maxDaily = Math.max(...Object.values(dailyMap), 1);

  // 이 달 총 예산 대비 일 기준
  const totalBudget = Object.values(budgets).reduce((s,v)=>s+v,0);
  const dailyBudget = totalBudget / daysInMonth;

  // 카드 결제일 — 이 달에 해당하는 것들
  const cardPayDates = cards.map(card => {
    try {
      const { payDate, cycleStart, cycleEnd, daysUntilPay } = getBillingPeriod(card,
        new Date(viewYear, viewMonth-1, 15)); // 해당 월 기준
      const pY = payDate.getFullYear(), pM = payDate.getMonth()+1, pD = payDate.getDate();
      if (pY===viewYear && pM===viewMonth) {
        return { card, payDay: pD, payDate, cycleStart, cycleEnd, daysUntilPay };
      }
    } catch { return null; }
    return null;
  }).filter(Boolean);

  // 카드 결제일 맵 (날짜 → 카드 배열)
  const payDateMap = {};
  cardPayDates.forEach(cp => {
    const key = `${viewYear}-${String(viewMonth).padStart(2,"0")}-${String(cp.payDay).padStart(2,"0")}`;
    if (!payDateMap[key]) payDateMap[key] = [];
    payDateMap[key].push(cp);
  });

  // 선택된 날 내역
  const selTx   = tx.filter(t => t.date === selDate).sort((a,b)=>b.id-a.id);
  const selTotal = selTx.reduce((s,t)=>s+t.amount, 0);
  const selPayCards = payDateMap[selDate] || [];

  const prevMonth = () => {
    if (viewMonth===1) { setViewYear(y=>y-1); setViewMonth(12); }
    else setViewMonth(m=>m-1);
  };
  const nextMonth = () => {
    if (viewMonth===12) { setViewYear(y=>y+1); setViewMonth(1); }
    else setViewMonth(m=>m+1);
  };

  const DNAMES = ["일","월","화","수","목","금","토"];
  const selDateLabel = `${selDate.split("-")[1]}월 ${selDate.split("-")[2].replace(/^0/,"")}일`;

  return (
    <div style={{padding:"0 16px 96px", overflowY:"auto", height:"100%"}}>

      {/* 월 네비게이션 */}
      <div className="u1" style={{padding:"22px 0 14px", display:"flex", alignItems:"center", justifyContent:"space-between"}}>
        <button onClick={prevMonth} style={{
          width:34,height:34,borderRadius:10,border:"1px solid var(--border)",
          background:"var(--bg2)",cursor:"pointer",fontSize:16,color:"var(--text2)",
          display:"flex",alignItems:"center",justifyContent:"center"
        }}>‹</button>
        <div style={{textAlign:"center"}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase"}}>{viewYear}</div>
          <div className="serif" style={{fontSize:22,lineHeight:1.2}}>{viewMonth}월</div>
        </div>
        <button onClick={nextMonth} style={{
          width:34,height:34,borderRadius:10,border:"1px solid var(--border)",
          background:"var(--bg2)",cursor:"pointer",fontSize:16,color:"var(--text2)",
          display:"flex",alignItems:"center",justifyContent:"center"
        }}>›</button>
      </div>

      {/* 이달 요약 */}
      {isCurrentMonth && (
        <div className="u2" style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
          {[
            {l:"이달 지출", v:fmtS(tx.filter(t=>t.date.startsWith(`${YEAR}-${String(MONTH).padStart(2,"0")}`)).reduce((s,t)=>s+t.amount,0))+"원", c:"var(--text)"},
            {l:"결제 예정", v:cards.length>0?fmtS(cardPayDates.reduce((s,cp)=>{
              const s2=toDateStr(cp.cycleStart),e2=toDateStr(cp.cycleEnd);
              return s+tx.filter(t=>t.cardId===cp.card.id&&t.date>=s2&&t.date<=e2).reduce((a,t)=>a+t.amount,0);
            },0))+"원":"—", c:"var(--pink)"},
            {l:"카드 수", v:cards.length+"개", c:"var(--blue)"},
          ].map(s=>(
            <Card key={s.l} style={{padding:"11px 10px",textAlign:"center"}}>
              <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{s.l}</div>
              <div style={{fontSize:13,fontWeight:700,color:s.c}}>{s.v}</div>
            </Card>
          ))}
        </div>
      )}

      {/* 달력 */}
      <Card className="u3" style={{padding:"14px",marginBottom:12}}>
        {/* 요일 헤더 */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",marginBottom:6}}>
          {DNAMES.map((d,i)=>(
            <div key={d} style={{
              textAlign:"center",fontSize:11,fontWeight:600,
              color:i===0?"var(--red)":i===6?"var(--blue)":"var(--text3)",
              padding:"3px 0"
            }}>{d}</div>
          ))}
        </div>

        {/* 날짜 그리드 */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
          {Array(firstDay).fill(null).map((_,i)=><div key={"e"+i}/>)}
          {Array(daysInMonth).fill(null).map((_,i)=>{
            const d = i+1;
            const dateStr = `${viewYear}-${String(viewMonth).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
            const amt = dailyMap[dateStr]||0;
            const isSel = dateStr===selDate;
            const isToday = dateStr===today_str();
            const payCards = payDateMap[dateStr]||[];
            const hasPayDay = payCards.length>0;
            const isOver = amt > dailyBudget * 1.5;
            const weekday = (firstDay + i) % 7;

            // 히트맵 강도 (0~1)
            const intensity = amt>0 ? Math.min(amt/maxDaily, 1) : 0;
            const heatBg = amt>0
              ? `rgba(${isOver?"217,95,95":"77,171,135"}, ${0.15 + intensity*0.5})`
              : "transparent";

            return (
              <div
                key={d}
                onClick={()=>setSelDate(dateStr)}
                style={{
                  borderRadius:9,padding:"5px 2px 4px",cursor:"pointer",
                  textAlign:"center",position:"relative",
                  background: isSel ? "var(--goldD)" : heatBg,
                  border:`1px solid ${isSel?"var(--gold)":"transparent"}`,
                  transition:"all .12s",
                  minHeight:46,
                }}
              >
                <div style={{
                  fontSize:12,fontWeight:isToday?700:400,lineHeight:1,
                  color:isToday?"var(--gold)":isSel?"var(--gold)":weekday===0?"var(--red)":weekday===6?"var(--blue)":"var(--text)"
                }}>{d}</div>

                {/* 지출 금액 */}
                {amt>0 && (
                  <div style={{fontSize:8,color:isSel?"var(--goldL)":"var(--text2)",marginTop:2,lineHeight:1}}>
                    {fmtS(amt)}
                  </div>
                )}

                {/* 카드 결제일 배지 */}
                {hasPayDay && (
                  <div style={{
                    position:"absolute",bottom:2,right:2,
                    width:5,height:5,borderRadius:"50%",
                    background:"var(--pink)"
                  }}/>
                )}

                {/* 오늘 표시 */}
                {isToday && (
                  <div style={{
                    position:"absolute",top:2,right:2,
                    width:5,height:5,borderRadius:"50%",
                    background:"var(--gold)"
                  }}/>
                )}
              </div>
            );
          })}
        </div>

        {/* 범례 */}
        <div style={{display:"flex",gap:14,marginTop:12,paddingTop:10,borderTop:"1px solid var(--border)",flexWrap:"wrap"}}>
          {[
            {color:"var(--gold)",label:"오늘"},
            {color:"rgba(77,171,135,.7)",label:"지출 있음"},
            {color:"rgba(217,95,95,.7)",label:"과지출 (1.5배↑)"},
            {color:"var(--pink)",label:"💳 카드 결제일"},
          ].map(l=>(
            <div key={l.label} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:7,height:7,borderRadius:"50%",background:l.color,flexShrink:0}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.label}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* 선택된 날 상세 */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{
          padding:"13px 15px 10px",
          display:"flex",justifyContent:"space-between",alignItems:"center",
          borderBottom:"1px solid var(--border)"
        }}>
          <div>
            <span style={{fontSize:13,fontWeight:700}}>{selDateLabel}</span>
            {selPayCards.length>0 && (
              <span style={{
                marginLeft:8,fontSize:10,fontWeight:700,
                background:"var(--pinkD)",color:"var(--pink)",
                padding:"2px 7px",borderRadius:99
              }}>💳 결제일</span>
            )}
          </div>
          <span style={{fontSize:13,fontWeight:700,color:selTotal>0?"var(--text)":"var(--text3)"}}>
            {selTotal>0 ? fmt(selTotal) : "지출 없음"}
          </span>
        </div>

        {/* 카드 결제일 정보 */}
        {selPayCards.map(cp=>{
          const s=toDateStr(cp.cycleStart), e=toDateStr(cp.cycleEnd);
          const cardTotal = tx.filter(t=>t.cardId===cp.card.id&&t.date>=s&&t.date<=e).reduce((a,t)=>a+t.amount,0);
          return(
            <div key={cp.card.id} style={{
              padding:"12px 15px",
              background:`linear-gradient(135deg,${cp.card.color}28,${cp.card.color}10)`,
              borderBottom:"1px solid var(--border)"
            }}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:15}}>{cp.card.icon}</span>
                  <span style={{fontSize:13,fontWeight:700}}>{cp.card.name}</span>
                  <span style={{fontSize:10,color:"var(--text2)"}}>결제일</span>
                </div>
                <span style={{fontSize:16,fontWeight:700,color:"var(--pink)"}}>{fmt(cardTotal)}</span>
              </div>
              <div style={{fontSize:11,color:"var(--text2)"}}>
                정산 기간: {fmtPeriodLabel(cp.cycleStart,cp.cycleEnd)}
              </div>
            </div>
          );
        })}

        {/* 당일 지출 내역 */}
        {selTx.length===0 && selPayCards.length===0 ? (
          <div style={{padding:"22px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            이 날의 기록이 없어요
          </div>
        ):selTx.map(t=>{
          const c = CAT[t.cat]||CATS[8];
          const cardName = t.cardId ? cards.find(c=>c.id===t.cardId)?.name : null;
          return(
            <div key={t.id} style={{
              padding:"10px 15px",borderBottom:"1px solid var(--border)",
              display:"flex",alignItems:"center",gap:10
            }}>
              <div style={{
                width:34,height:34,borderRadius:9,flexShrink:0,
                background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15
              }}>{c.icon}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:2,flexWrap:"wrap"}}>
                  <span style={{fontSize:12,fontWeight:600}}>{c.label}</span>
                  <Chip who={t.who} names={names}/>
                  {cardName && (
                    <span style={{fontSize:9,color:"var(--pink)",background:"var(--pinkD)",padding:"1px 6px",borderRadius:99}}>
                      {cardName}
                    </span>
                  )}
                </div>
                {t.memo && <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo}</div>}
              </div>
              <span style={{fontSize:13,fontWeight:700,flexShrink:0}}>-{fmtS(t.amount)}원</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// PLAN VIEW — 연간·월간 재무 계획
// ─────────────────────────────────────────────────────────────
const MONTH_NAMES = ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"];

function PlanView({plan, setPlan, tx, budgets}) {
  const [editSection, setEditSection] = useState(null); // 'annual' | 'events' | number(month)
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEvent, setNewEvent] = useState({title:"", amount:"", month:MONTH, cat:"etc"});

  // ── 연간 실적 계산 ───────────────────────────────────────
  const yearTx       = tx.filter(t => t.date.startsWith(`${YEAR}`));
  const yearSpent    = yearTx.reduce((s,t) => s+t.amount, 0);
  const yearSavingGoal = plan.yearSavingGoal || 0;
  // 연간 예상 수입 (plan에서 설정)
  const yearIncome   = plan.yearIncome || 0;
  const yearActualSaving = Math.max(0, yearIncome - yearSpent);
  const savingPct    = yearSavingGoal > 0 ? Math.round(yearActualSaving / yearSavingGoal * 100) : 0;

  // 연간 지출 한도
  const yearSpendLimit = plan.yearSpendLimit || 0;
  const spendPct     = yearSpendLimit > 0 ? Math.round(yearSpent / yearSpendLimit * 100) : 0;
  const yearProjected = DAY > 0 ? Math.round(yearSpent / (MONTH*30+DAY) * 365) : 0;

  // 월별 지출 집계
  const monthlySpent = Array.from({length:12}, (_,i) => {
    const prefix = `${YEAR}-${String(i+1).padStart(2,"0")}`;
    return tx.filter(t=>t.date.startsWith(prefix)).reduce((s,t)=>s+t.amount,0);
  });

  // 이달 월간 계획 예산 (plan.monthBudgets[MONTH-1])
  const monthPlanBudgets = plan.monthBudgets || Array(12).fill(null).map(()=>({...budgets}));

  const iStyle = {
    width:"100%", background:"var(--bg4)", border:"1px solid var(--border)",
    borderRadius:10, padding:"10px 13px", color:"var(--text)", fontSize:13, outline:"none"
  };
  const numStyle = {...iStyle, textAlign:"right"};

  const updatePlan = (key, val) => setPlan(p => ({...p, [key]: val}));

  // 이벤트 추가
  const addEvent = () => {
    if (!newEvent.title || !newEvent.amount) return;
    setPlan(p => ({...p, events:[...(p.events||[]),{id:Date.now(),...newEvent,amount:parseInt(newEvent.amount)}]}));
    setNewEvent({title:"",amount:"",month:MONTH,cat:"etc"});
    setShowAddEvent(false);
  };
  const delEvent = id => setPlan(p => ({...p, events:(p.events||[]).filter(e=>e.id!==id)}));

  // 이번 달 이후 이벤트 정렬
  const upcomingEvents = [...(plan.events||[])].filter(e=>e.month >= MONTH).sort((a,b)=>a.month-b.month);
  const pastEvents     = [...(plan.events||[])].filter(e=>e.month < MONTH).sort((a,b)=>a.month-b.month);

  return (
    <div style={{padding:"0 16px 96px", overflowY:"auto", height:"100%"}}>
      <div className="u1" style={{padding:"22px 0 14px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>Annual & Monthly Plan</div>
        <div className="serif" style={{fontSize:21}}>{YEAR}년 재무 계획</div>
      </div>

      {/* ── 연간 재무 목표 ── */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ 연간 재무 목표</div>
          <button onClick={()=>setEditSection(editSection==="annual"?null:"annual")} style={{
            fontSize:11,color:"var(--gold)",background:"var(--goldD)",border:"1px solid var(--gold)",
            borderRadius:7,padding:"3px 10px",cursor:"pointer"
          }}>{editSection==="annual"?"완료":"수정"}</button>
        </div>

        {editSection==="annual" ? (
          <div>
            {[
              {label:"연간 예상 수입", key:"yearIncome",    placeholder:"예: 84000000"},
              {label:"연간 저축 목표", key:"yearSavingGoal",placeholder:"예: 36000000"},
              {label:"연간 지출 한도", key:"yearSpendLimit",placeholder:"예: 48000000"},
            ].map(f=>(
              <div key={f.key} style={{marginBottom:10}}>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>{f.label}</div>
                <input type="number" placeholder={f.placeholder}
                  value={plan[f.key]||""}
                  onChange={e=>updatePlan(f.key, parseInt(e.target.value)||0)}
                  style={numStyle}/>
              </div>
            ))}
          </div>
        ) : (
          <div>
            {/* 저축 목표 */}
            <div style={{marginBottom:16}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:16}}>💰</span>
                  <span style={{fontSize:13,fontWeight:600}}>연간 저축 목표</span>
                </div>
                <div>
                  <span style={{fontSize:14,fontWeight:700,color:"var(--green)"}}>{fmtS(yearActualSaving)}원</span>
                  <span style={{fontSize:11,color:"var(--text2)"}}> / {fmtS(yearSavingGoal)}원</span>
                </div>
              </div>
              {yearSavingGoal > 0 ? (
                <>
                  <Bar pct={savingPct} color="var(--green)" h={8}/>
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
                    <span style={{fontSize:11,color:"var(--text2)"}}>달성률 {savingPct}%</span>
                    <span style={{fontSize:11,color:savingPct>=100?"var(--green)":"var(--text2)"}}>
                      {savingPct>=100 ? "🎉 목표 달성!" : `${fmtS(yearSavingGoal-yearActualSaving)}원 남음`}
                    </span>
                  </div>
                </>
              ) : (
                <div style={{fontSize:11,color:"var(--text3)",textAlign:"center",padding:"8px 0"}}>수정 버튼을 눌러 목표를 설정하세요</div>
              )}
            </div>

            {/* 지출 한도 */}
            <div style={{paddingTop:14,borderTop:"1px solid var(--border)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:6}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:16}}>📉</span>
                  <span style={{fontSize:13,fontWeight:600}}>연간 지출 한도</span>
                </div>
                <div>
                  <span style={{fontSize:14,fontWeight:700,color:spendPct>100?"var(--red)":"var(--text)"}}>{fmtS(yearSpent)}원</span>
                  <span style={{fontSize:11,color:"var(--text2)"}}> / {fmtS(yearSpendLimit)}원</span>
                </div>
              </div>
              {yearSpendLimit > 0 ? (
                <>
                  <Bar pct={spendPct} color="var(--blue)" h={8}/>
                  <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}>
                    <span style={{fontSize:11,color:"var(--text2)"}}>집행률 {spendPct}%</span>
                    <span style={{fontSize:11,color:yearProjected>yearSpendLimit?"var(--red)":"var(--green)"}}>
                      연말 예상 {fmtS(yearProjected)}원 {yearProjected>yearSpendLimit?"⚠️ 한도 초과 예상":"✓"}
                    </span>
                  </div>
                </>
              ) : (
                <div style={{fontSize:11,color:"var(--text3)",textAlign:"center",padding:"8px 0"}}>수정 버튼을 눌러 한도를 설정하세요</div>
              )}
            </div>
          </div>
        )}
      </Card>

      {/* ── 월별 지출 현황 바 ── */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ {YEAR}년 월별 지출 현황</div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:6}}>
          {MONTH_NAMES.map((m,i)=>{
            const spent  = monthlySpent[i];
            const mBudget= Object.values(budgets).reduce((s,v)=>s+v,0);
            const pct    = mBudget>0 ? Math.min(spent/mBudget*100, 100) : 0;
            const isCur  = i+1 === MONTH;
            const isFuture = i+1 > MONTH;
            const hasEvents = (plan.events||[]).some(e=>e.month===i+1);
            return (
              <div key={m} style={{textAlign:"center"}}>
                <div style={{
                  height:60, background:"var(--bg3)", borderRadius:8, overflow:"hidden",
                  position:"relative", marginBottom:4,
                  border:`1px solid ${isCur?"var(--gold)":"var(--border)"}`
                }}>
                  {!isFuture && spent>0 && (
                    <div style={{
                      position:"absolute", bottom:0, left:0, right:0,
                      height:`${pct}%`,
                      background:pct>=100?"var(--red)":isCur?"var(--gold)":"var(--blue)",
                      opacity:isFuture?0.3:1,
                      transition:"height .6s ease"
                    }}/>
                  )}
                  {hasEvents && (
                    <div style={{position:"absolute",top:3,right:3,fontSize:8}}>📌</div>
                  )}
                </div>
                <div style={{fontSize:9,color:isCur?"var(--gold)":"var(--text2)",fontWeight:isCur?700:400}}>{m}</div>
                {!isFuture && spent>0 && (
                  <div style={{fontSize:8,color:"var(--text3)"}}>{fmtS(spent)}</div>
                )}
              </div>
            );
          })}
        </div>
        <div style={{display:"flex",gap:14,marginTop:12,paddingTop:10,borderTop:"1px solid var(--border)"}}>
          {[{c:"var(--gold)",l:"이번 달"},{c:"var(--blue)",l:"지출 있음"},{c:"var(--red)",l:"예산 초과"}].map(l=>(
            <div key={l.l} style={{display:"flex",alignItems:"center",gap:4}}>
              <div style={{width:7,height:7,borderRadius:2,background:l.c}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.l}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* ── 이달 카테고리별 플래닝 ── */}
      <Card className="u4" style={{padding:"18px",marginBottom:10}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ {MONTH}월 카테고리별 플래닝</div>
          <button onClick={()=>setEditSection(editSection==="month"?null:"month")} style={{
            fontSize:11,color:"var(--blue)",background:"var(--blueD)",border:"1px solid var(--blue)",
            borderRadius:7,padding:"3px 10px",cursor:"pointer"
          }}>{editSection==="month"?"완료":"조정"}</button>
        </div>
        <div style={{fontSize:11,color:"var(--text3)",marginBottom:14}}>
          현재 예산 설정과 별개로 이달 목표를 따로 잡을 수 있어요
        </div>

        {CATS.map(cat=>{
          const planKey  = `monthPlan_${YEAR}_${MONTH}_${cat.id}`;
          const planAmt  = plan[planKey] ?? (budgets[cat.id]||0);
          const spent    = tx.filter(t=>t.cat===cat.id&&t.date.startsWith(`${YEAR}-${String(MONTH).padStart(2,"0")}`)).reduce((s,t)=>s+t.amount,0);
          const pct      = planAmt > 0 ? Math.round(spent/planAmt*100) : 0;
          if(!planAmt && !spent) return null;
          return (
            <div key={cat.id} style={{marginBottom:14}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:14}}>{cat.icon}</span>
                  <span style={{fontSize:12,fontWeight:500}}>{cat.label}</span>
                  <span style={{fontSize:11}}>{pct>100?"🔴":pct>85?"🟡":"🟢"}</span>
                </div>
                {editSection==="month" ? (
                  <input type="number" value={planAmt||""}
                    onChange={e=>updatePlan(planKey, parseInt(e.target.value)||0)}
                    style={{width:90,background:"var(--bg4)",border:`1px solid ${cat.color}66`,
                      borderRadius:8,padding:"4px 8px",color:cat.color,fontSize:12,
                      fontWeight:700,textAlign:"right",outline:"none"}}/>
                ) : (
                  <div style={{display:"flex",alignItems:"baseline",gap:4}}>
                    <span style={{fontSize:12,fontWeight:700}}>{fmtS(spent)}</span>
                    <span style={{fontSize:10,color:"var(--text2)"}}>/ {fmtS(planAmt)}원</span>
                    <span style={{fontSize:11,fontWeight:700,color:pct>100?"var(--red)":pct>85?"var(--gold)":"var(--green)",minWidth:32,textAlign:"right"}}>{pct}%</span>
                  </div>
                )}
              </div>
              {editSection!=="month" && <Bar pct={pct} color={cat.color} h={4}/>}
            </div>
          );
        })}
      </Card>

      {/* ── 큰 지출 이벤트 예고 ── */}
      <Card className="u5" style={{overflow:"hidden",marginBottom:10}}>
        <div style={{padding:"14px 16px 10px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em"}}>■ 큰 지출 이벤트 예고</div>
          <span style={{fontSize:11,color:"var(--text2)"}}>{(plan.events||[]).length}개</span>
        </div>

        {/* 예정 이벤트 */}
        {upcomingEvents.length===0 && pastEvents.length===0 ? (
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            예정된 큰 지출을 미리 등록해두세요<br/>
            <span style={{fontSize:11}}>냉장고 구매, 여행, 경조사 등</span>
          </div>
        ) : (
          <>
            {upcomingEvents.map(e=>{
              const c = CAT[e.cat]||CATS[8];
              const isPast2 = e.month < MONTH;
              return (
                <div key={e.id} style={{
                  padding:"11px 15px",borderTop:"1px solid var(--border)",
                  display:"flex",alignItems:"center",gap:10
                }}>
                  <div style={{
                    width:36,height:36,borderRadius:10,flexShrink:0,
                    background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16
                  }}>{c.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:600,marginBottom:2}}>{e.title}</div>
                    <div style={{fontSize:10,color:"var(--text2)"}}>
                      {MONTH_NAMES[e.month-1]} · {c.label}
                    </div>
                  </div>
                  <div style={{textAlign:"right",marginRight:6}}>
                    <div style={{fontSize:14,fontWeight:700}}>{fmtS(e.amount)}원</div>
                    <div style={{fontSize:10,color:e.month===MONTH?"var(--red)":"var(--text2)"}}>
                      {e.month===MONTH?"이번달!":e.month > MONTH?`${e.month-MONTH}개월 후`:""}
                    </div>
                  </div>
                  <button onClick={()=>delEvent(e.id)} style={{
                    width:24,height:24,borderRadius:6,border:"none",cursor:"pointer",
                    background:"transparent",color:"var(--text3)",fontSize:12,flexShrink:0
                  }}>✕</button>
                </div>
              );
            })}
            {pastEvents.length>0 && (
              <div style={{padding:"8px 15px",background:"var(--bg3)"}}>
                <div style={{fontSize:10,color:"var(--text3)"}}>지난 이벤트 {pastEvents.length}개</div>
              </div>
            )}
          </>
        )}

        {/* 이벤트 추가 */}
        {showAddEvent ? (
          <div style={{padding:"14px 15px",borderTop:"1px solid var(--border)"}}>
            <input placeholder="이벤트명 (예: 냉장고 구매)" value={newEvent.title}
              onChange={e=>setNewEvent(v=>({...v,title:e.target.value}))}
              style={{...iStyle,marginBottom:8}}/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
              <div>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>예상 금액</div>
                <input type="number" placeholder="금액" value={newEvent.amount}
                  onChange={e=>setNewEvent(v=>({...v,amount:e.target.value}))}
                  style={iStyle}/>
              </div>
              <div>
                <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>예정 월</div>
                <select value={newEvent.month} onChange={e=>setNewEvent(v=>({...v,month:+e.target.value}))}
                  style={{...iStyle,cursor:"pointer"}}>
                  {MONTH_NAMES.map((m,i)=>(
                    <option key={i} value={i+1}>{m}</option>
                  ))}
                </select>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:10}}>
              {CATS.slice(0,6).map(c=>(
                <button key={c.id} onClick={()=>setNewEvent(v=>({...v,cat:c.id}))} style={{
                  background:newEvent.cat===c.id?c.color+"25":"var(--bg4)",
                  border:`1px solid ${newEvent.cat===c.id?c.color+"66":"var(--border)"}`,
                  borderRadius:10,padding:"8px 4px",cursor:"pointer",
                  display:"flex",flexDirection:"column",alignItems:"center",gap:3
                }}>
                  <span style={{fontSize:15}}>{c.icon}</span>
                  <span style={{fontSize:9,color:"var(--text2)"}}>{c.label}</span>
                </button>
              ))}
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setShowAddEvent(false)} style={{
                flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",
                borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12
              }}>취소</button>
              <button onClick={addEvent} style={{
                flex:2,padding:"11px",background:"var(--purpleD)",border:"1px solid var(--purple)",
                borderRadius:11,color:"var(--purple)",fontWeight:700,fontSize:12,cursor:"pointer"
              }}>추가</button>
            </div>
          </div>
        ) : (
          <button onClick={()=>setShowAddEvent(true)} style={{
            display:"block",width:"100%",padding:"12px",
            background:"transparent",border:"none",borderTop:"1px solid var(--border)",
            color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600
          }}>+ 이벤트 추가</button>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// REPORT WRAPPER — 리포트 + 캘린더 + 계획 서브탭
// ─────────────────────────────────────────────────────────────
function ReportView({tx, budgets, fixed, install, names, cards, plan, setPlan}) {
  const [tab, setTab] = useState("report");
  return (
    <div style={{height:"100%",display:"flex",flexDirection:"column"}}>
      <div style={{display:"flex",gap:6,padding:"14px 16px 0",background:"var(--bg)",flexShrink:0}}>
        {[{id:"report",l:"📊 리포트"},{id:"calendar",l:"📅 캘린더"},{id:"plan",l:"🎯 계획"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flex:1,padding:"10px 6px",borderRadius:12,cursor:"pointer",
            fontWeight:700,fontSize:11,
            background:tab===t.id?"var(--goldD)":"var(--bg2)",
            border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,
            color:tab===t.id?"var(--gold)":"var(--text2)",
            transition:"all .15s"
          }}>{t.l}</button>
        ))}
      </div>
      <div style={{flex:1,overflow:"hidden"}}>
        {tab==="report"   && <ReportContent tx={tx} budgets={budgets} fixed={fixed} install={install} names={names}/>}
        {tab==="calendar" && <CalendarView  tx={tx} cards={cards} names={names} budgets={budgets}/>}
        {tab==="plan"     && <PlanView      plan={plan} setPlan={setPlan} tx={tx} budgets={budgets}/>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// REPORT CONTENT (기존 ReportView 내용)
// ─────────────────────────────────────────────────────────────
function StackedBar({data,total,height=24,showLegend=false}){
  return(
    <div>
      <div style={{display:"flex",height,borderRadius:10,overflow:"hidden"}}>
        {data.filter(d=>d.amount>0).map(d=>{
          const c=CAT[d.cat]; const w=total>0?d.amount/total*100:0;
          return <div key={d.cat} style={{width:`${w}%`,background:c?.color||"#888",transition:"width .7s ease",minWidth:w>1?1:0}} title={`${c?.label} ${Math.round(w)}%`}/>;
        })}
      </div>
      {showLegend&&(
        <div style={{display:"flex",flexWrap:"wrap",gap:"5px 12px",marginTop:8}}>
          {data.filter(d=>d.amount>0&&total>0&&d.amount/total>.03).map(d=>{
            const c=CAT[d.cat]; const p=Math.round(d.amount/total*100);
            return(<div key={d.cat} style={{display:"flex",alignItems:"center",gap:4}}><div style={{width:6,height:6,borderRadius:1,background:c?.color}}/><span style={{fontSize:10,color:"var(--text2)"}}>{c?.label} {p}%</span></div>);
          })}
        </div>
      )}
    </div>
  );
}

function ReportContent({tx,budgets,fixed,install,names}){
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const totalSpent   = tx.reduce((s,t)=>s+t.amount,0);
  const fixedTotal   = fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal = install.reduce((s,i)=>s+i.monthly,0);
  const projected    = DAY > 0 ? Math.round(totalSpent / DAY * DAYS) : 0;
  const hSpent = tx.filter(t=>t.who==="husband").reduce((s,t)=>s+t.amount,0);
  const wSpent = tx.filter(t=>t.who==="wife").reduce((s,t)=>s+t.amount,0);

  // 이번 달 카테고리별 집계
  const curMonthStr = `${YEAR}-${String(MONTH).padStart(2,"0")}`;
  const curTx  = tx.filter(t=>t.date.startsWith(curMonthStr));
  const catData= CATS.map(c=>({cat:c.id,amount:curTx.filter(t=>t.cat===c.id).reduce((s,t)=>s+t.amount,0)}));
  const curTotal = curTx.reduce((s,t)=>s+t.amount,0);

  // 전월 데이터 — 실제 tx에서 계산
  const prevYear  = MONTH===1 ? YEAR-1 : YEAR;
  const prevMonth = MONTH===1 ? 12 : MONTH-1;
  const prevMonthStr = `${prevYear}-${String(prevMonth).padStart(2,"0")}`;
  const prevTx   = tx.filter(t=>t.date.startsWith(prevMonthStr));
  const prevCatData = CATS.map(c=>({cat:c.id,amount:prevTx.filter(t=>t.cat===c.id).reduce((s,t)=>s+t.amount,0)}));
  const prevTotal= prevTx.reduce((s,t)=>s+t.amount,0);
  const hasPrev  = prevTotal > 0;

  // 월 표시 레이블
  const prevLabel = `${prevYear}년 ${prevMonth}월`;

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub={`${YEAR}년 ${MONTH}월 · ${DAY}일 기준`} title="월간 경영 리포트"/></div>

      {/* 지출 구조 비교 */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 지출 구조 비교</div>

        {/* 이번 달 */}
        <div style={{marginBottom:16}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
            <span style={{fontSize:12,fontWeight:600}}>이번 달 ({fmtS(curTotal)}원)</span>
            <span style={{fontSize:11,color:projected>totalBudget?"var(--red)":"var(--green)"}}>
              예상 {fmtS(projected)}원
            </span>
          </div>
          {curTotal > 0
            ? <StackedBar data={catData} total={curTotal} height={24} showLegend/>
            : <div style={{height:24,borderRadius:10,background:"var(--track)",display:"flex",alignItems:"center",paddingLeft:12}}>
                <span style={{fontSize:11,color:"var(--text3)"}}>이번 달 지출 내역 없음</span>
              </div>
          }
        </div>

        {/* 전월 */}
        <div style={{borderTop:"1px solid var(--border)",paddingTop:14}}>
          <div style={{marginBottom:8}}>
            <span style={{fontSize:12,fontWeight:600,color:"var(--text2)"}}>
              {prevLabel} ({fmtS(prevTotal)}원)
            </span>
          </div>
          {hasPrev
            ? <StackedBar data={prevCatData} total={prevTotal} height={18} showLegend/>
            : <div style={{
                height:18,borderRadius:8,background:"var(--track)",
                display:"flex",alignItems:"center",paddingLeft:12
              }}>
                <span style={{fontSize:11,color:"var(--text3)"}}>전월 데이터 없음</span>
              </div>
          }
        </div>

        {/* 전월 대비 증감 */}
        <div style={{marginTop:14,paddingTop:12,borderTop:"1px solid var(--border)"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:10}}>전월 대비 증감</div>
          {hasPrev && curTotal > 0 ? (
            <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
              {CATS.map(c=>{
                const cur = catData.find(d=>d.cat===c.id)?.amount||0;
                const prv = prevCatData.find(d=>d.cat===c.id)?.amount||0;
                if(!cur && !prv) return null;
                const diff = cur - prv;
                const isUp = diff > 0;
                const isNew = prv === 0 && cur > 0;
                const isGone = cur === 0 && prv > 0;
                return(
                  <div key={c.id} style={{
                    background:"var(--bg3)",borderRadius:10,padding:"8px 11px",
                    display:"flex",alignItems:"center",gap:7,
                    border:`1px solid ${isUp?"var(--redD)":isGone?"var(--border)":"var(--greenD)"}`
                  }}>
                    <span style={{fontSize:14}}>{c.icon}</span>
                    <div>
                      <div style={{fontSize:10,color:"var(--text2)",marginBottom:1}}>{c.label}</div>
                      <div style={{fontSize:12,fontWeight:700,
                        color:isNew?"var(--blue)":isGone?"var(--text3)":isUp?"var(--red)":"var(--green)"
                      }}>
                        {isNew ? "신규" : isGone ? "없음" : `${isUp?"+":""}${fmtS(diff)}원`}
                      </div>
                    </div>
                  </div>
                );
              }).filter(Boolean)}
            </div>
          ) : (
            <div style={{
              padding:"16px",borderRadius:12,background:"var(--bg3)",
              textAlign:"center",color:"var(--text3)",fontSize:12
            }}>
              {!hasPrev && curTotal > 0
                ? `${prevLabel} 데이터가 없어 비교할 수 없어요`
                : "이번 달 또는 전월 데이터가 없어요"
              }
            </div>
          )}
        </div>
      </Card>

      {/* 총괄 */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:12}}>■ 총괄</div>
        {[
          {l:"월 총 예산",  v:fmt(totalBudget),                        c:"var(--text2)"},
          {l:"고정비+할부", v:fmt(fixedTotal+installTotal),             c:"var(--gold)"},
          {t:"div"},
          {l:"누적 지출",   v:fmt(totalSpent),                         c:"var(--text)"},
          {l:"잔여 예산",   v:fmt(totalBudget-totalSpent),              c:totalBudget-totalSpent>=0?"var(--green)":"var(--red)"},
          {l:"월말 예상",   v:totalSpent>0?fmt(projected):"—",         c:projected>totalBudget?"var(--red)":"var(--gold)"},
        ].map((r,i)=>r.t?<div key={i} style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>:(
          <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:"1px solid var(--border)"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>{r.l}</span>
            <span style={{fontSize:13,fontWeight:700,color:r.c}}>{r.v}</span>
          </div>
        ))}
      </Card>

      {/* 카테고리별 KPI */}
      <Card className="u4" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 카테고리별 KPI</div>
        {CATS.map(cat=>{
          const spent  = tx.filter(t=>t.cat===cat.id).reduce((s,t)=>s+t.amount,0);
          const budget = budgets[cat.id]||0;
          if(!budget && !spent) return null;
          const pct = budget>0 ? Math.round(spent/budget*100) : 0;
          return(
            <div key={cat.id} style={{marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <div style={{display:"flex",alignItems:"center",gap:7}}>
                  <span style={{fontSize:14}}>{cat.icon}</span>
                  <span style={{fontSize:12,fontWeight:500}}>{cat.label}</span>
                  <span style={{fontSize:12}}>{pct>100?"🔴":pct>85?"🟡":"🟢"}</span>
                </div>
                <div style={{display:"flex",alignItems:"baseline",gap:4}}>
                  <span style={{fontSize:12,fontWeight:700}}>{fmtS(spent)}</span>
                  <span style={{fontSize:10,color:"var(--text2)"}}>/ {fmtS(budget)}원</span>
                  <span style={{fontSize:11,fontWeight:700,minWidth:34,textAlign:"right",
                    color:pct>100?"var(--red)":pct>85?"var(--gold)":"var(--green)"
                  }}>{pct}%</span>
                </div>
              </div>
              <Bar pct={pct} color={cat.color} h={4}/>
            </div>
          );
        })}
        {CATS.every(c=>(budgets[c.id]||0)===0 && tx.filter(t=>t.cat===c.id).length===0) && (
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            예산을 설정하거나 지출을 입력하면 KPI가 표시됩니다
          </div>
        )}
      </Card>

      {/* 파트너별 비교 */}
      <Card className="u5" style={{padding:"18px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:12}}>■ 파트너별 비교</div>
        {totalSpent > 0 ? (
          <>
            <div style={{display:"flex",borderRadius:8,overflow:"hidden",height:16,marginBottom:12}}>
              <div style={{width:`${hSpent/totalSpent*100}%`,background:"var(--h)",transition:"width .7s ease"}}/>
              <div style={{flex:1,background:"var(--w)"}}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {[{who:"husband",amt:hSpent},{who:"wife",amt:wSpent}].map(p=>(
                <div key={p.who} style={{background:"var(--bg3)",borderRadius:13,padding:"13px"}}>
                  <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:7}}>
                    <div style={{width:7,height:7,borderRadius:"50%",background:p.who==="husband"?"var(--h)":"var(--w)"}}/>
                    <span style={{fontSize:11,color:"var(--text2)"}}>{p.who==="husband"?names.husband:names.wife}</span>
                  </div>
                  <div style={{fontSize:17,fontWeight:700}}>{fmt(p.amt)}</div>
                  <div style={{fontSize:11,color:"var(--text2)",marginTop:2}}>
                    {tx.filter(t=>t.who===p.who).length}건 · {totalSpent>0?Math.round(p.amt/totalSpent*100):0}%
                  </div>
                </div>
              ))}
            </div>
          </>
        ):(
          <div style={{padding:"20px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            지출을 입력하면 파트너별 비교가 표시됩니다
          </div>
        )}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SIMULATOR VIEW
// ─────────────────────────────────────────────────────────────
const simTooltip=({active,payload,label})=>{
  if(!active||!payload?.length) return null;
  return(
    <div style={{background:"var(--bg3)",border:"1px solid var(--border2)",borderRadius:10,padding:"10px 14px",fontSize:11}}>
      <div style={{color:"var(--text2)",marginBottom:4}}>{label}년</div>
      {payload.map(p=>(<div key={p.name} style={{color:p.color,fontWeight:700}}>{p.name}: {fmtS(p.value)}원</div>))}
    </div>
  );
};

function SimulatorView({sliderCfg,onUpdateSimCfg}){
  const [init,   setInit]   = useState(sliderCfg.simInitAmt);
  const [monthly,setMonthly]= useState(sliderCfg.simMonthly);
  const [rate,   setRate]   = useState(sliderCfg.simRate);
  const [years,  setYears]  = useState(sliderCfg.simYears);
  const [goal,   setGoal]   = useState(sliderCfg.simGoal);

  const reset=()=>{setInit(sliderCfg.simInitAmt);setMonthly(sliderCfg.simMonthly);setRate(sliderCfg.simRate);setYears(sliderCfg.simYears);setGoal(sliderCfg.simGoal);};

  const data=useMemo(()=>{
    const r=rate/100;
    return Array.from({length:years+1},(_,y)=>({
      year:y,
      복리성장:Math.round(init*Math.pow(1+r,y)+monthly*12*(r>0?(Math.pow(1+r,y)-1)/r:y)),
      단순저축:Math.round(init+monthly*12*y),
      원금:init,
    }));
  },[init,monthly,rate,years]);

  const final=data[data.length-1];
  const multiple=(final.복리성장/Math.max(init,1)).toFixed(1);
  const goalYear=data.findIndex(d=>d.복리성장>=goal);

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1">
        <div style={{padding:"22px 0 4px",display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
          <SectionHeader sub="Finance Simulator" title="재무 시뮬레이터"/>
          <button onClick={reset} style={{fontSize:11,color:"var(--text2)",background:"rgba(255,255,255,.04)",border:"1px solid var(--border)",borderRadius:8,padding:"5px 12px",cursor:"pointer",marginBottom:14}}>전체 초기화</button>
        </div>
      </div>

      {/* Sliders */}
      <Card className="u2" style={{padding:"20px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:16}}>■ 변수 조정</div>
        <SliderRow label="초기 투자금" value={init} min={1000000} max={100000000} step={1000000}
          onChange={setInit} fillColor="var(--gold)"
          showReset onReset={()=>setInit(sliderCfg.simInitAmt)}/>
        <SliderRow label="월 저축액" value={monthly} min={100000} max={3000000} step={50000}
          onChange={setMonthly} fillColor="var(--blue)"
          showReset onReset={()=>setMonthly(sliderCfg.simMonthly)}/>
        <SliderRow label="연 수익률" value={rate} min={1} max={20} step={0.5}
          onChange={setRate} fillColor="var(--green)"
          formatVal={v=>v.toFixed(1)+"%"}
          showReset onReset={()=>setRate(sliderCfg.simRate)}/>
        <SliderRow label="투자 기간" value={years} min={1} max={40} step={1}
          onChange={setYears} fillColor="var(--pink)"
          formatVal={v=>v+"년"}
          showReset onReset={()=>setYears(sliderCfg.simYears)}/>

        <div style={{borderTop:"1px solid var(--border)",paddingTop:16,marginTop:4}}>
          <SliderRow label="🎯 목표 금액" value={goal} min={10000000} max={1000000000} step={10000000}
            onChange={setGoal} fillColor="var(--purple)"
            formatVal={v=>fmtS(v)+"원"}
            showReset onReset={()=>setGoal(sliderCfg.simGoal)}/>
          <div style={{
            background:goalYear>0?"var(--greenD)":"var(--redD)",
            border:`1px solid ${goalYear>0?"rgba(77,171,135,.3)":"rgba(217,95,95,.3)"}`,
            borderRadius:10,padding:"10px 14px",fontSize:12,
            color:goalYear>0?"var(--green)":"var(--red)"
          }}>
            {goalYear>0
              ?`✓ ${goalYear}년 후 달성 예상 (${YEAR+goalYear}년)`
              :`✗ ${years}년 내 달성 불가 — 저축액이나 수익률을 높여보세요`
            }
          </div>
        </div>
      </Card>

      {/* Result */}
      <div className="u3" style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:10}}>
        {[
          {label:"최종 금액",  val:fmtS(final.복리성장)+"원",c:"var(--goldL)", icon:"💰"},
          {label:"복리 추가수익",val:fmtS(final.복리성장-final.단순저축)+"원",c:"var(--green)",icon:"📈"},
          {label:"원금 대비",  val:multiple+"배",             c:"var(--purple)",icon:"✨"},
        ].map(c=>(
          <Card key={c.label} style={{padding:"13px 8px",textAlign:"center"}}>
            <div style={{fontSize:18,marginBottom:5}}>{c.icon}</div>
            <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{c.label}</div>
            <div style={{fontSize:13,fontWeight:700,color:c.c,lineHeight:1.2}}>{c.val}</div>
          </Card>
        ))}
      </div>

      {/* Chart */}
      <Card className="u4" style={{padding:"18px"}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:14}}>■ 성장 곡선</div>
        <div style={{height:210}}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{top:5,right:8,left:0,bottom:5}}>
              <XAxis dataKey="year" tick={{fill:"var(--text3)",fontSize:10}} tickLine={false} axisLine={false} tickFormatter={v=>v+"년"}/>
              <YAxis tick={{fill:"var(--text3)",fontSize:10}} tickLine={false} axisLine={false} tickFormatter={fmtS} width={40}/>
              <Tooltip content={simTooltip}/>
              {goalYear>0&&<ReferenceLine x={goalYear} stroke="rgba(200,168,75,.5)" strokeDasharray="4 4"/>}
              <Line type="monotone" dataKey="복리성장" stroke="#5c8de8" strokeWidth={2.5} dot={false}/>
              <Line type="monotone" dataKey="단순저축" stroke="#4dab87" strokeWidth={1.5} dot={false} strokeDasharray="5 4"/>
              <Line type="monotone" dataKey="원금"    stroke="rgba(255,255,255,.15)" strokeWidth={1} dot={false} strokeDasharray="3 6"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div style={{display:"flex",gap:16,marginTop:10,justifyContent:"center"}}>
          {[{c:"#5c8de8",l:"복리 성장"},{c:"#4dab87",l:"단순 저축"},{c:"rgba(255,255,255,.25)",l:"원금"}].map(l=>(
            <div key={l.l} style={{display:"flex",alignItems:"center",gap:5}}>
              <div style={{width:14,height:2,background:l.c,borderRadius:1}}/>
              <span style={{fontSize:10,color:"var(--text2)"}}>{l.l}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// CARD VIEW — 카드사별 정산 기간 관리
// ─────────────────────────────────────────────────────────────
function CardView({cards, setCards, tx, names}) {
  const [showAdd, setShowAdd] = useState(false);
  const blank = {name:"", owner:"husband", color:"#1c2340", icon:"💳",
    billingStartDay:13, billingEndDay:14, billingEndNextMonth:true, paymentDay:23};
  const [nc, setNc] = useState({...blank});
  const iStyle = {background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,
    padding:"9px 12px",color:"var(--text)",fontSize:13,outline:"none",width:"100%"};

  const addCard = () => {
    if (!nc.name.trim()) return;
    setCards(cs => [...cs, {...nc, id:"card_"+Date.now()}]);
    setNc({...blank}); setShowAdd(false);
  };
  const delCard = id => setCards(cs => cs.filter(c => c.id !== id));

  return (
    <div className="u4">
      {/* 헤더 안내 */}
      <div style={{
        background:"var(--blueD)",border:"1px solid rgba(92,141,232,.2)",
        borderRadius:14,padding:"13px 15px",marginBottom:14,
        display:"flex",gap:10,alignItems:"flex-start"
      }}>
        <span style={{fontSize:18,flexShrink:0}}>💡</span>
        <div style={{fontSize:11,color:"var(--text2)",lineHeight:1.7}}>
          카드사별 정산 기간을 등록하면 결제일 기준 <strong style={{color:"var(--text)"}}>실제 납부 예정금액</strong>을 정확하게 계산합니다. 지출 입력 시 카드를 선택하면 자동으로 집계돼요.
        </div>
      </div>

      {/* 카드 목록 */}
      {cards.length === 0 ? (
        <div style={{padding:"32px 16px",textAlign:"center",color:"var(--text3)"}}>
          <div style={{fontSize:36,marginBottom:10}}>💳</div>
          <div style={{fontSize:13,color:"var(--text2)",marginBottom:5}}>등록된 카드가 없어요</div>
          <div style={{fontSize:11,lineHeight:1.7}}>아래 버튼으로 카드를 추가하면<br/>정산 기간 기준 청구 예정금액을 확인할 수 있어요</div>
        </div>
      ) : cards.map(card => {
        const { cycleStart, cycleEnd, payDate, daysUntilPay } = getBillingPeriod(card);
        const s = toDateStr(cycleStart), e = toDateStr(cycleEnd);
        const cardTx = tx.filter(t => t.cardId === card.id && t.date >= s && t.date <= e);
        const total  = cardTx.reduce((sum,t) => sum+t.amount, 0);
        const isPast = daysUntilPay < 0;
        const isNear = daysUntilPay >= 0 && daysUntilPay <= 7;

        return (
          <div key={card.id} style={{marginBottom:12,borderRadius:18,overflow:"hidden",border:"1px solid var(--border)"}}>
            {/* 카드 헤더 */}
            <div style={{
              background:`linear-gradient(135deg, ${card.color}f0, ${card.color}a0)`,
              padding:"18px 16px 14px",position:"relative",
            }}>
              {/* D-day 뱃지 */}
              <div style={{
                position:"absolute",top:14,right:14,
                background:isPast?"rgba(0,0,0,.4)":isNear?"rgba(220,60,60,.8)":"rgba(0,0,0,.35)",
                borderRadius:99,padding:"4px 10px",
                fontSize:11,fontWeight:700,color:"#fff",letterSpacing:".04em"
              }}>
                {isPast ? "결제 완료" : `D-${daysUntilPay}`}
              </div>
              <div style={{fontSize:11,color:"rgba(255,255,255,.55)",marginBottom:4}}>
                {card.owner==="husband"?names.husband:names.wife}
              </div>
              <div style={{fontSize:17,fontWeight:700,color:"#fff",marginBottom:10}}>
                {card.icon} {card.name}
              </div>
              <div style={{display:"flex",gap:16}}>
                <div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,.5)",marginBottom:2}}>정산 기간</div>
                  <div style={{fontSize:12,fontWeight:600,color:"rgba(255,255,255,.85)"}}>
                    {fmtPeriodLabel(cycleStart, cycleEnd)}
                  </div>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,.5)",marginBottom:2}}>결제일</div>
                  <div style={{fontSize:12,fontWeight:600,color:isNear&&!isPast?"#ffb3b3":"rgba(255,255,255,.85)"}}>
                    {fmtMonthDay(payDate)}
                  </div>
                </div>
              </div>
            </div>

            {/* 청구 금액 */}
            <div style={{background:"var(--bg2)",padding:"14px 16px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:10}}>
                <div>
                  <div style={{fontSize:11,color:"var(--text2)",marginBottom:3}}>
                    {isPast ? "청구 금액 (확정)" : "청구 예정금액"}
                  </div>
                  <div style={{fontSize:22,fontWeight:700,
                    color:total>0?(isNear&&!isPast?"var(--red)":"var(--text)"):"var(--text3)"
                  }}>
                    {fmt(total)}
                  </div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:11,color:"var(--text2)"}}>내역 {cardTx.length}건</div>
                  {!isPast && daysUntilPay >= 0 && (
                    <div style={{fontSize:11,color:"var(--text2)",marginTop:2}}>
                      {daysUntilPay === 0 ? "⚠️ 오늘 결제" : `${daysUntilPay}일 후 결제`}
                    </div>
                  )}
                </div>
              </div>

              {/* 이번 주기 지출 내역 미리보기 */}
              {cardTx.length > 0 ? (
                <div style={{borderTop:"1px solid var(--border)",paddingTop:10}}>
                  {cardTx.slice(-4).reverse().map(t => {
                    const c = CAT[t.cat]||CATS[8];
                    return (
                      <div key={t.id} style={{
                        display:"flex",justifyContent:"space-between",alignItems:"center",
                        padding:"4px 0",fontSize:12
                      }}>
                        <span style={{color:"var(--text2)"}}>
                          {c.icon} {c.label}
                          {t.memo && <span style={{color:"var(--text3)"}}> · {t.memo}</span>}
                          <span style={{color:"var(--text3)",fontSize:10}}> {t.date.slice(5)}</span>
                        </span>
                        <span style={{fontWeight:600,color:"var(--text)",flexShrink:0,marginLeft:8}}>
                          {fmtS(t.amount)}원
                        </span>
                      </div>
                    );
                  })}
                  {cardTx.length > 4 && (
                    <div style={{fontSize:11,color:"var(--text3)",paddingTop:4}}>외 {cardTx.length-4}건 더</div>
                  )}
                </div>
              ) : (
                <div style={{
                  fontSize:11,color:"var(--text3)",paddingTop:8,borderTop:"1px solid var(--border)"
                }}>이번 정산 기간 내 해당 카드 내역 없음</div>
              )}

              {/* 삭제 */}
              <button onClick={()=>delCard(card.id)} style={{
                marginTop:10,width:"100%",padding:"7px",
                background:"transparent",border:"1px solid var(--border)",
                borderRadius:9,color:"var(--text3)",fontSize:11,cursor:"pointer"
              }}>카드 삭제</button>
            </div>
          </div>
        );
      })}

      {/* 카드 추가 폼 */}
      {showAdd ? (
        <Card style={{padding:"18px",marginBottom:10}}>
          <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>+ 카드 등록</div>

          {/* 카드명 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>카드사 / 카드명</div>
            <input placeholder="예: 현대카드 M" value={nc.name}
              onChange={e=>setNc(v=>({...v,name:e.target.value}))} style={iStyle}/>
          </div>

          {/* 사용자 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>사용자</div>
            <div style={{display:"flex",gap:6}}>
              {["husband","wife"].map(w=>(
                <button key={w} onClick={()=>setNc(v=>({...v,owner:w}))} style={{
                  flex:1,padding:"9px",borderRadius:10,cursor:"pointer",fontWeight:600,fontSize:12,
                  background:nc.owner===w?(w==="husband"?"var(--hD)":"var(--wD)"):"var(--bg4)",
                  border:`1px solid ${nc.owner===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,
                  color:nc.owner===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)"
                }}>{w==="husband"?names.husband:names.wife}</button>
              ))}
            </div>
          </div>

          {/* 정산 타입 선택 */}
          <div style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>정산 기간 유형</div>
            <div style={{display:"flex",gap:6}}>
              {[
                {v:false, l:"당월 정산", desc:"예: 1일~말일 → 다음달 결제"},
                {v:true,  l:"익월 정산", desc:"예: 13일~다음달14일 → 다음달23일 결제"},
              ].map(t=>(
                <button key={String(t.v)} onClick={()=>setNc(v=>({...v,billingEndNextMonth:t.v}))} style={{
                  flex:1,padding:"9px 6px",borderRadius:10,cursor:"pointer",
                  background:nc.billingEndNextMonth===t.v?"var(--goldD)":"var(--bg4)",
                  border:`1px solid ${nc.billingEndNextMonth===t.v?"var(--gold)":"var(--border)"}`,
                  textAlign:"center"
                }}>
                  <div style={{fontSize:11,fontWeight:700,color:nc.billingEndNextMonth===t.v?"var(--gold)":"var(--text2)",marginBottom:2}}>{t.l}</div>
                  <div style={{fontSize:9,color:"var(--text3)"}}>{t.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* 날짜 설정 */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
            {[
              {label:"정산 시작일", key:"billingStartDay", suffix:"일부터"},
              {label:nc.billingEndNextMonth?"마감일 (익월)":"정산 마감일", key:"billingEndDay", suffix:"일까지"},
              {label:"결제일 (익월)", key:"paymentDay", suffix:"일"},
            ].map(f=>(
              <div key={f.key}>
                <div style={{fontSize:10,color:"var(--text2)",marginBottom:4}}>{f.label}</div>
                <div style={{position:"relative"}}>
                  <input type="number" min={1} max={31} value={nc[f.key]}
                    onChange={e=>setNc(v=>({...v,[f.key]:Math.min(31,Math.max(1,parseInt(e.target.value)||1))}))}
                    style={{...iStyle,textAlign:"center",paddingRight:6}}/>
                  <div style={{fontSize:10,color:"var(--text3)",textAlign:"center",marginTop:3}}>{f.suffix}</div>
                </div>
              </div>
            ))}
          </div>

          {/* 미리보기 */}
          {(() => {
            try {
              const preview = getBillingPeriod(nc);
              return (
                <div style={{
                  background:"var(--greenD)",border:"1px solid rgba(77,171,135,.25)",
                  borderRadius:10,padding:"10px 13px",marginBottom:12,fontSize:11
                }}>
                  <div style={{fontWeight:700,color:"var(--green)",marginBottom:4}}>✓ 정산 미리보기</div>
                  <div style={{color:"var(--text2)",lineHeight:1.8}}>
                    현재 주기: <strong style={{color:"var(--text)"}}>{fmtPeriodLabel(preview.cycleStart, preview.cycleEnd)}</strong><br/>
                    결제일: <strong style={{color:"var(--text)"}}>{fmtMonthDay(preview.payDate)}</strong>
                    {preview.daysUntilPay>=0 && <span style={{color:"var(--text3)"}}> (D-{preview.daysUntilPay})</span>}
                  </div>
                </div>
              );
            } catch { return null; }
          })()}

          {/* 색상 선택 */}
          <div style={{marginBottom:14}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:7}}>카드 색상</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {CARD_PRESETS_COLOR.map(c=>(
                <button key={c} onClick={()=>setNc(v=>({...v,color:c}))} style={{
                  width:28,height:28,borderRadius:8,background:c,border:"none",cursor:"pointer",
                  outline:nc.color===c?"2px solid var(--goldL)":"2px solid transparent",
                  outlineOffset:2,transition:"outline .15s"
                }}/>
              ))}
            </div>
          </div>

          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>{setShowAdd(false);setNc({...blank});}} style={{
              flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",
              borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12
            }}>취소</button>
            <button onClick={addCard} style={{
              flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",
              borderRadius:11,color:"var(--gold)",fontWeight:700,fontSize:13,cursor:"pointer"
            }}>카드 등록</button>
          </div>
        </Card>
      ) : (
        <button onClick={()=>setShowAdd(true)} style={{
          width:"100%",padding:"13px",background:"transparent",
          border:"1px dashed var(--border2)",borderRadius:13,
          color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600
        }}>💳 카드 추가</button>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// FIXED + INSTALLMENT VIEW
// ─────────────────────────────────────────────────────────────
function FixedView({fixed,setFixed,install,setInstall,cards,setCards,tx,names}){
  const [tab,setTab]=useState("fixed");
  const [showAdd,setShowAdd]=useState(false);
  const [nf,setNf]=useState({name:"",amount:"",cat:"etc",icon:"📦"});
  const [showAddI,setShowAddI]=useState(false);
  const [ni,setNi]=useState({name:"",monthly:"",total:"",paidN:"0",cat:"etc",icon:"💳"});
  const fixedTotal  =fixed.reduce((s,f)=>s+f.amount,0);
  const installTotal=install.reduce((s,i)=>s+i.monthly,0);
  const paidFixed   =fixed.filter(f=>f.paid).reduce((s,f)=>s+f.amount,0);
  const togglePaid  =id=>setFixed(fs=>fs.map(f=>f.id===id?{...f,paid:!f.paid}:f));
  const iStyle={width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"9px 13px",color:"var(--text)",fontSize:13,outline:"none"};

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub="Fixed Costs" title="고정비 · 할부"/></div>
      <div className="u2" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
        <Card style={{padding:"14px"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>이달 고정비</div>
          <div style={{fontSize:18,fontWeight:700,color:"var(--gold)"}}>{fmtS(fixedTotal)}원</div>
          <div style={{fontSize:11,color:"var(--text2)",marginTop:3}}>납부 {fmtS(paidFixed)} / 미납 {fmtS(fixedTotal-paidFixed)}</div>
          <div style={{marginTop:8}}><Bar pct={fixedTotal>0?paidFixed/fixedTotal*100:0} color="var(--gold)" h={4}/></div>
        </Card>
        <Card style={{padding:"14px"}}>
          <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>월 할부 부담</div>
          <div style={{fontSize:18,fontWeight:700,color:"var(--pink)"}}>{fmtS(installTotal)}원</div>
          <div style={{fontSize:11,color:"var(--text2)",marginTop:3}}>{install.length}건</div>
          <div style={{marginTop:8}}><Bar pct={install.length>0?Math.round(install.reduce((s,i)=>s+i.paid,0)/install.reduce((s,i)=>s+i.total,0)*100):0} color="var(--pink)" h={4}/></div>
        </Card>
      </div>
      <div className="u3" style={{display:"flex",gap:6,marginBottom:12}}>
        {[
          {id:"fixed",  l:`고정비 (${fixed.length})`},
          {id:"install",l:`할부 (${install.length})`},
          {id:"card",   l:`💳 카드 (${cards.length})`},
        ].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            flex:1,padding:"8px 4px",borderRadius:11,cursor:"pointer",fontWeight:700,fontSize:11,
            background:tab===t.id?"var(--goldD)":"transparent",
            border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,
            color:tab===t.id?"var(--gold)":"var(--text2)"
          }}>{t.l}</button>
        ))}
      </div>
      {tab==="fixed"&&(
        <div className="u4">
          <Card style={{overflow:"hidden",marginBottom:10}}>
            {fixed.map(f=>{const c=CAT[f.cat]||CATS[8];return(
              <div key={f.id} style={{padding:"11px 13px",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:34,height:34,borderRadius:10,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,flexShrink:0}}>{f.icon}</div>
                <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600}}>{f.name}</div><div style={{fontSize:11,color:"var(--text2)"}}>{c.label}</div></div>
                <div style={{textAlign:"right",marginRight:6}}>
                  <div style={{fontSize:14,fontWeight:700}}>{fmtS(f.amount)}원</div>
                  <div style={{fontSize:10,color:f.paid?"var(--green)":"var(--red)"}}>{f.paid?"납부완료":"미납"}</div>
                </div>
                <button onClick={()=>togglePaid(f.id)} style={{width:28,height:28,borderRadius:8,border:"none",cursor:"pointer",fontSize:13,flexShrink:0,background:f.paid?"var(--greenD)":"var(--bg4)",color:f.paid?"var(--green)":"var(--text2)"}}>{f.paid?"✓":"○"}</button>
                <button onClick={()=>setFixed(fs=>fs.filter(x=>x.id!==f.id))} style={{width:22,height:22,borderRadius:6,border:"none",cursor:"pointer",fontSize:12,flexShrink:0,background:"transparent",color:"var(--text3)"}}>✕</button>
              </div>
            );})}
          </Card>
          {showAdd?(
            <Card style={{padding:"16px",marginBottom:10}}>
              <div style={{fontSize:12,fontWeight:700,marginBottom:12,color:"var(--text2)"}}>+ 고정비 추가</div>
              <input placeholder="항목명" value={nf.name} onChange={e=>setNf(v=>({...v,name:e.target.value}))} style={{...iStyle,marginBottom:8}}/>
              <input type="number" placeholder="월 금액" value={nf.amount} onChange={e=>setNf(v=>({...v,amount:e.target.value}))} style={{...iStyle,marginBottom:10}}/>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:12}}>
                {CATS.slice(0,6).map(c=>(
                  <button key={c.id} onClick={()=>setNf(v=>({...v,cat:c.id,icon:c.icon}))} style={{background:nf.cat===c.id?c.color+"25":"var(--bg4)",border:`1px solid ${nf.cat===c.id?c.color+"66":"var(--border)"}`,borderRadius:10,padding:"8px 4px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3}}>
                    <span style={{fontSize:15}}>{c.icon}</span><span style={{fontSize:9,color:"var(--text2)"}}>{c.label}</span>
                  </button>
                ))}
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setShowAdd(false)} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>취소</button>
                <button onClick={()=>{if(!nf.name||!nf.amount)return;setFixed(fs=>[...fs,{id:Date.now(),name:nf.name,amount:parseInt(nf.amount),cat:nf.cat,icon:nf.icon,paid:false}]);setNf({name:"",amount:"",cat:"etc",icon:"📦"});setShowAdd(false);}} style={{flex:2,padding:"10px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:10,color:"var(--goldL)",cursor:"pointer",fontWeight:700,fontSize:12}}>추가</button>
              </div>
            </Card>
          ):(
            <button onClick={()=>setShowAdd(true)} style={{width:"100%",padding:"12px",background:"transparent",border:"1px dashed var(--border2)",borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600}}>+ 고정비 추가</button>
          )}
        </div>
      )}
      {tab==="install"&&(
        <div className="u4">
          {install.map(item=>{
            const pct=Math.round(item.paid/item.total*100);
            const remain=(item.total-item.paid)*item.monthly;
            return(
              <Card key={item.id} style={{padding:"16px",marginBottom:8}}>
                <div style={{display:"flex",gap:10,marginBottom:12}}>
                  <div style={{width:38,height:38,borderRadius:11,background:"var(--pinkD)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{item.icon}</div>
                  <div style={{flex:1}}><div style={{fontSize:14,fontWeight:700,marginBottom:2}}>{item.name}</div><div style={{fontSize:11,color:"var(--text2)"}}>월 {fmtS(item.monthly)}원 · {item.paid}/{item.total}회차</div></div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:13,fontWeight:700,color:"var(--pink)"}}>{fmtS(remain)}원 잔여</div>
                    <div style={{fontSize:10,color:"var(--text2)"}}>{item.total-item.paid}회 남음</div>
                  </div>
                  <button onClick={()=>setInstall(is=>is.filter(x=>x.id!==item.id))} style={{width:22,height:22,borderRadius:6,border:"none",cursor:"pointer",background:"transparent",color:"var(--text3)",fontSize:12,flexShrink:0,alignSelf:"flex-start"}}>✕</button>
                </div>
                <Bar pct={pct} color="var(--pink)" h={5}/>
                <div style={{display:"flex",justifyContent:"space-between",marginTop:5}}><span style={{fontSize:10,color:"var(--text2)"}}>진행 {pct}%</span><span style={{fontSize:10,color:"var(--text2)"}}>완납 {item.total}회차</span></div>
              </Card>
            );
          })}
          {showAddI?(
            <Card style={{padding:"16px",marginBottom:10}}>
              <div style={{fontSize:12,fontWeight:700,marginBottom:12,color:"var(--text2)"}}>+ 할부 추가</div>
              <input placeholder="항목명" value={ni.name} onChange={e=>setNi(v=>({...v,name:e.target.value}))} style={{...iStyle,marginBottom:8}}/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
                <input type="number" placeholder="월 납부액" value={ni.monthly} onChange={e=>setNi(v=>({...v,monthly:e.target.value}))} style={iStyle}/>
                <input type="number" placeholder="총 회차" value={ni.total} onChange={e=>setNi(v=>({...v,total:e.target.value}))} style={iStyle}/>
              </div>
              <input type="number" placeholder="완납 회차 (현재)" value={ni.paidN} onChange={e=>setNi(v=>({...v,paidN:e.target.value}))} style={{...iStyle,marginBottom:12}}/>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setShowAddI(false)} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>취소</button>
                <button onClick={()=>{if(!ni.name||!ni.monthly||!ni.total)return;setInstall(is=>[...is,{id:Date.now(),name:ni.name,monthly:parseInt(ni.monthly),total:parseInt(ni.total),paid:parseInt(ni.paidN)||0,cat:ni.cat,icon:ni.icon}]);setNi({name:"",monthly:"",total:"",paidN:"0",cat:"etc",icon:"💳"});setShowAddI(false);}} style={{flex:2,padding:"10px",background:"var(--pinkD)",border:"1px solid var(--pink)",borderRadius:10,color:"var(--pink)",cursor:"pointer",fontWeight:700,fontSize:12}}>추가</button>
              </div>
            </Card>
          ):(
            <button onClick={()=>setShowAddI(true)} style={{width:"100%",padding:"12px",background:"transparent",border:"1px dashed var(--border2)",borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:13,fontWeight:600}}>+ 할부 추가</button>
          )}
        </div>
      )}
      {tab==="card"&&(
        <CardView cards={cards} setCards={setCards} tx={tx} names={names}/>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ★ SETTINGS VIEW — 이름, 예산 슬라이더, 슬라이더 초기값 통합 관리
// ─────────────────────────────────────────────────────────────
function SettingsView({names,setNames,budgets,setBudgets,sliderCfg,setSliderCfg,theme,setTheme,resetAll,householdId,myRole,leaveHousehold}){
  const [n,setN]     = useState({...names});
  const [tab,setTab] = useState("budget");
  const [cfg,setCfg] = useState({...sliderCfg});
  const totalBudget  = Object.values(budgets).reduce((s,v)=>s+v,0);
  const budgetMax    = sliderCfg.budgetSliderMax;
  const iStyle       = {width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"9px 13px",color:"var(--text)",fontSize:13,outline:"none"};

  const saveCfg=()=>setSliderCfg({...cfg});

  return(
    <div style={{padding:"0 16px 96px",overflowY:"auto",height:"100%"}}>
      <div className="u1"><SectionHeader sub="Settings" title="설정"/></div>

      {/* 테마 선택 */}
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 화면 모드</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          {[
            {id:"dark", label:"🌙 다크 모드", desc:"어두운 배경"},
            {id:"light",label:"☀️ 라이트 모드",desc:"밝은 배경"},
          ].map(t=>(
            <button key={t.id} onClick={()=>setTheme(t.id)} style={{
              padding:"14px 10px",borderRadius:14,cursor:"pointer",textAlign:"center",
              background:theme===t.id?"var(--goldD)":"var(--bg3)",
              border:`2px solid ${theme===t.id?"var(--gold)":"var(--border)"}`,
              transition:"all .2s"
            }}>
              <div style={{fontSize:22,marginBottom:6}}>{t.label.split(" ")[0]}</div>
              <div style={{fontSize:12,fontWeight:700,color:theme===t.id?"var(--gold)":"var(--text2)"}}>{t.label.split(" ").slice(1).join(" ")}</div>
              <div style={{fontSize:10,color:"var(--text3)",marginTop:2}}>{t.desc}</div>
            </button>
          ))}
        </div>
      </Card>
      <Card className="u2" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 이름 설정</div>
        {["husband","wife"].map(w=>(
          <div key={w} style={{marginBottom:10}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:5}}>{w==="husband"?"남편":"와이프"}</div>
            <input value={n[w]} onChange={e=>setN(v=>({...v,[w]:e.target.value}))} style={iStyle}/>
          </div>
        ))}
        <button onClick={()=>setNames(n)} style={{width:"100%",marginTop:6,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>저장</button>
      </Card>

      {/* 가정 연결 정보 */}
      <Card className="u3" style={{padding:"18px",marginBottom:10}}>
        <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:13}}>■ 가정 연결 정보</div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:4}}>가정 코드</div>
            <div style={{fontSize:24,fontWeight:700,letterSpacing:".12em",color:"var(--gold)"}}>{householdId}</div>
          </div>
          <div style={{
            background:myRole==="husband"?"var(--hD)":"var(--wD)",
            color:myRole==="husband"?"var(--h)":"var(--w)",
            padding:"8px 16px",borderRadius:99,fontWeight:700,fontSize:13
          }}>
            {myRole==="husband"?names.husband:names.wife}
          </div>
        </div>
        <div style={{
          background:"var(--bg3)",borderRadius:12,padding:"12px 14px",
          fontSize:12,color:"var(--text2)",lineHeight:1.7,marginBottom:12
        }}>
          이 코드를 와이프에게 공유하세요.<br/>
          앱 첫 화면에서 <strong style={{color:"var(--text)"}}>코드로 참여하기</strong> 선택 후<br/>
          <strong style={{color:"var(--gold)"}}>{householdId}</strong>를 입력하면 연결됩니다.
        </div>
        <button onClick={()=>{
          if(window.confirm("가계부에서 나가면 이 기기의 연결이 끊깁니다.\n데이터는 유지됩니다. 나가시겠어요?"))
            leaveHousehold();
        }} style={{
          width:"100%",padding:"10px",background:"transparent",
          border:"1px solid var(--border2)",borderRadius:10,
          color:"var(--text3)",fontSize:12,cursor:"pointer"
        }}>다른 코드로 연결하기</button>
      </Card>
      <div className="u3" style={{display:"flex",gap:6,marginBottom:12}}>
        {[{id:"budget",l:"예산 슬라이더"},{id:"sim",l:"시뮬레이터 초기값"},{id:"pace",l:"Pace 설정"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px 4px",borderRadius:10,cursor:"pointer",fontWeight:700,fontSize:11,background:tab===t.id?"var(--goldD)":"transparent",border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,color:tab===t.id?"var(--goldL)":"var(--text2)"}}>{t.l}</button>
        ))}
      </div>

      {/* ── 예산 슬라이더 탭 ── */}
      {tab==="budget"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ 카테고리별 예산</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:14}}>슬라이더 최대값: {fmtS(budgetMax)}원 (하단 Pace 설정에서 변경)</div>
          {/* Live stacked bar */}
          <div style={{display:"flex",height:20,borderRadius:9,overflow:"hidden",marginBottom:12}}>
            {CATS.map(c=>{
              const pct=totalBudget>0?(budgets[c.id]||0)/totalBudget*100:0;
              return <div key={c.id} style={{width:`${pct}%`,background:c.color,transition:"width .3s ease",minWidth:pct>0?2:0}} title={`${c.label} ${Math.round(pct)}%`}/>;
            })}
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:"4px 10px",marginBottom:16}}>
            {CATS.filter(c=>totalBudget>0&&(budgets[c.id]||0)/totalBudget>.02).map(c=>(
              <div key={c.id} style={{display:"flex",alignItems:"center",gap:4}}>
                <div style={{width:6,height:6,borderRadius:1,background:c.color}}/>
                <span style={{fontSize:9,color:"var(--text2)"}}>{c.label} {Math.round((budgets[c.id]||0)/totalBudget*100)}%</span>
              </div>
            ))}
          </div>
          {CATS.map(c=>{
            const val = budgets[c.id]||0;
            const pct = totalBudget>0 ? Math.round(val/totalBudget*100) : 0;
            return(
              <div key={c.id} style={{marginBottom:18}}>
                {/* 라벨 + 직접입력 */}
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <div style={{display:"flex",alignItems:"center",gap:6}}>
                    <span style={{fontSize:15}}>{c.icon}</span>
                    <span style={{fontSize:13,fontWeight:500}}>{c.label}</span>
                    <span style={{fontSize:10,color:"var(--text3)",background:"var(--bg3)",borderRadius:99,padding:"1px 6px"}}>{pct}%</span>
                  </div>
                  <input
                    type="number"
                    value={val===0?"":val}
                    placeholder="0"
                    onChange={e=>{
                      const v=parseInt(e.target.value)||0;
                      setBudgets(b=>({...b,[c.id]:v}));
                    }}
                    style={{
                      width:100,background:"var(--bg4)",border:"1px solid var(--border2)",
                      borderRadius:8,padding:"5px 9px",fontSize:13,fontWeight:700,
                      color:c.color,textAlign:"right",outline:"none"
                    }}
                  />
                </div>
                {/* 슬라이더 */}
                <input
                  type="range"
                  min={0} max={budgetMax} step={10000}
                  value={Math.min(val, budgetMax)}
                  onChange={e=>setBudgets(b=>({...b,[c.id]:+e.target.value}))}
                  style={{background:`linear-gradient(to right, ${c.color} 0%, ${c.color} ${Math.min(val,budgetMax)/budgetMax*100}%, var(--track) ${Math.min(val,budgetMax)/budgetMax*100}%, var(--track) 100%)`}}
                />
              </div>
            );
          })}
          <div style={{paddingTop:14,borderTop:"1px solid var(--border)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>총 예산</span>
            <span style={{fontSize:17,fontWeight:700,color:"var(--goldL)"}}>{fmt(totalBudget)}</span>
          </div>
          <button onClick={()=>setBudgets({...INIT_BUDGETS})} style={{width:"100%",marginTop:12,padding:"11px",background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:11,color:"var(--red)",fontWeight:700,fontSize:12,cursor:"pointer"}}>예산 전체 초기화</button>
        </Card>
      )}

      {/* ── 시뮬레이터 초기값 탭 ── */}
      {tab==="sim"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ 시뮬레이터 초기값 설정</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16}}>시뮬레이터 탭 진입 시 기본값으로 사용됩니다</div>
          {[
            {key:"simInitAmt",  l:"초기 투자금",    min:1000000,  max:100000000, step:1000000, fv:undefined},
            {key:"simMonthly",  l:"월 저축액",      min:100000,   max:3000000,   step:50000,  fv:undefined},
            {key:"simRate",     l:"연 수익률",      min:1,        max:20,        step:0.5,    fv:(v)=>v.toFixed(1)+"%"},
            {key:"simYears",    l:"투자 기간",      min:1,        max:40,        step:1,      fv:(v)=>v+"년"},
            {key:"simGoal",     l:"목표 금액",      min:10000000, max:1000000000,step:10000000,fv:(v)=>fmtS(v)+"원"},
          ].map(r=>(
            <SliderRow key={r.key}
              label={r.l}
              value={cfg[r.key]}
              min={r.min} max={r.max} step={r.step}
              onChange={v=>setCfg(c=>({...c,[r.key]:v}))}
              fillColor="var(--blue)"
              formatVal={r.fv}
            />
          ))}
          <div style={{display:"flex",gap:8,marginTop:4}}>
            <button onClick={()=>setCfg({...sliderCfg})} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>되돌리기</button>
            <button onClick={saveCfg} style={{flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>초기값 저장</button>
          </div>
        </Card>
      )}

      {/* ── Pace 설정 탭 ── */}
      {tab==="pace"&&(
        <Card className="u4" style={{padding:"20px",marginBottom:10}}>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".06em",marginBottom:6}}>■ Pace 슬라이더 범위 설정</div>
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16}}>홈 화면 일평균 목표 지출 슬라이더의 최대값을 설정합니다</div>
          <SliderRow
            label="일 지출 슬라이더 최대값"
            value={cfg.paceMaxDaily}
            min={50000} max={1000000} step={50000}
            onChange={v=>setCfg(c=>({...c,paceMaxDaily:v}))}
            fillColor="var(--gold)"
            formatVal={v=>fmtS(v)+"원/일"}
          />
          <div style={{fontSize:11,color:"var(--text3)",marginBottom:16,marginTop:-4}}>예산 슬라이더 최대값 (카테고리별)</div>
          <SliderRow
            label="예산 슬라이더 최대값"
            value={cfg.budgetSliderMax}
            min={500000} max={5000000} step={100000}
            onChange={v=>setCfg(c=>({...c,budgetSliderMax:v}))}
            fillColor="var(--purple)"
            formatVal={v=>fmtS(v)+"원"}
          />
          <div style={{display:"flex",gap:8,marginTop:8}}>
            <button onClick={()=>setCfg({...sliderCfg})} style={{flex:1,padding:"10px",background:"transparent",border:"1px solid var(--border)",borderRadius:10,color:"var(--text2)",cursor:"pointer",fontSize:12}}>되돌리기</button>
            <button onClick={saveCfg} style={{flex:2,padding:"11px",background:"var(--goldD)",border:"1px solid var(--gold)",borderRadius:11,color:"var(--goldL)",fontWeight:700,fontSize:12,cursor:"pointer"}}>저장</button>
          </div>
          <button onClick={()=>{setCfg({...DEFAULT_SLIDER_CFG});setSliderCfg({...DEFAULT_SLIDER_CFG});}} style={{width:"100%",marginTop:10,padding:"10px",background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:10,color:"var(--red)",fontWeight:700,fontSize:12,cursor:"pointer"}}>모든 슬라이더 공장초기화</button>
        </Card>
      )}

      <div style={{textAlign:"center",padding:"20px 0",color:"var(--text3)",fontSize:10,letterSpacing:".06em"}}>가정 경영 가계부 v5.0</div>

      {/* 데이터 초기화 */}
      <Card style={{padding:"18px",marginBottom:20,border:"1px solid var(--redD)"}}>
        <div style={{fontSize:11,color:"var(--red)",letterSpacing:".06em",marginBottom:10}}>■ 데이터 초기화</div>
        <div style={{fontSize:12,color:"var(--text2)",marginBottom:14,lineHeight:1.6}}>
          지출 내역, 고정비, 할부 내역을 모두 삭제합니다.<br/>
          예산과 설정값은 유지됩니다.
        </div>
        <button onClick={()=>{if(window.confirm("모든 내역을 초기화할까요? 이 작업은 되돌릴 수 없습니다.")) resetAll();}} style={{
          width:"100%",padding:"12px",background:"var(--redD)",
          border:"1px solid var(--red)",borderRadius:11,
          color:"var(--red)",fontWeight:700,fontSize:13,cursor:"pointer"
        }}>모든 내역 초기화</button>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// INPUT MODAL
// ─────────────────────────────────────────────────────────────
async function runOCR(file){
  const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
  const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:512,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:base64}},{type:"text",text:`영수증 분석. JSON만 응답:\n{"merchant":"가맹점","amount":숫자,"date":"YYYY-MM-DD","category":"food|transport|medical|education|housing|culture|clothing|sub|etc","memo":"메모"}\n오늘:${today_str()}`}]}]})});
  const data=await resp.json();
  return JSON.parse(data.content?.map(i=>i.text||"").join("").replace(/```json|```/g,"").trim());
}

function InputModal({defaultWho,names,onClose,onSave}){
  const [mode,setMode]=useState("manual");
  const [who,setWho]=useState(defaultWho||"husband");
  const [amount,setAmount]=useState("");
  const [cat,setCat]=useState("");
  const [memo,setMemo]=useState("");
  const [ocr,setOcr]=useState("idle");
  const [ocrMsg,setOcrMsg]=useState("");
  const num=v=>{if(v==="⌫")setAmount(a=>a.slice(0,-1));else if(v==="000")setAmount(a=>(a+"000").slice(0,9));else setAmount(a=>(a+v).slice(0,9));};
  const handleFile=async e=>{
    const f=e.target.files[0];if(!f)return;
    setOcr("loading");setOcrMsg("Claude AI 분석 중...");
    try{const r=await runOCR(f);setAmount(String(r.amount||""));setCat(r.category||"");setMemo(r.memo||r.merchant||"");setOcr("done");setOcrMsg(`✓ ${r.merchant||"가맹점"} · ${(r.amount||0).toLocaleString()}원`);setMode("manual");}
    catch{setOcr("error");setOcrMsg("인식 실패 · 직접 입력해주세요");}
  };
  const save=()=>{if(!amount||!cat)return;onSave({who,amount:parseInt(amount),cat,memo,date:today_str()});onClose();};
  const pad=["1","2","3","4","5","6","7","8","9","000","0","⌫"];
  return(
    <div style={{position:"fixed",inset:0,zIndex:200,background:"rgba(0,0,0,.82)",backdropFilter:"blur(10px)",display:"flex",flexDirection:"column",justifyContent:"flex-end",animation:"fadeIn .2s ease"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:"var(--bg3)",borderRadius:"22px 22px 0 0",border:"1px solid var(--border2)",borderBottom:"none",padding:"6px 18px 28px",maxHeight:"92dvh",overflowY:"auto",animation:"slideUp .3s ease"}}>
        <div style={{width:36,height:4,background:"rgba(255,255,255,.1)",borderRadius:99,margin:"10px auto 16px"}}/>
        {ocr!=="idle"&&(<div style={{padding:"9px 13px",borderRadius:11,marginBottom:12,background:ocr==="done"?"var(--greenD)":ocr==="error"?"var(--redD)":"var(--bg4)",border:`1px solid ${ocr==="done"?"rgba(77,171,135,.3)":ocr==="error"?"rgba(217,95,95,.3)":"var(--border)"}`,fontSize:12,color:ocr==="done"?"var(--green)":ocr==="error"?"var(--red)":"var(--text2)",display:"flex",alignItems:"center",gap:6}}>
          {ocr==="loading"&&<span style={{animation:"spin .8s linear infinite",display:"inline-block"}}>⟳</span>}{ocrMsg}
        </div>)}
        <div style={{display:"flex",gap:6,marginBottom:14}}>
          {[{id:"manual",l:"✏️ 직접 입력"},{id:"ocr",l:"📸 영수증 OCR"}].map(m=>(
            <button key={m.id} onClick={()=>setMode(m.id)} style={{flex:1,padding:"9px",borderRadius:11,cursor:"pointer",background:mode===m.id?"var(--goldD)":"transparent",border:`1px solid ${mode===m.id?"var(--gold)":"var(--border)"}`,color:mode===m.id?"var(--goldL)":"var(--text2)",fontWeight:600,fontSize:12}}>{m.l}</button>
          ))}
        </div>
        {mode==="ocr"?(
          <div style={{textAlign:"center",padding:"8px 0 14px"}}>
            <div style={{border:"2px dashed var(--border2)",borderRadius:16,padding:"32px 20px",cursor:"pointer",background:"var(--bg4)"}} onClick={()=>document.getElementById("ocrFileV4")?.click()}>
              <div style={{fontSize:36,marginBottom:10}}>📷</div>
              <div style={{fontSize:14,fontWeight:700,marginBottom:5}}>사진 업로드</div>
              <div style={{fontSize:11,color:"var(--text2)"}}>영수증 · 카드전표 · 결제문자<br/><span style={{fontSize:10,color:"var(--text3)"}}>Claude AI가 자동으로 파싱합니다</span></div>
            </div>
            <input id="ocrFileV4" type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          </div>
        ):(
          <>
            <div style={{display:"flex",gap:7,marginBottom:13}}>
              {["husband","wife"].map(w=>(<button key={w} onClick={()=>setWho(w)} style={{flex:1,padding:"9px",borderRadius:11,cursor:"pointer",background:who===w?(w==="husband"?"var(--hD)":"var(--wD)"):"transparent",border:`1px solid ${who===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,color:who===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)",fontWeight:700,fontSize:13}}>{w==="husband"?names.husband:names.wife}</button>))}
            </div>
            <div style={{background:"var(--bg4)",borderRadius:13,padding:"12px 16px",marginBottom:13,display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
              <span style={{fontSize:11,color:"var(--text2)"}}>금액</span>
              <span style={{fontSize:28,fontWeight:700,color:amount?"var(--text)":"var(--text3)",letterSpacing:"-.02em"}}>{amount?parseInt(amount).toLocaleString():"0"}<span style={{fontSize:14,color:"var(--text2)",marginLeft:2}}>원</span></span>
            </div>
            {!amount&&(<div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:13}}>{pad.map(n=>(<button key={n} onClick={()=>num(n)} style={{background:n==="⌫"?"rgba(255,255,255,.03)":"var(--bg4)",border:"1px solid var(--border)",borderRadius:12,padding:"14px",color:"var(--text)",fontSize:17,fontWeight:500,cursor:"pointer"}}>{n}</button>))}</div>)}
            {amount&&(<div style={{display:"flex",gap:6,marginBottom:13}}>{["⌫","000"].map(n=>(<button key={n} onClick={()=>num(n)} style={{flex:1,background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:10,padding:"8px",color:"var(--text2)",fontSize:13,cursor:"pointer"}}>{n}</button>))}<button onClick={()=>setAmount("")} style={{flex:1,background:"var(--redD)",border:"1px solid rgba(217,95,95,.25)",borderRadius:10,padding:"8px",color:"var(--red)",fontSize:12,cursor:"pointer",fontWeight:600}}>초기화</button></div>)}
            {amount&&(<div style={{marginBottom:13}}><div style={{fontSize:11,color:"var(--text2)",marginBottom:8}}>카테고리</div><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>{CATS.map(c=>(<button key={c.id} onClick={()=>setCat(c.id)} style={{background:cat===c.id?c.color+"25":"var(--bg4)",border:`1px solid ${cat===c.id?c.color+"66":"var(--border)"}`,borderRadius:12,padding:"10px 6px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4}}><span style={{fontSize:17}}>{c.icon}</span><span style={{fontSize:10,color:cat===c.id?"var(--text)":"var(--text2)"}}>{c.label}</span></button>))}</div></div>)}
            {cat&&(<input placeholder="메모 (선택)" value={memo} onChange={e=>setMemo(e.target.value)} style={{width:"100%",background:"var(--bg4)",border:"1px solid var(--border)",borderRadius:11,padding:"11px 14px",color:"var(--text)",fontSize:13,outline:"none",marginBottom:13}}/>)}
            {amount&&cat&&(<button onClick={save} style={{width:"100%",padding:"15px",background:"linear-gradient(135deg,var(--gold),var(--goldL))",border:"none",borderRadius:13,color:"#1a1200",fontWeight:700,fontSize:15,cursor:"pointer",boxShadow:"0 4px 24px rgba(200,168,75,.3)"}}>저장 · {parseInt(amount).toLocaleString()}원</button>)}
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ENTRY VIEW — 전용 입력 탭 (시뮬 자리 대체)
// ─────────────────────────────────────────────────────────────
async function runOCR_entry(file){
  const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
  const resp=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:512,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:base64}},{type:"text",text:`영수증 분석. JSON만 응답:\n{"merchant":"가맹점","amount":숫자,"date":"YYYY-MM-DD","category":"food|transport|medical|education|housing|culture|clothing|sub|etc","memo":"메모"}\n오늘:${today_str()}`}]}]})});
  const data=await resp.json();
  return JSON.parse(data.content?.map(i=>i.text||"").join("").replace(/```json|```/g,"").trim());
}

function EntryView({names,onSave,onDelete,tx,cards}){
  const [mode,  setMode]  = useState("manual");
  const [who,   setWho]   = useState("husband");
  const [amount,setAmount]= useState("");
  const [cat,   setCat]   = useState("");
  const [cardId,setCardId]= useState("");
  const [memo,  setMemo]  = useState("");
  const [saved, setSaved] = useState(false);
  const [ocr,   setOcr]   = useState("idle");
  const [ocrMsg,setOcrMsg]= useState("");

  const myCards = cards.filter(c => c.owner === who);

  const num=v=>{
    if(v==="⌫") setAmount(a=>a.slice(0,-1));
    else if(v==="000") setAmount(a=>(a+"000").slice(0,9));
    else setAmount(a=>(a+v).slice(0,9));
  };
  const reset=()=>{setAmount("");setCat("");setCardId("");setMemo("");setSaved(false);setOcr("idle");setOcrMsg("");};
  const save=()=>{
    if(!amount||!cat) return;
    onSave({who,amount:parseInt(amount),cat,cardId:cardId||null,memo,date:today_str()});
    setSaved(true);
    setTimeout(()=>{setAmount("");setCat("");setCardId("");setMemo("");setSaved(false);},900);
  };

  const handleFile=async e=>{
    const f=e.target.files[0]; if(!f) return;
    setOcr("loading"); setOcrMsg("Claude AI 분석 중...");
    try{
      const r=await runOCR_entry(f);
      setAmount(String(r.amount||"")); setCat(r.category||""); setMemo(r.memo||r.merchant||"");
      setOcr("done"); setOcrMsg(`✓ ${r.merchant||"가맹점"} · ${(r.amount||0).toLocaleString()}원`);
      setMode("manual");
    }catch{ setOcr("error"); setOcrMsg("인식 실패 · 직접 입력해주세요"); }
    e.target.value="";
  };

  const pad=["1","2","3","4","5","6","7","8","9","000","0","⌫"];
  const todayTx=[...tx].filter(t=>t.date===today_str()).sort((a,b)=>b.id-a.id);

  return(
    <div style={{display:"flex",flexDirection:"column",height:"100%",overflowY:"auto",padding:"0 16px 96px"}}>
      {/* Header */}
      <div className="u1" style={{padding:"22px 0 14px",display:"flex",justifyContent:"space-between",alignItems:"flex-end"}}>
        <div>
          <div style={{fontSize:11,color:"var(--text2)",letterSpacing:".08em",textTransform:"uppercase",marginBottom:3}}>Daily Entry</div>
          <div className="serif" style={{fontSize:21}}>지출 입력</div>
        </div>
        <div style={{fontSize:11,color:"var(--text2)",background:"var(--bg3)",border:"1px solid var(--border)",borderRadius:99,padding:"4px 10px"}}>
          오늘 {todayTx.length}건 · {fmtS(todayTx.reduce((s,t)=>s+t.amount,0))}원
        </div>
      </div>

      {/* Mode toggle */}
      <div className="u2" style={{display:"flex",gap:7,marginBottom:14}}>
        {[{id:"manual",l:"✏️ 직접 입력"},{id:"ocr",l:"📸 영수증 OCR"}].map(m=>(
          <button key={m.id} onClick={()=>setMode(m.id)} style={{
            flex:1,padding:"11px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:13,
            background:mode===m.id?"var(--goldD)":"var(--bg2)",
            border:`1px solid ${mode===m.id?"var(--gold)":"var(--border)"}`,
            color:mode===m.id?"var(--goldL)":"var(--text2)"
          }}>{m.l}</button>
        ))}
      </div>

      {/* OCR banner */}
      {ocr!=="idle"&&(
        <div className="u2" style={{
          padding:"10px 14px",borderRadius:12,marginBottom:12,
          background:ocr==="done"?"var(--greenD)":ocr==="error"?"var(--redD)":"var(--bg3)",
          border:`1px solid ${ocr==="done"?"rgba(77,171,135,.3)":ocr==="error"?"rgba(217,95,95,.3)":"var(--border)"}`,
          fontSize:12,color:ocr==="done"?"var(--green)":ocr==="error"?"var(--red)":"var(--text2)",
          display:"flex",alignItems:"center",gap:8
        }}>
          {ocr==="loading"&&<span style={{animation:"spin .8s linear infinite",display:"inline-block"}}>⟳</span>}
          {ocrMsg}
        </div>
      )}

      {mode==="ocr"?(
        /* OCR 업로드 영역 */
        <Card className="u3" style={{padding:"0",overflow:"hidden",marginBottom:14}}>
          <label style={{display:"block",padding:"36px 20px",textAlign:"center",cursor:"pointer"}}>
            <div style={{fontSize:40,marginBottom:12}}>📷</div>
            <div style={{fontSize:15,fontWeight:700,marginBottom:6}}>사진 업로드</div>
            <div style={{fontSize:12,color:"var(--text2)",lineHeight:1.7}}>
              영수증 · 카드전표 · 결제문자 캡처<br/>
              <span style={{fontSize:11,color:"var(--text3)"}}>Claude AI가 금액·가맹점·날짜를 자동으로 읽어옵니다</span>
            </div>
            <input type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          </label>
        </Card>
      ):(
        /* 직접 입력 영역 */
        <div className="u3">
          {/* Who */}
          <div style={{display:"flex",gap:8,marginBottom:12}}>
            {["husband","wife"].map(w=>(
              <button key={w} onClick={()=>setWho(w)} style={{
                flex:1,padding:"12px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:14,
                background:who===w?(w==="husband"?"var(--hD)":"var(--wD)"):"var(--bg2)",
                border:`1px solid ${who===w?(w==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,
                color:who===w?(w==="husband"?"var(--h)":"var(--w)"):"var(--text2)"
              }}>{w==="husband"?names.husband:names.wife}</button>
            ))}
          </div>

          {/* Amount display */}
          <Card style={{padding:"14px 18px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
            <span style={{fontSize:12,color:"var(--text2)"}}>금액</span>
            <span style={{fontSize:32,fontWeight:700,color:amount?"var(--text)":"var(--text3)",letterSpacing:"-.02em"}}>
              {amount?parseInt(amount).toLocaleString():"0"}
              <span style={{fontSize:16,color:"var(--text2)",marginLeft:3}}>원</span>
            </span>
          </Card>

          {/* Numpad — 항상 표시 */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7,marginBottom:12}}>
            {pad.map(n=>(
              <button key={n} onClick={()=>num(n)} style={{
                background:n==="⌫"?"var(--bg3)":"var(--bg2)",
                border:"1px solid var(--border)",borderRadius:13,
                padding:"16px",color:"var(--text)",fontSize:18,fontWeight:500,cursor:"pointer",
                transition:"background .1s"
              }}>{n}</button>
            ))}
          </div>

          {/* Category — 금액 입력 전에도 보임 */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:11,color:"var(--text2)",marginBottom:9}}>카테고리</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7}}>
              {CATS.map(c=>(
                <button key={c.id} onClick={()=>setCat(c.id)} style={{
                  background:cat===c.id?c.color+"28":"var(--bg2)",
                  border:`1px solid ${cat===c.id?c.color+"88":"var(--border)"}`,
                  borderRadius:13,padding:"12px 6px",cursor:"pointer",
                  display:"flex",flexDirection:"column",alignItems:"center",gap:5,
                  transition:"all .15s"
                }}>
                  <span style={{fontSize:20}}>{c.icon}</span>
                  <span style={{fontSize:10,fontWeight:cat===c.id?700:400,color:cat===c.id?"var(--text)":"var(--text2)"}}>{c.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Memo */}
          <input placeholder="메모 (선택사항)" value={memo} onChange={e=>setMemo(e.target.value)}
            style={{width:"100%",background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:12,padding:"12px 16px",color:"var(--text)",fontSize:13,outline:"none",marginBottom:12}}/>

          {/* 카드 선택 (등록된 카드가 있을 때만) */}
          {myCards.length > 0 && (
            <div style={{marginBottom:12}}>
              <div style={{fontSize:11,color:"var(--text2)",marginBottom:7}}>결제 카드 <span style={{color:"var(--text3)"}}>(선택)</span></div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                <button onClick={()=>setCardId("")} style={{
                  padding:"7px 13px",borderRadius:99,cursor:"pointer",fontSize:11,fontWeight:600,
                  background:!cardId?"var(--bg4)":"transparent",
                  border:`1px solid ${!cardId?"var(--border2)":"var(--border)"}`,
                  color:!cardId?"var(--text)":"var(--text3)"
                }}>현금/기타</button>
                {myCards.map(c=>(
                  <button key={c.id} onClick={()=>setCardId(c.id)} style={{
                    padding:"7px 13px",borderRadius:99,cursor:"pointer",fontSize:11,fontWeight:600,
                    background:cardId===c.id?c.color+"22":"transparent",
                    border:`1px solid ${cardId===c.id?c.color+"88":"var(--border)"}`,
                    color:cardId===c.id?"var(--text)":"var(--text2)",
                    display:"flex",alignItems:"center",gap:5
                  }}>
                    <span>{c.icon}</span>{c.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Save / Reset */}
          <div style={{display:"flex",gap:8,marginBottom:16}}>
            <button onClick={reset} style={{
              width:52,padding:"14px",background:"var(--bg2)",border:"1px solid var(--border)",
              borderRadius:13,color:"var(--text2)",cursor:"pointer",fontSize:16,flexShrink:0
            }}>↺</button>
            <button onClick={save} disabled={!amount||!cat} style={{
              flex:1,padding:"15px",
              background:saved?"var(--greenD)":(!amount||!cat)?"var(--bg3)":"var(--gold)",
              border:`1px solid ${saved?"var(--green)":(!amount||!cat)?"var(--border)":"transparent"}`,
              borderRadius:13,
              color:saved?"var(--green)":(!amount||!cat)?"var(--text3)":"#fff",
              fontWeight:700,fontSize:15,cursor:(!amount||!cat)?"default":"pointer",
              boxShadow:(!amount||!cat)||saved?"none":"0 4px 24px rgba(200,168,75,.3)",
              transition:"all .2s"
            }}>
              {saved?"✓ 저장됨":(!amount||!cat)?"금액과 카테고리 선택":`저장 · ${amount?parseInt(amount).toLocaleString():0}원`}
            </button>
          </div>
        </div>
      )}

      {/* 오늘의 내역 */}
      <Card className="u4" style={{overflow:"hidden"}}>
        <div style={{padding:"12px 14px 8px",display:"flex",justifyContent:"space-between"}}>
          <span style={{fontSize:12,fontWeight:700}}>오늘 내역</span>
          <span style={{fontSize:12,fontWeight:700,color:"var(--gold)"}}>{fmtS(todayTx.reduce((s,t)=>s+t.amount,0))}원</span>
        </div>
        {todayTx.length===0?(
          <div style={{padding:"24px 14px",textAlign:"center",color:"var(--text3)",fontSize:12}}>
            오늘 입력된 내역이 없어요
          </div>
        ):todayTx.map(t=>{
          const c=CAT[t.cat]||CATS[8];
          return(
            <div key={t.id} style={{padding:"9px 14px",borderTop:"1px solid var(--border)",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:32,height:32,borderRadius:9,background:c.color+"1a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{c.icon}</div>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:1}}>
                  <span style={{fontSize:12,fontWeight:500}}>{c.label}</span>
                  <Chip who={t.who} names={names}/>
                </div>
                <div style={{fontSize:10,color:"var(--text2)"}}>{t.memo||"—"}</div>
              </div>
              <span style={{fontSize:13,fontWeight:700,color:"var(--text)",flexShrink:0}}>-{fmtS(t.amount)}원</span>
              <button onClick={()=>onDelete(t.id)} style={{
                width:26,height:26,borderRadius:7,border:"none",cursor:"pointer",
                background:"var(--redD)",color:"var(--red)",fontSize:13,
                display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0
              }}>✕</button>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// NAV — 입력 탭은 중앙 플로팅 버튼으로 크게
// ─────────────────────────────────────────────────────────────
function Nav({view,setView}){
  const sides=[
    [{id:"home",  icon:"⌂", l:"홈"},    {id:"report",icon:"◈",l:"리포트"}],
    [{id:"fixed", icon:"📌",l:"고정비"}, {id:"settings",icon:"⊙",l:"설정"}],
  ];
  const isEntry = view==="entry";
  return(
    <div style={{
      position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",
      width:"100%",maxWidth:480,zIndex:100,
    }}>
      {/* 플로팅 입력 버튼 — 네브 위에 떠있음 */}
      <div style={{
        position:"absolute",top:-28,left:"50%",transform:"translateX(-50%)",
        zIndex:101,
      }}>
        <button onClick={()=>setView("entry")} style={{
          width:60,height:60,borderRadius:"50%",
          background: isEntry
            ? "linear-gradient(135deg,#e2c97e,#c8a84b)"
            : "linear-gradient(135deg,var(--gold),var(--goldL))",
          border:`3px solid var(--bg)`,
          boxShadow: isEntry
            ? "0 0 0 4px rgba(200,168,75,.3), 0 6px 24px rgba(200,168,75,.5)"
            : "0 4px 20px rgba(200,168,75,.35)",
          cursor:"pointer",
          display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
          gap:1,
          transition:"all .2s",
          transform: isEntry ? "scale(1.08)" : "scale(1)",
        }}>
          <span style={{fontSize:22,lineHeight:1,color:"#fff",fontWeight:700}}>✚</span>
          <span style={{fontSize:8,fontWeight:800,color:"#fff",letterSpacing:".06em",lineHeight:1}}>입력</span>
        </button>
      </div>

      {/* 네브바 본체 */}
      <div style={{
        background:"var(--nav-bg)",backdropFilter:"blur(20px)",
        borderTop:"1px solid var(--border)",
        display:"flex",alignItems:"center",
        padding:"8px 0 14px",
      }}>
        {/* 좌측 2개 */}
        {sides[0].map(item=>(
          <button key={item.id} onClick={()=>setView(item.id)} style={{
            flex:1,background:"none",border:"none",cursor:"pointer",
            display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"4px 0",
            color:view===item.id?"var(--gold)":"var(--text3)",
            fontFamily:"Syne,sans-serif",transition:"color .2s"
          }}>
            <span style={{fontSize:19,lineHeight:1}}>{item.icon}</span>
            <span style={{fontSize:9,fontWeight:view===item.id?700:400,letterSpacing:".03em"}}>{item.l}</span>
          </button>
        ))}

        {/* 가운데 공간 (플로팅 버튼 자리) */}
        <div style={{flex:1}}/>

        {/* 우측 2개 */}
        {sides[1].map(item=>(
          <button key={item.id} onClick={()=>setView(item.id)} style={{
            flex:1,background:"none",border:"none",cursor:"pointer",
            display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"4px 0",
            color:view===item.id?"var(--gold)":"var(--text3)",
            fontFamily:"Syne,sans-serif",transition:"color .2s"
          }}>
            <span style={{fontSize:19,lineHeight:1}}>{item.icon}</span>
            <span style={{fontSize:9,fontWeight:view===item.id?700:400,letterSpacing:".03em"}}>{item.l}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// 기본값 — 샘플 데이터 없음, 빈 상태로 시작
// ─────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────
// SYNC SETUP SCREEN — 가정 코드 생성/참여
// ─────────────────────────────────────────────────────────────
function SyncSetup({onDone}){
  const [tab,  setTab]  = useState("create"); // create | join
  const [code, setCode] = useState("");
  const [role, setRole] = useState("husband");
  const [err,  setErr]  = useState("");
  const [busy, setBusy] = useState(false);

  const genCode = () => Math.random().toString(36).slice(2,8).toUpperCase();

  const handleCreate = async () => {
    setBusy(true); setErr("");
    const hid = genCode();
    try {
      const pairs = [
        [`${hid}_tx`,      JSON.stringify([])],
        [`${hid}_fixed`,   JSON.stringify([])],
        [`${hid}_install`, JSON.stringify([])],
        [`${hid}_cards`,   JSON.stringify([])],
        [`${hid}_budgets`, JSON.stringify(INIT_BUDGETS)],
        [`${hid}_names`,   JSON.stringify({husband:"남편",wife:"와이프"})],
        [`${hid}_plan`,    JSON.stringify({})],
        ["householdId",    JSON.stringify(hid)],
        ["myRole",         JSON.stringify(role)],
      ];
      for (const [k, v] of pairs) {
        await window.storage.set(k, v);
      }
      onDone(hid, role);
    } catch(e) {
      setErr(`오류: ${e?.message||"알 수 없는 오류"}. 다시 시도해주세요.`);
      setBusy(false);
    }
  };

  const handleJoin = async () => {
    const hid = code.trim().toUpperCase();
    if (hid.length !== 6) { setErr("6자리 코드를 입력해주세요."); return; }
    setBusy(true); setErr("");
    try {
      const r = await window.storage.get(`${hid}_tx`);
      if (!r) { setErr("코드를 찾을 수 없어요. 같은 기기에서 만든 코드인지 확인해주세요."); setBusy(false); return; }
      await window.storage.set("householdId", JSON.stringify(hid));
      await window.storage.set("myRole",      JSON.stringify(role));
      onDone(hid, role);
    } catch(e) {
      setErr(`연결 오류: ${e?.message||"알 수 없는 오류"}`); setBusy(false);
    }
  };

  return(
    <div style={{
      height:"100dvh",display:"flex",flexDirection:"column",
      alignItems:"center",justifyContent:"center",padding:"24px",
      background:"var(--bg)",maxWidth:480,margin:"0 auto"
    }}>
      {/* 로고 */}
      <div style={{marginBottom:32,textAlign:"center"}}>
        <div style={{fontSize:48,marginBottom:12}}>💰</div>
        <div className="serif" style={{fontSize:26,marginBottom:6}}>가정 경영 가계부</div>
        <div style={{fontSize:13,color:"var(--text2)"}}>부부가 함께 쓰는 가계부</div>
      </div>

      {/* 탭 */}
      <div style={{display:"flex",gap:6,marginBottom:24,width:"100%",maxWidth:340}}>
        {[{id:"create",l:"새 가계부 만들기"},{id:"join",l:"코드로 참여하기"}].map(t=>(
          <button key={t.id} onClick={()=>{setTab(t.id);setErr("");}} style={{
            flex:1,padding:"11px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:12,
            background:tab===t.id?"var(--goldD)":"var(--bg2)",
            border:`1px solid ${tab===t.id?"var(--gold)":"var(--border)"}`,
            color:tab===t.id?"var(--gold)":"var(--text2)"
          }}>{t.l}</button>
        ))}
      </div>

      {/* 카드 */}
      <div style={{
        background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:20,
        padding:"24px",width:"100%",maxWidth:340
      }}>
        {/* 역할 선택 */}
        <div style={{marginBottom:20}}>
          <div style={{fontSize:12,color:"var(--text2)",marginBottom:10}}>내 역할</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {[{id:"husband",l:"남편",e:"👨"},{id:"wife",l:"와이프",e:"👩"}].map(r=>(
              <button key={r.id} onClick={()=>setRole(r.id)} style={{
                padding:"14px",borderRadius:13,cursor:"pointer",fontWeight:700,fontSize:14,
                background:role===r.id?(r.id==="husband"?"var(--hD)":"var(--wD)"):"var(--bg3)",
                border:`1px solid ${role===r.id?(r.id==="husband"?"rgba(92,141,232,.4)":"rgba(217,127,168,.4)"):"var(--border)"}`,
                color:role===r.id?(r.id==="husband"?"var(--h)":"var(--w)"):"var(--text2)",
                display:"flex",flexDirection:"column",alignItems:"center",gap:6
              }}>
                <span style={{fontSize:28}}>{r.e}</span>
                <span>{r.l}</span>
              </button>
            ))}
          </div>
        </div>

        {tab==="join"&&(
          <div style={{marginBottom:16}}>
            <div style={{fontSize:12,color:"var(--text2)",marginBottom:8}}>가정 코드 6자리</div>
            <input
              value={code}
              onChange={e=>setCode(e.target.value.toUpperCase().slice(0,6))}
              placeholder="예: AB12CD"
              maxLength={6}
              style={{
                width:"100%",background:"var(--bg3)",border:"1px solid var(--border2)",
                borderRadius:12,padding:"14px 16px",color:"var(--text)",fontSize:20,
                fontWeight:700,letterSpacing:".15em",textAlign:"center",outline:"none"
              }}
            />
          </div>
        )}

        {err&&(
          <div style={{
            padding:"10px 14px",borderRadius:10,marginBottom:14,
            background:"var(--redD)",border:"1px solid rgba(170,32,32,.25)",
            fontSize:12,color:"var(--red)"
          }}>{err}</div>
        )}

        <button
          onClick={tab==="create"?handleCreate:handleJoin}
          disabled={busy}
          style={{
            width:"100%",padding:"15px",borderRadius:14,border:"none",cursor:"pointer",
            background:busy?"var(--bg3)":"var(--gold)",
            color:busy?"var(--text3)":"#fff",fontWeight:700,fontSize:15,
            transition:"all .2s"
          }}
        >
          {busy?"처리 중...":(tab==="create"?"가계부 만들기":"참여하기")}
        </button>

        {tab==="create"&&(
          <div style={{fontSize:11,color:"var(--text3)",marginTop:12,textAlign:"center",lineHeight:1.7}}>
            만들면 6자리 코드가 생성돼요.<br/>
            와이프에게 코드를 공유해서 함께 사용하세요.
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// APP ROOT — shared storage + 실시간 동기화
// ─────────────────────────────────────────────────────────────
export default function App(){
  const [ready,      setReady]      = useState(false);
  const [setupDone,  setSetupDone]  = useState(false);
  const [householdId,setHouseholdId]= useState("");
  const [myRole,     setMyRole]     = useState("husband");
  const [view,       setView]       = useState("home");
  const [syncStatus, setSyncStatus] = useState("ok"); // ok | syncing | error
  const [lastSync,   setLastSync]   = useState(null);

  // ── 공유 데이터 ─────────────────────────────────────────────
  const [tx,         setTxRaw]      = useState(EMPTY_TX);
  const [fixed,      setFixedRaw]   = useState(EMPTY_FIXED);
  const [install,    setInstallRaw] = useState(EMPTY_INSTALL);
  const [cards,      setCardsRaw]   = useState(EMPTY_CARDS);
  const [plan,       setPlanRaw]    = useState({});
  const [budgets,    setBudgetsRaw] = useState(INIT_BUDGETS);
  const [names,      setNamesRaw]   = useState({husband:"남편",wife:"와이프"});

  // ── 개인 설정 ───────────────────────────────────────────────
  const [sliderCfg,  setSliderCfgRaw] = useState({...DEFAULT_SLIDER_CFG});
  const [theme,      setThemeRaw]   = useState("dark");
  const [modal,      setModal]      = useState(null);

  // ── 스토리지 헬퍼 — private only (아티팩트 환경 호환) ───────
  // shared:true는 GitHub Pages 배포 후 지원. 현재는 private으로 동작.
  const storeGet = useCallback(async (key) => {
    try { return await window.storage.get(key); } catch { return null; }
  }, []);

  const storeSet = useCallback(async (key, value) => {
    try { return await window.storage.set(key, value); } catch { return null; }
  }, []);

  // ── 공유 데이터 로드 ────────────────────────────────────────
  const loadShared = useCallback(async (hid) => {
    const k = (key) => `${hid}_${key}`;
    const load = async (key, fallback) => {
      try {
        const r = await storeGet(key);
        return r ? JSON.parse(r.value) : fallback;
      } catch { return fallback; }
    };
    const [savedTx, savedFixed, savedInstall, savedCards, savedBudgets, savedNames, savedPlan] =
      await Promise.all([
        load(k("tx"),      EMPTY_TX),
        load(k("fixed"),   EMPTY_FIXED),
        load(k("install"), EMPTY_INSTALL),
        load(k("cards"),   EMPTY_CARDS),
        load(k("budgets"), INIT_BUDGETS),
        load(k("names"),   {husband:"남편",wife:"와이프"}),
        load(k("plan"),    {}),
      ]);
    setTxRaw(savedTx);
    setFixedRaw(savedFixed);
    setInstallRaw(savedInstall);
    setCardsRaw(savedCards);
    setBudgetsRaw(savedBudgets);
    setNamesRaw(savedNames);
    setPlanRaw(savedPlan);
  }, [storeGet]);

  // ── 최초 로드 ──────────────────────────────────────────────
  useEffect(()=>{
    (async()=>{
      try {
        const safeGet = async (key) => {
          try { const r = await window.storage.get(key); return r ? JSON.parse(r.value) : null; }
          catch { return null; }
        };
        const [savedHid, savedRole, savedSlider, savedTheme] = await Promise.all([
          safeGet("householdId"),
          safeGet("myRole"),
          safeGet("sliderCfg"),
          safeGet("theme"),
        ]);
        if (savedSlider) setSliderCfgRaw(savedSlider);
        if (savedTheme)  setThemeRaw(savedTheme);
        if (savedHid) {
          setHouseholdId(savedHid);
          setMyRole(savedRole || "husband");
          await loadShared(savedHid);
          setSetupDone(true);
        }
      } catch(e) { console.error("load error:", e); }
      finally { setReady(true); }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── 폴링 동기화 (5초마다) ──────────────────────────────────
  const pollRef = useRef(null);
  useEffect(()=>{
    if (!setupDone || !householdId) return;
    const poll = async () => {
      setSyncStatus("syncing");
      try {
        await loadShared(householdId);
        setSyncStatus("ok");
        setLastSync(new Date());
      } catch { setSyncStatus("error"); }
    };
    pollRef.current = setInterval(poll, 5000);
    return () => clearInterval(pollRef.current);
  }, [setupDone, householdId, loadShared]);

  // ── 저장 래퍼 (private only — shared는 GitHub Pages 배포 후) ─
  const saveShared = useCallback(async (key, value) => {
    try { await window.storage.set(`${householdId}_${key}`, JSON.stringify(value)); }
    catch(e) { console.error("save error:", e); }
  }, [householdId]);

  const savePrivate = useCallback(async (key, value) => {
    try { await window.storage.set(key, JSON.stringify(value)); }
    catch(e) { console.error("save error:", e); }
  }, []);

  const setTx = useCallback(updater => {
    setTxRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("tx", next); return next;
    });
  }, [saveShared]);

  const setFixed = useCallback(updater => {
    setFixedRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("fixed", next); return next;
    });
  }, [saveShared]);

  const setInstall = useCallback(updater => {
    setInstallRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("install", next); return next;
    });
  }, [saveShared]);

  const setCards = useCallback(updater => {
    setCardsRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("cards", next); return next;
    });
  }, [saveShared]);

  const setPlan = useCallback(updater => {
    setPlanRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("plan", next); return next;
    });
  }, [saveShared]);

  const setBudgets = useCallback(updater => {
    setBudgetsRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      saveShared("budgets", next); return next;
    });
  }, [saveShared]);

  const setNames = useCallback(v => {
    setNamesRaw(v); saveShared("names", v);
  }, [saveShared]);

  const setSliderCfg = useCallback(updater => {
    setSliderCfgRaw(prev => {
      const next = typeof updater==="function" ? updater(prev) : updater;
      savePrivate("sliderCfg", next); return next;
    });
  }, [savePrivate]);

  const setTheme = useCallback(v => {
    setThemeRaw(v); savePrivate("theme", v);
  }, [savePrivate]);

  const addTx    = useCallback(t  => setTx(ts => [...ts, {...t, id:Date.now()}]), [setTx]);
  const deleteTx = useCallback(id => setTx(ts => ts.filter(t=>t.id!==id)), [setTx]);

  const resetAll = useCallback(async () => {
    setTxRaw(EMPTY_TX);           await saveShared("tx",      EMPTY_TX);
    setFixedRaw(EMPTY_FIXED);     await saveShared("fixed",   EMPTY_FIXED);
    setInstallRaw(EMPTY_INSTALL); await saveShared("install", EMPTY_INSTALL);
    setCardsRaw(EMPTY_CARDS);     await saveShared("cards",   EMPTY_CARDS);
    setPlanRaw({});               await saveShared("plan",    {});
    setBudgetsRaw(INIT_BUDGETS);  await saveShared("budgets", INIT_BUDGETS);
  }, [saveShared]);

  // 가계부 나가기 (다른 코드로 참여)
  const leaveHousehold = useCallback(async () => {
    clearInterval(pollRef.current);
    await savePrivate("householdId", null);
    setHouseholdId(""); setSetupDone(false);
    setTxRaw(EMPTY_TX); setFixedRaw(EMPTY_FIXED);
    setInstallRaw(EMPTY_INSTALL); setCardsRaw(EMPTY_CARDS);
    setBudgetsRaw(INIT_BUDGETS); setNamesRaw({husband:"남편",wife:"와이프"});
  }, [savePrivate]);

  // 셋업 완료 콜백
  const handleSetupDone = useCallback(async (hid, role) => {
    setHouseholdId(hid);
    setMyRole(role);
    await loadShared(hid);
    setSetupDone(true);
  }, [loadShared]);

  // ── 로딩 ──────────────────────────────────────────────────
  if(!ready) return(
    <>
      <style dangerouslySetInnerHTML={{__html:G}}/>
      <div className="app-root" style={{maxWidth:480,margin:"0 auto",height:"100dvh",
        display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:12}}>
        <div style={{fontSize:28,animation:"spin 1s linear infinite"}}>⟳</div>
        <div style={{fontSize:13,color:"var(--text2)"}}>불러오는 중...</div>
      </div>
    </>
  );

  // ── 셋업 미완료 → 온보딩 화면 ─────────────────────────────
  if(!setupDone) return(
    <>
      <style dangerouslySetInnerHTML={{__html:G}}/>
      <div className={`app-root${theme==="light"?" light":""}`}>
        <SyncSetup onDone={handleSetupDone}/>
      </div>
    </>
  );

  // ── 동기화 상태 표시 바 ───────────────────────────────────
  const SyncBar = () => (
    <div style={{
      position:"fixed",top:0,left:"50%",transform:"translateX(-50%)",
      width:"100%",maxWidth:480,zIndex:200,
      display:"flex",justifyContent:"space-between",alignItems:"center",
      padding:"6px 14px",
      background:syncStatus==="error"?"var(--redD)":"var(--bg3)",
      borderBottom:`1px solid ${syncStatus==="error"?"rgba(170,32,32,.3)":"var(--border)"}`,
      fontSize:10,color:syncStatus==="error"?"var(--red)":"var(--text3)",
    }}>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <div style={{
          width:6,height:6,borderRadius:"50%",flexShrink:0,
          background:syncStatus==="syncing"?"var(--gold)":syncStatus==="error"?"var(--red)":"var(--green)",
          animation:syncStatus==="syncing"?"pulse 1s infinite":"none"
        }}/>
        <span>{syncStatus==="error"?"동기화 오류":syncStatus==="syncing"?"동기화 중...":"실시간 연결됨"}</span>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <span style={{letterSpacing:".08em",fontWeight:700,color:"var(--gold)"}}>
          {householdId}
        </span>
        <span style={{
          background:myRole==="husband"?"var(--hD)":"var(--wD)",
          color:myRole==="husband"?"var(--h)":"var(--w)",
          padding:"1px 7px",borderRadius:99,fontWeight:700,fontSize:9
        }}>
          {myRole==="husband"?names.husband:names.wife}
        </span>
      </div>
    </div>
  );

  return(
    <>
      <style dangerouslySetInnerHTML={{__html:G}}/>
      <div className={`app-root${theme==="light"?" light":""}`}
        style={{maxWidth:480,margin:"0 auto",height:"100dvh",display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <SyncBar/>
        <div style={{flex:1,overflow:"hidden",marginTop:28}}>
          {view==="home"     && <HomeView     tx={tx} budgets={budgets} fixed={fixed} install={install}
                                              names={names} onAdd={setModal} sliderCfg={sliderCfg}/>}
          {view==="entry"    && <EntryView    names={names} onSave={addTx} onDelete={deleteTx}
                                              tx={tx} cards={cards}/>}
          {view==="report"   && <ReportView   tx={tx} budgets={budgets} fixed={fixed}
                                              install={install} names={names} cards={cards}
                                              plan={plan} setPlan={setPlan}/>}
          {view==="fixed"    && <FixedView    fixed={fixed} setFixed={setFixed}
                                              install={install} setInstall={setInstall}
                                              cards={cards} setCards={setCards}
                                              tx={tx} names={names}/>}
          {view==="settings" && <SettingsView names={names} setNames={setNames}
                                              budgets={budgets} setBudgets={setBudgets}
                                              sliderCfg={sliderCfg} setSliderCfg={setSliderCfg}
                                              theme={theme} setTheme={setTheme}
                                              resetAll={resetAll}
                                              householdId={householdId}
                                              myRole={myRole}
                                              leaveHousehold={leaveHousehold}/>}
        </div>
        <Nav view={view} setView={setView}/>
        {modal&&<InputModal defaultWho={modal} names={names} onClose={()=>setModal(null)} onSave={addTx}/>}
      </div>
    </>
  );
}
