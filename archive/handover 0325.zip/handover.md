# 💰 가정 경영 가계부 — 핸드오버 문서

**작성일:** 2026년 3월 25일  
**저장소:** https://github.com/wjinz/showmethemoney  
**현재 버전:** v2.0 (멀티파일 구조)

---

## 1. 프로젝트 개요

부부(남편 + 와이프)가 함께 쓰는 가계부 앱.  
단순 지출 기록이 아닌 **회사 경영계획처럼** 예산 대비 실적을 관리하는 것이 핵심 컨셉.

---

## 2. 파일 현황

| 파일 | 설명 |
|------|------|
| `budget-app-v2.zip` | ✅ **현재 최신** — 멀티파일 구조 GitHub 업로드용 |
| `family-budget-v4.jsx` | ✅ 단일파일 최신 소스 (Claude 아티팩트용) |
| `family-budget-v3.jsx` | 이전 버전 |
| `family-budget-v2.jsx` | 이전 버전 |
| `family-budget-app.jsx` | 초기 v1 |

**→ 실사용은 `budget-app-v2.zip` 기준으로 진행**

---

## 3. 구현된 기능 전체 목록

### 🏠 홈 탭
- 이달 예산 집행률 링 차트
- 남편 / 와이프 지출 비중 실시간 비교
- **Pace 슬라이더** — 남은 일수 기준 "하루 얼마씩 쓰면 월말이 얼마" 시나리오
- 최근 내역 4건 미리보기
- 빈 상태 안내 메시지

### ✚ 입력 탭 (중앙 플로팅 버튼)
- 직접 입력: 누가 → 숫자패드 → 카테고리 → 메모 → 저장
- **영수증 OCR**: 사진 업로드 → Claude AI가 가맹점·금액·날짜 자동 파싱
- 카드 선택 (등록된 카드 있을 때)
- 오늘 입력 내역 하단 표시 + ✕ 삭제 버튼

### 📊 리포트 탭 (3개 서브탭)

**① 리포트**
- 이번 달 / 전월 지출 구조 가로 스택바 비교
- 전월 대비 카테고리별 증감 칩 (신규/없음/+/-)
- 총괄 표 (예산·고정비·지출·잔여·월말예상)
- 카테고리별 KPI 바 (🔴🟡🟢)
- 파트너별 지출 비교

**② 캘린더**
- 월 네비게이션 (‹ ›)
- 날짜별 지출 히트맵 (초록/빨강)
- 💳 카드 결제일 표시 (분홍 점)
- 날짜 탭하면 당일 내역 + 카드 청구 예정금액 상세

**③ 계획**
- 연간 저축 목표 + 달성률
- 연간 지출 한도 + 집행률·연말 예상
- 월별 지출 현황 바 차트 (12개월)
- 이달 카테고리별 플래닝 (예산 설정과 별개로 이달 목표)
- 큰 지출 이벤트 예고 (냉장고 구매, 여행 등)

### 📌 고정비 탭 (3개 서브탭)

**① 고정비**
- 항목별 등록 (월세, 통신비, 보험 등)
- ✓ 납부 완료 체크
- 납부율 프로그레스바

**② 할부**
- 항목별 등록 (월 납부액, 총 회차, 현재 회차)
- 진행률 바 + 잔여 금액 자동 계산

**③ 카드** ← 핵심 차별화 기능
- 카드사별 정산 기간 등록
  - A형: 당월 X일~말일 → 다음달 Y일 결제
  - B형: 당월 X일~다음달 Z일 → 다음달 Y일 결제 (예: 현대카드)
- 현재 정산 주기 자동 계산
- **D-day** 표시 (결제일 7일 이내 빨강 경고)
- 정산 기간 내 해당 카드 지출 자동 집계 → 청구 예정금액

### ⚙️ 설정 탭
- 화면 모드 (다크/라이트)
- **가정 연결 정보** — 6자리 코드 표시, 공유 안내
- 이름 설정 (남편/와이프 호칭)
- 예산 설계 — 슬라이더 + 직접 입력, 실시간 스택바
- 슬라이더 범위 설정 (Pace 최대값, 예산 최대값)
- 재무 시뮬레이터 초기값
- 모든 내역 초기화

### 🔗 공유·동기화
- **가정 코드 6자리**로 부부 연결
- 새 가계부 만들기 → 코드 생성
- 코드로 참여하기 → 기존 가계부 합류
- 상단 싱크바 (연결됨 🟢 / 동기화중 🟡 / 오류 🔴)
- 5초마다 자동 폴링

---

## 4. 기술 스택

| 항목 | 내용 |
|------|------|
| Framework | React 18 |
| Build Tool | Vite 5 |
| 차트 | Recharts 2 |
| OCR | Claude API (claude-sonnet-4-20250514) |
| 스토리지 | window.storage (Claude 환경) / localStorage 교체 가능 |
| 폰트 | DM Serif Display + Noto Sans KR |
| 배포 | GitHub Pages (GitHub Actions 자동) |

---

## 5. 프로젝트 구조 (v2.0 멀티파일)

```
budget-v2/
├── index.html
├── package.json
├── vite.config.js          ← base: '/showmethemoney/' 설정됨
├── .gitignore
├── .github/workflows/
│   └── deploy.yml          ← push → 자동 빌드·배포
└── src/
    ├── main.jsx
    ├── App.jsx              ← 루트: 상태·저장·라우팅 관리
    ├── constants/index.js   ← CATS, 기본값, 빈 배열
    ├── utils/index.js       ← 날짜, 포맷, 카드 정산 알고리즘
    ├── styles/globalStyles.js
    ├── components/
    │   ├── shared.jsx       ← Ring, Bar, Chip, Card, SliderRow
    │   ├── Nav.jsx
    │   └── InputModal.jsx
    └── views/
        ├── HomeView.jsx
        ├── EntryView.jsx
        ├── ReportView.jsx   ← CalendarView, PlanView, SimulatorView 포함
        ├── FixedView.jsx    ← CardView 포함
        ├── SettingsView.jsx
        ├── SyncSetup.jsx    ← 온보딩
        ├── AssetView.jsx    ← 준비 중 (스텁)
        └── WidgetView.jsx   ← 홈 위젯 오버레이
```

---

## 6. 데이터 구조

### 지출 내역 (tx)
```js
{
  id: 1711234567890,   // Date.now()
  date: "2025-04-21",
  who: "husband",      // "husband" | "wife"
  cat: "food",         // 카테고리 id
  amount: 45000,
  memo: "마트",
  cardId: "card_xxx",  // null이면 현금
}
```

### 카드 (cards)
```js
{
  id: "card_xxx",
  name: "현대카드 M",
  owner: "husband",
  color: "#1c2340",
  icon: "💳",
  billingStartDay: 13,
  billingEndDay: 14,
  billingEndNextMonth: true,   // B형
  paymentDay: 23,
}
```

### 계획 (plan)
```js
{
  yearIncome: 84000000,
  yearSavingGoal: 36000000,
  yearSpendLimit: 48000000,
  monthPlan_2025_4_food: 400000,   // 이달 카테고리별 목표
  events: [
    { id: 123, title: "냉장고 구매", amount: 1500000, month: 5, cat: "housing" }
  ]
}
```

---

## 7. 스토리지 키 구조

```
householdId          → 가정 코드 (private)
myRole               → "husband" | "wife" (private)
sliderCfg            → 슬라이더 설정 (private)
theme                → "dark" | "light" (private)

{hid}_tx             → 지출 내역 (shared)
{hid}_fixed          → 고정비 (shared)
{hid}_install        → 할부 (shared)
{hid}_cards          → 카드 (shared)
{hid}_budgets        → 예산 (shared)
{hid}_names          → 이름 {husband, wife} (shared)
{hid}_plan           → 연간·월간 계획 (shared)
{hid}_assets         → 자산 (shared, 미구현)
```

---

## 8. 현재 알려진 제한사항

| 항목 | 현황 | 해결 방법 |
|------|------|-----------|
| 부부 실시간 동기화 | Claude 아티팩트에선 미지원 | GitHub Pages 배포 후 Supabase 연결 |
| OCR | Claude API 키 필요 | 배포 시 API 키 환경변수로 관리 |
| AssetView | 스텁만 있음 | 다음 스프린트 구현 |
| 데이터 월간 이월 | 미구현 | 월 전환 시 자동 처리 로직 필요 |
| 앱 알림 | 미구현 | PWA + Push 알림으로 구현 가능 |

---

## 9. 다음 작업 우선순위 (백로그)

### 🔴 Must (출시 전 필수)
1. **Supabase 연동** — 진짜 부부 간 실시간 동기화
2. **AssetView** — 부동산·금융자산·현금 자산 관리
3. **월 전환 처리** — 새달이 되면 이전달 데이터 보관
4. **taxConfig** — 남편/와이프 연봉별 실수령액 계산기

### 🟡 Should (출시 후 v2.1)
5. **PWA 설정** — 홈 화면 추가, 오프라인 지원
6. **알림** — 카드 결제일 D-3 알림, 예산 초과 알림
7. **연간 리포트 PDF** — 월말 자동 생성
8. **카테고리 커스텀** — 추가·삭제·색상 변경

### 🟢 Nice to have
9. **내보내기** — 엑셀/CSV 다운로드
10. **광고 연동** — Google AdMob (무료 티어)
11. **유료 구독** — RevenueCat (OCR 무제한, 광고 제거)

---

## 10. GitHub 배포 현황

```
저장소: https://github.com/wjinz/showmethemoney
브랜치: main
배포 URL: https://wjinz.github.io/showmethemoney/

vite.config.js base: '/showmethemoney/'  ✅ 설정됨
GitHub Actions: deploy.yml               ✅ 준비됨
GitHub Pages: Settings → Pages → GitHub Actions 선택 필요
```

**업로드 완료 후 해야 할 것:**
1. 저장소 → Settings → Pages → Source: **GitHub Actions** 선택
2. main 브랜치 push → Actions 탭에서 빌드 확인
3. 초록 체크 → `https://wjinz.github.io/showmethemoney/` 접속

---

## 11. 이 대화에서 만든 것들 요약

| 버전 | 주요 추가 내용 |
|------|--------------|
| v1 | 초기 프로토타입 (홈·입력·리포트·캘린더·설정) |
| v2 | OCR 연동, 고정비·할부 관리, UI 전면 개선 |
| v3 | 슬라이더 4종 인터랙션, 재무 시뮬레이터 |
| v4 | 입력 탭 독립, 데이터 영구저장, 카드 정산, 다크/라이트 |
| v4.1 | 리포트 실데이터 연동, 예산 직접입력, 부부 공유 온보딩 |
| v4.2 | 캘린더 탭, 연간·월간 계획 탭, 멀티파일 구조 분리 |

---

*이 문서는 다음 Claude 세션에서 핸드오버용으로 사용하세요.*  
*새 대화 시작 시 이 문서를 첨부하면 컨텍스트를 빠르게 복원할 수 있습니다.*
